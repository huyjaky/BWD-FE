"use strict";
exports.id = 515;
exports.ids = [515];
exports.modules = {

/***/ 3446:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _headers_buttonAccount_listButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7039);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7607);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const FooterMainRes = ()=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__/* .userAccContext */ .G);
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_9__/* .selectPopoverContext */ .K);
    const [isClickProfile, setIsClickProfile] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const profileTab = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        user
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        const handeOnClick = (event)=>{
            const isClick = profileTab.current?.contains(event.target);
            if (!isClick) {
                setIsClickProfile(false);
                return;
            }
        };
        document.addEventListener("click", handeOnClick);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "laptop:hidden desktop:hidden fixed z-40 bg-white bottom-0 w-full h-[70px]   flex border-t-2 py-1 box-border justify-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: "/homepage",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                        className: "flex w-fit h-full flex-col box-border ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full flex justify-center flex-[4]",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_5__.BiSearch, {
                                    className: "text-[40px] text-slate-500"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 text-slate-500",
                                children: "Explorer"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                    className: "flex w-fit h-full flex-col box-border mx-[70px]",
                    ref: profileTab,
                    onClick: (event)=>{
                        if (user.UserId) {
                            setIsClickProfile(!isClickProfile);
                        }
                    },
                    children: [
                        user.UserId !== "none user" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex justify-center flex-[4]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/api/img/path/" + user.Image,
                                alt: user.UserId,
                                className: "object-cover   w-[40px] h-[40px] rounded-full   "
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex justify-center flex-[4]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_5__.BiUser, {
                                className: "text-[40px] text-slate-500"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-1 text-slate-500",
                            children: user.UserId ? "Profile" : "Login"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                    onClick: ()=>{
                        if (user.UserId !== "none user") {
                            router.push("/hosting", undefined, {
                                shallow: true
                            });
                            return;
                        }
                        setIsLoginClick(true);
                    },
                    className: "flex w-fit h-full flex-col box-border ",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex justify-center flex-[4]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__.BsHouses, {
                                className: "text-[40px] text-slate-500"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-1 text-slate-500",
                            children: "Manage"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    animate: isClickProfile ? {} : {
                        height: 0
                    },
                    className: "fixed bottom-[70px] w-full bg-white overflow-hidden",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headers_buttonAccount_listButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterMainRes);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7039:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7607);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6648);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3708);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);







const ListButton = ()=>{
    const { user , resetDataUser  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_3__/* .userAccContext */ .G);
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_1__/* .selectPopoverContext */ .K);
    const { isFilter , setIsFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_6__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_2__/* .getHouseContext */ .S);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-fit border-b-2",
                children: user?.UserId == "none user" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "w-full py-4 text-left px-5",
                        onClick: (event)=>setIsLoginClick(true),
                        children: "Login"
                    })
                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            href: "hosting",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "w-full py-4 text-left px-5",
                                children: "Manage listings"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "w-full py-4 text-left px-5",
                            children: "Account"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "w-full py-4 text-left px-5",
                            onClick: async ()=>{
                                const logout = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_4__.signOut)({
                                    redirect: false
                                });
                                resetDataUser();
                                setIsFilter("main");
                            },
                            children: "Logout"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-fit",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                    href: "/",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full py-4 text-left px-5",
                        children: "About us"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ListButton);


/***/ }),

/***/ 1600:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const variants = {
    inView: {
        x: [
            -200,
            0
        ]
    },
    iconAnimate: {
        borderRadius: [
            "50% 50% 20% 80% / 25% 80% 20% 75%",
            "67% 33% 47% 53% / 37% 20% 80% 63%",
            "39% 61% 47% 53% / 37% 40% 60% 63%",
            "39% 61% 82% 18% / 74% 40% 60% 26%",
            "50% 50% 53% 47% / 26% 22% 78% 74%",
            "50% 50% 20% 80% / 25% 80% 20% 75%",
            "30% 70% 70% 30% / 30% 52% 48% 70%",
            "20% 80% 20% 80% / 20% 80% 20% 80%"
        ],
        transition: {
            duration: 10,
            repeat: Infinity,
            type: "tween"
        }
    }
};
const HostUser = ({ imgPath , userName , gmail , description  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
        variants: variants,
        whileInView: "inView",
        className: "w-fit h-fit m-auto ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                whileHover: {
                    scale: 1.1
                },
                className: "w-[400px] mobile:w-full h-[250px] bg-white rounded-2xl flex flex-col shadow-2xl",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-fit h-fit m-auto text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.img, {
                            variants: variants,
                            animate: "iconAnimate",
                            src: "/api/img/path/" + imgPath,
                            alt: "",
                            className: "w-[120px] h-[120px] rounded-full"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-semibold text-[30px]",
                            children: userName
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full h-fit text-justify text-[20px]",
                            children: description
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col w-full h-fit items-center text-[30px] divide-y-2 divide-red-500 mt-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Contact me"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_2__.TbBrandGmail, {}),
                            ": \xa0",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: gmail
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HostUser);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6487:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const maskVariants = {
    hidden: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        }
    }
};
const MaskPt = ({ Path , setPath  })=>{
    if (!Path) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: maskVariants,
            initial: Path ? {
                display: "flex"
            } : false,
            animate: "hidden",
            className: "fixed flex top-0 left-0 w-screen h-screen bg-mask box-border py-3 ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[1000px] m-auto h-fit overflow-hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: Path ? "/api/img/path/" + Path : "",
                    alt: "",
                    className: "m-auto  rounded-2xl"
                })
            })
        })
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            initial: {
                display: "flex",
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            className: "fixed flex top-0 left-0 w-screen h-screen bg-mask box-border py-3 z-[50] ",
            onClick: ()=>setPath(null),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[1000px] m-auto h-full overflow-hidden flex",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.img, {
                    transition: {
                        type: "spring"
                    },
                    initial: {
                        y: 200
                    },
                    animate: {
                        y: 0
                    },
                    src: Path ? "/api/img/path/" + Path : "",
                    alt: "",
                    className: "m-auto max-w-full max-h-full object-cover rounded-2xl "
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MaskPt);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8183:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3565);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const tickVariants = {
    pressed: (isChecked)=>({
            pathLength: isChecked ? 1 : 0.2
        }),
    checked: {
        pathLength: 1
    },
    unchecked: {
        pathLength: 0
    }
};
const boxVariants = {
    hover: {
        scale: 1,
        strokeWidth: 7
    },
    pressed: {
        scale: 1,
        strokeWidth: 4
    },
    checked: {
        stroke: "#FF008C"
    },
    unchecked: {
        stroke: "#ddd",
        strokeWidth: 5
    }
};
const CheckBox = ({ isCheckedProps  })=>{
    const [isChecked, setIsChecked] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(isCheckedProps);
    const { filterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_3__/* .filterContext */ .u);
    const pathLength = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__.useMotionValue)(0);
    const opacity = (0,framer_motion__WEBPACK_IMPORTED_MODULE_2__.useTransform)(pathLength, [
        0.05,
        0.15
    ], [
        0,
        1
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setIsChecked(isCheckedProps);
    }, [
        isCheckedProps,
        isChecked
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "text-left",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.svg, {
            initial: false,
            animate: isChecked ? "checked" : "unchecked",
            whileHover: "hover",
            whileTap: "pressed",
            width: "40",
            height: "40",
            onClick: ()=>setIsChecked(!isChecked),
            className: "stroke-[3.5px] outline-none",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.path, {
                    d: "M 7.2 13.6 C 7.2 10.0654 10.0654 7.2 13.6 7.2 L 30.4 7.2 C 33.9346 7.2 36.8 10.0654 36.8 13.6 L 36.8 30.4 C 36.8 33.9346 33.9346 36.8 30.4 36.8 L 13.6 36.8 C 10.0654 36.8 7.2 33.9346 7.2 30.4 Z",
                    fill: "transparent",
                    strokeWidth: "5",
                    stroke: "#FF008C",
                    variants: boxVariants,
                    className: "stroke-[3.5px] stroke-slate-600 "
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.path, {
                    d: "M 0 12.8666 L 12.8658 25.7373 L 27.2016 0",
                    transform: "translate(8.4917 8.8332) rotate(-4 20.0904 20.8687)",
                    fill: "transparent",
                    strokeWidth: "7",
                    stroke: "hsl(0, 0%, 100%)",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    variants: tickVariants,
                    style: {
                        pathLength,
                        opacity
                    },
                    custom: isChecked,
                    className: "stroke-[5px] stroke-slate-200"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.path, {
                    d: "M 0 12.8666 L 12.8658 25.7373 L 27.2016 0",
                    transform: "translate(7.4917 6.8947) rotate(-4 17.0904 12.8687)",
                    fill: "transparent",
                    strokeWidth: "7",
                    stroke: "#7700FF",
                    strokeLinecap: "round",
                    strokeLinejoin: "round",
                    variants: tickVariants,
                    style: {
                        pathLength,
                        opacity
                    },
                    custom: isChecked,
                    className: "stroke-[5px] stroke-red-500"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckBox);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3579:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var popmotion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5563);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, popmotion__WEBPACK_IMPORTED_MODULE_3__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, popmotion__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const variants = {
    enter: (direction)=>{
        return {
            x: direction > 0 ? 1000 : -1000,
            opacity: 0
        };
    },
    center: {
        zIndex: 1,
        x: 0,
        opacity: 1
    },
    exit: (direction)=>{
        return {
            zIndex: 0,
            x: direction < 0 ? 1000 : -1000,
            opacity: 0
        };
    }
};
const variantsBtn = {
    hiddenLeft: {
        left: -100
    },
    showLeft: {
        left: 8
    },
    hiddenRight: {
        right: 8
    },
    showRight: {
        right: -100
    }
};
const swipeConfidenceThreshold = 10000;
const swipePower = (offset, velocity)=>{
    return Math.abs(offset) * velocity;
};
const styleBtn = "absolute top-[calc(50%-20px)] z-10 bg-white rounded-full w-10 h-10 flex items-center justify-center ";
const Carousel = ({ arrImg , houseId  })=>{
    const [[page, direction], setPage] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([
        0,
        0
    ]);
    const [isHover, setIsHover] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const imageIndex = (0,popmotion__WEBPACK_IMPORTED_MODULE_3__.wrap)(0, arrImg.length, page);
    const paginate = (newDirection)=>{
        setPage([
            page + newDirection,
            newDirection
        ]);
    };
    const handleOnEnter = (event)=>{
        setIsHover(true);
    };
    const handleOnLeave = (event)=>{
        setIsHover(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.AnimatePresence, {
            initial: false,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                className: "w-full h-full relative flex overflow-hidden rounded-xl",
                onHoverStart: handleOnEnter,
                onHoverEnd: handleOnLeave,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.AnimatePresence, {
                        initial: false,
                        custom: direction,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.img, {
                            src: "/api/img/path/" + arrImg[imageIndex].Path,
                            custom: direction,
                            variants: variants,
                            initial: "enter",
                            animate: "center",
                            exit: "exit",
                            onDoubleClick: (event)=>{
                                router.push(`/house/${houseId}`, undefined, {
                                    shallow: true
                                });
                            },
                            onTouchEnd: ()=>{
                            // router.push(`/house/${houseId}`, undefined, { shallow: true });
                            },
                            className: "w-full h-full absolute object-cover",
                            transition: {
                                x: {
                                    type: "spring",
                                    stiffness: 200,
                                    damping: 30
                                },
                                opacity: {
                                    duration: 0.5
                                }
                            },
                            drag: "x",
                            dragConstraints: {
                                left: 0,
                                right: 0
                            },
                            dragElastic: 1,
                            onDragEnd: (e, { offset , velocity  })=>{
                                const swipe = swipePower(offset.x, velocity.x);
                                if (swipe < -swipeConfidenceThreshold) {
                                    paginate(1);
                                } else if (swipe > swipeConfidenceThreshold) {
                                    paginate(-1);
                                }
                            }
                        }, page)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                        variants: variantsBtn,
                        onClick: ()=>paginate(-1),
                        initial: isHover ? "hiddenLeft" : "showLeft",
                        animate: isHover ? "showLeft" : "hiddenLeft",
                        whileHover: {
                            scale: 1.1,
                            backgroundColor: "rgba(239, 68, 68, .6)"
                        },
                        transition: {
                            duration: 0.5,
                            type: "tween"
                        },
                        className: `${styleBtn} left-[10px] mobile:hidden tablet:hidden `,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__.GrCaretPrevious, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                        variants: variantsBtn,
                        onClick: ()=>paginate(1),
                        initial: isHover ? "showRight" : "hiddenRight",
                        whileHover: {
                            scale: 1.1,
                            backgroundColor: "rgba(239, 68, 68, .6)"
                        },
                        animate: isHover ? "hiddenRight" : "showRight",
                        transition: {
                            duration: 0.5,
                            type: "tween"
                        },
                        className: `${styleBtn} right-[10px] mobile:hidden tablet:hidden `,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__.GrCaretNext, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                        variants: variantsBtn,
                        onClick: ()=>paginate(-1),
                        whileTap: {
                            scale: 1.1,
                            backgroundColor: "rgba(239, 68, 68, .6)"
                        },
                        transition: {
                            duration: 0.5,
                            type: "tween"
                        },
                        className: `${styleBtn} left-[10px] laptop:hidden desktop:hidden`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__.GrCaretPrevious, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                        variants: variantsBtn,
                        onClick: ()=>paginate(1),
                        whileTap: {
                            scale: 1.1,
                            backgroundColor: "rgba(239, 68, 68, .6)"
                        },
                        transition: {
                            duration: 0.5,
                            type: "tween"
                        },
                        className: `${styleBtn} right-[10px] laptop:hidden desktop:hidden`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__.GrCaretNext, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Carousel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;