"use strict";
exports.id = 539;
exports.ids = [539];
exports.modules = {

/***/ 1539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1705);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9445);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var bingmaps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5538);
/* harmony import */ var bingmaps__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bingmaps__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);




 // <--  Microsoft supported types library for Microsoft.Maps

const SearchBox = ({ styleBox  })=>{
    const { address , setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_2__/* .selectPlaceContext */ .t);
    const { isShowHeader , setIsShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_1__/* .filterFormAnimateContext */ .b);
    const inputBox = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    // luu y la chi cho nhung doan code ve map vao useEffect con nhung doan code ve input nhap lieu thi
    // khong duoc cho vao useEffect
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__.whenLoaded.then(()=>{
            Microsoft.Maps.loadModule("Microsoft.Maps.AutoSuggest", {
                callback: onLoad
            });
        });
        function onLoad() {
            var options = {
                maxResults: 5,
                businessSuggestions: true
            };
            var manager = new Microsoft.Maps.AutosuggestManager(options);
            manager.attachAutosuggest("#searchBox", "#searchBoxContainer", (suggestionResult)=>{
                setIsShowHeader(true);
                setAddress({
                    ...address,
                    address: {
                        ...address.address,
                        ...suggestionResult?.address,
                        ...suggestionResult?.location
                    }
                });
            });
        }
        const temp = document.getElementById("searchBox");
        temp?.addEventListener("change", (event)=>{
            setAddress({
                ...address,
                address: {
                    ...address.address,
                    formattedAddress: event.target.value
                }
            });
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "searchBoxContainer",
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "text",
                name: "input-place",
                id: "searchBox",
                ref: inputBox,
                placeholder: "Search your locations",
                className: `outline-none focus:border-b-2 focus:border-slate-600 w-[calc(100%-40px)] ${styleBox} pointer-events-auto text-ellipsis `
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchBox);


/***/ })

};
;