"use strict";
exports.id = 665;
exports.ids = [665];
exports.modules = {

/***/ 1477:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ createHouseFormContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const createHouseDataDefault = {
    Address: {
        countryRegion: "",
        locality: "",
        adminDistrict: "",
        countryRegionIso2: "",
        postalCode: "",
        addressLine: "",
        streetName: "",
        formattedAddress: "",
        latitude: 0,
        longitude: 0,
        title: ""
    },
    setAddress: ()=>{},
    typeHouseId: [],
    setTypeHouseId: ()=>{},
    createHouseForm: {
        address: {
            countryRegion: "",
            locality: "",
            adminDistrict: "",
            countryRegionIso2: "",
            postalCode: "",
            addressLine: "",
            streetName: "",
            formattedAddress: "",
            latitude: 0,
            longitude: 0,
            title: ""
        },
        AddressId: "",
        Area: "",
        arrImg: [],
        Capacity: 0,
        DateUp: new Date(),
        Description: "",
        HouseId: "",
        IsFavorite: false,
        JudicalId: "",
        NumsOfBath: 0,
        NumsOfBed: 0,
        Orientation: "",
        placeOffer: [],
        PostBy: "",
        Price: 10,
        Title: "",
        Type: "",
        useracc: {
            UserId: "",
            UserName: "",
            Password: "",
            Birth: new Date(),
            Gmail: "",
            Sex: "",
            Decentralization: "",
            PersonCode: "",
            CustomerType: "",
            Image: "",
            error: "",
            Phone: ""
        }
    },
    emptyCreateHouseForm: {
        address: {
            countryRegion: "",
            locality: "",
            adminDistrict: "",
            countryRegionIso2: "",
            postalCode: "",
            addressLine: "",
            streetName: "",
            formattedAddress: "",
            latitude: 0,
            longitude: 0,
            title: ""
        },
        AddressId: "",
        Area: "",
        arrImg: [],
        Capacity: 0,
        DateUp: new Date(),
        Description: "",
        HouseId: "",
        IsFavorite: false,
        JudicalId: "",
        NumsOfBath: 0,
        NumsOfBed: 0,
        Orientation: "",
        placeOffer: [],
        PostBy: "",
        Price: 10,
        Title: "",
        Type: "",
        useracc: {
            UserId: "",
            UserName: "",
            Password: "",
            Birth: new Date(),
            Gmail: "",
            Sex: "",
            Decentralization: "",
            PersonCode: "",
            CustomerType: "",
            Image: "",
            error: "",
            Phone: ""
        }
    },
    imgArr: [],
    setCreateHouseForm: ()=>{},
    setImgArr: ()=>{}
};
const createHouseFormContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(createHouseDataDefault);
const CreateHouseFormProvider = ({ children  })=>{
    const [createHouseForm, setSelectHouse_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(createHouseDataDefault.createHouseForm);
    const [emptyCreateHouseForm, setEmptyCreateHouseForm_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(createHouseDataDefault.emptyCreateHouseForm);
    const [typeHouseId, setTypeHouseId_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(createHouseDataDefault.typeHouseId);
    const [imgArr, setImgArr_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(createHouseDataDefault.imgArr);
    const [Address, setAddress_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(createHouseDataDefault.Address);
    const setCreateHouseForm = (payload)=>setSelectHouse_(payload);
    const setTypeHouseId = (payload)=>setTypeHouseId_(payload);
    const setImgArr = (payload)=>setImgArr_(payload);
    const setAddress = (payload)=>setAddress_(payload);
    const selectHouseDynamicData = {
        createHouseForm,
        emptyCreateHouseForm,
        setCreateHouseForm,
        typeHouseId,
        setTypeHouseId,
        imgArr,
        setImgArr,
        Address,
        setAddress
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(createHouseFormContext.Provider, {
        value: selectHouseDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateHouseFormProvider);


/***/ }),

/***/ 9747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ StepCreateHomeContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const StepCreateHomeDefaultData = {
    stepCreate: 1,
    setStepCreate: ()=>{}
};
const StepCreateHomeContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(StepCreateHomeDefaultData);
const StepCreateHomeProvider = ({ children  })=>{
    const [stepCreate, setStepCreate_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(StepCreateHomeDefaultData.stepCreate);
    const setStepCreate = (payload)=>setStepCreate_(payload);
    const StepCreateHomeDynamicData = {
        stepCreate,
        setStepCreate
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StepCreateHomeContext.Provider, {
        value: StepCreateHomeDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StepCreateHomeProvider);


/***/ })

};
;