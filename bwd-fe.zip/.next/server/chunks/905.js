"use strict";
exports.id = 905;
exports.ids = [905];
exports.modules = {

/***/ 6905:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7607);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6648);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3708);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1908);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5641);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_8__]);
([_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__, react_hook_form__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const passwordRegex = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/;
const schema = yup__WEBPACK_IMPORTED_MODULE_9__.object({
    username: yup__WEBPACK_IMPORTED_MODULE_9__.string().required(),
    password: yup__WEBPACK_IMPORTED_MODULE_9__.string().required()
}).required();
const LoginPanel = ({ children  })=>{
    const { data: session  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_5__.useSession)();
    const { user , setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_3__/* .userAccContext */ .G);
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_1__/* .selectPopoverContext */ .K);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const divRef = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    const title_username = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    const input_username = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    const { setIsFilter , isFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_2__/* .getHouseContext */ .S);
    const divRef2 = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    const title_password = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    const input_password = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    // just animate
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        let handleOnClickOutSide = (event)=>{
            const isContain1 = divRef?.current?.contains(event.target);
            if (isContain1) {
                title_username?.current?.classList.add("animate-boxInputLoginFocus_title");
                input_username?.current?.classList.add("animate-boxInputLoginFocus_input");
                // input_username?.current?.classList.add('border-b-2');
                title_username?.current?.classList.remove("animate-boxInputLoginFocus_titleReverse");
                input_username?.current?.classList.remove("animate-boxInputLoginFocus_inputReverse");
                input_username?.current?.focus();
                return;
            }
            const isContain2 = divRef2?.current?.contains(event.target);
            if (isContain2) {
                title_password?.current?.classList.add("animate-boxInputLoginFocus_title");
                input_password?.current?.classList.add("animate-boxInputLoginFocus_input");
                title_password?.current?.classList.remove("animate-boxInputLoginFocus_titleReverse");
                input_password?.current?.classList.remove("animate-boxInputLoginFocus_inputReverse");
                input_password?.current?.focus();
                return;
            }
        };
        document.addEventListener("mousedown", handleOnClickOutSide);
    }, []);
    const { register , handleSubmit , watch , setError , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_8__.useForm)({
        defaultValues: {
            username: "",
            password: ""
        },
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_4__.yupResolver)(schema)
    });
    // fetch accesstoken , navigate as well as do animte
    const onSubmit = async (data_)=>{
        nprogress__WEBPACK_IMPORTED_MODULE_10___default().set(0.6);
        const login_ = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_5__.signIn)("credentials", {
            username: data_.username,
            password: data_.password,
            redirect: false
        });
        if (!login_?.ok) {
            setError("username", {
                type: "validate",
                message: "Wrong username or password!"
            });
            setError("password", {
                type: "validate",
                message: "Wrong username or password!"
            });
            return;
        }
        if (login_?.ok) {
            setUser({
                ...user,
                ...session?.userAcc
            });
            setIsLoginClick(false);
        }
        setIsFilter("main");
        if (router.asPath === "/login") {
            router.push("/", undefined, {
                shallow: true
            });
        }
        nprogress__WEBPACK_IMPORTED_MODULE_10___default().done();
        return;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-[600px] h-fit m-auto shadow-2xl rounded-3xl box-border p-10   mobile:w-full mobile:h-full relative   ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: ()=>{
                    setIsLoginClick(false);
                },
                className: "top-5 left-5 absolute ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_11__.IoCloseOutline, {
                    className: "h-full text-[2.4rem] text-left"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-fit flex justify-end border-b-2 mb-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full text-center m-auto relative",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-bold",
                            children: "Login or Sign Up"
                        })
                    }),
                    children
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "font-semibold text-[2rem] w-full",
                children: "Welcome to Olympus"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 w-full h-fit",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                        onSubmit: handleSubmit(onSubmit),
                        className: "w-full h-full grid grid-cols-1 grid-rows-2 mb-3   ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `border-2 rounded-t-xl box-border p-3 h-[5.625rem] ${errors?.username?.message ? "border-red-500" : ""}`,
                                ref: divRef,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-full m-auto",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full h-full flex items-center",
                                            ref: title_username,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    "User name",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "italic text-red-500",
                                                        children: [
                                                            " ",
                                                            "| ",
                                                            errors.username?.message ? ` ${errors.username.message}` : ""
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full h-0 mt-2 overflow-hidden",
                                            ref: input_username,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                ...register("username"),
                                                type: "text",
                                                className: "w-full h-[2.4rem] outline-none border-b shadow-2xl text-[1rem]"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `border-2 rounded-b-xl box-border flex p-3 h-[5.625rem] ${errors?.password?.message ? "border-red-500" : ""}`,
                                ref: divRef2,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-full m-auto",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full h-full flex items-center",
                                            ref: title_password,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                children: [
                                                    "Password",
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: "italic text-red-500",
                                                        children: [
                                                            " ",
                                                            "| ",
                                                            errors.password?.message ? ` ${errors.password.message}` : ""
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full h-0 mt-2 overflow-hidden",
                                            ref: input_password,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                ...register("password"),
                                                type: "password",
                                                className: "w-full h-[2.4rem] outline-none border-b shadow-2xl text-[1rem]"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "submit",
                                className: "w-full h-fit py-3 bg-red-600 mt-5 rounded-xl",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-white font-semibold text-[2rem]",
                                    children: "Login"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "font-light text-[15px]",
                        children: "We'll call or text you to confirm your number. Standard message and data rates apply."
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginPanel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;