"use strict";
exports.id = 751;
exports.ids = [751];
exports.modules = {

/***/ 3446:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _headers_buttonAccount_listButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7039);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7607);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const FooterMainRes = ()=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__/* .userAccContext */ .G);
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_9__/* .selectPopoverContext */ .K);
    const [isClickProfile, setIsClickProfile] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const profileTab = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        user
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        const handeOnClick = (event)=>{
            const isClick = profileTab.current?.contains(event.target);
            if (!isClick) {
                setIsClickProfile(false);
                return;
            }
        };
        document.addEventListener("click", handeOnClick);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "laptop:hidden desktop:hidden fixed z-40 bg-white bottom-0 w-full h-[4.5rem]   flex border-t-2 py-1 box-border justify-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: "/homepage",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                        className: "flex w-fit h-full flex-col box-border ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full flex justify-center flex-[4]",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_5__.BiSearch, {
                                    className: "text-[2.4rem] text-slate-500"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 text-slate-500",
                                children: "Explorer"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                    className: "flex w-fit h-full flex-col box-border mx-[4.5rem]",
                    ref: profileTab,
                    onClick: (event)=>{
                        if (user.UserId) {
                            setIsClickProfile(!isClickProfile);
                        }
                    },
                    children: [
                        user.UserId !== "none user" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex justify-center flex-[4]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/api/img/path/" + user.Image,
                                alt: user.UserId,
                                className: "object-cover   w-[2.4rem] h-[2.4rem] rounded-full   "
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex justify-center flex-[4]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_5__.BiUser, {
                                className: "text-[2.4rem] text-slate-500"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-1 text-slate-500",
                            children: user.UserId ? "Profile" : "Login"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                    onClick: ()=>{
                        if (user.UserId !== "none user") {
                            router.push("/hosting", undefined, {
                                shallow: true
                            });
                            return;
                        }
                        setIsLoginClick(true);
                    },
                    className: "flex w-fit h-full flex-col box-border ",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex justify-center flex-[4]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_7__.BsHouses, {
                                className: "text-[2.4rem] text-slate-500"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-1 text-slate-500",
                            children: "Manage"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    animate: isClickProfile ? {} : {
                        height: 0
                    },
                    className: "fixed bottom-[4.5rem] w-full bg-white overflow-hidden",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headers_buttonAccount_listButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterMainRes);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1600:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const variants = {
    inView: {
        x: [
            -200,
            0
        ]
    },
    iconAnimate: {
        borderRadius: [
            "50% 50% 20% 80% / 25% 80% 20% 75%",
            "67% 33% 47% 53% / 37% 20% 80% 63%",
            "39% 61% 47% 53% / 37% 40% 60% 63%",
            "39% 61% 82% 18% / 74% 40% 60% 26%",
            "50% 50% 53% 47% / 26% 22% 78% 74%",
            "50% 50% 20% 80% / 25% 80% 20% 75%",
            "30% 70% 70% 30% / 30% 52% 48% 70%",
            "20% 80% 20% 80% / 20% 80% 20% 80%"
        ],
        transition: {
            duration: 10,
            repeat: Infinity,
            type: "tween"
        }
    }
};
const HostUser = ({ imgPath , userName , gmail , description  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
        variants: variants,
        whileInView: "inView",
        className: "w-fit h-fit m-auto ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                whileHover: {
                    scale: 1.1
                },
                className: "w-[25rem] mobile:w-full h-[16rem] bg-white rounded-2xl flex flex-col shadow-2xl",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-fit h-fit m-auto text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.img, {
                            variants: variants,
                            animate: "iconAnimate",
                            src: "/api/img/path/" + imgPath,
                            alt: "",
                            className: "w-[7.5rem] h-[7.5rem] rounded-full"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-semibold text-[2rem]",
                            children: userName
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full h-fit text-justify text-[1rem]",
                            children: description
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {})
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col w-full h-fit items-center text-[2rem] divide-y-2 divide-red-500 mt-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Contact me"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_2__.TbBrandGmail, {}),
                            ": \xa0",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: gmail
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HostUser);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6487:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const maskVariants = {
    hidden: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        }
    }
};
const MaskPt = ({ Path , setPath  })=>{
    if (!Path) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: maskVariants,
            initial: Path ? {
                display: "flex"
            } : false,
            animate: "hidden",
            className: "fixed flex top-0 left-0 w-screen h-screen bg-mask   box-border py-3   ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[63rem] m-auto h-fit overflow-hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: Path ? "/api/img/path/" + Path : "",
                    alt: "",
                    className: "m-auto  rounded-2xl"
                })
            })
        })
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            initial: {
                display: "flex",
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            className: "fixed flex top-0 left-0 w-screen h-screen bg-mask   box-border py-3 z-[50]   ",
            onClick: ()=>setPath(null),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[63rem] m-auto h-full overflow-hidden flex",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.img, {
                    transition: {
                        type: "spring"
                    },
                    initial: {
                        y: 200
                    },
                    animate: {
                        y: 0
                    },
                    src: Path ? "/api/img/path/" + Path : "",
                    alt: "",
                    className: "m-auto max-w-full max-h-full object-cover rounded-2xl "
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MaskPt);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3579:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var popmotion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5563);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, popmotion__WEBPACK_IMPORTED_MODULE_3__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, popmotion__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const variants = {
    enter: (direction)=>{
        return {
            x: direction > 0 ? 1000 : -1000,
            opacity: 0
        };
    },
    center: {
        zIndex: 1,
        x: 0,
        opacity: 1
    },
    exit: (direction)=>{
        return {
            zIndex: 0,
            x: direction < 0 ? 1000 : -1000,
            opacity: 0
        };
    }
};
const variantsBtn = {
    hiddenLeft: {
        left: -100
    },
    showLeft: {
        left: 8
    },
    hiddenRight: {
        right: 8
    },
    showRight: {
        right: -100
    }
};
const swipeConfidenceThreshold = 10000;
const swipePower = (offset, velocity)=>{
    return Math.abs(offset) * velocity;
};
const styleBtn = "absolute top-[calc(50%-1rem)] z-10 bg-white rounded-full w-10 h-10 flex items-center justify-center ";
const Carousel = ({ arrImg , houseId  })=>{
    const [[page, direction], setPage] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([
        0,
        0
    ]);
    const [isHover, setIsHover] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const imageIndex = (0,popmotion__WEBPACK_IMPORTED_MODULE_3__.wrap)(0, arrImg.length, page);
    const paginate = (newDirection)=>{
        setPage([
            page + newDirection,
            newDirection
        ]);
    };
    const handleOnEnter = (event)=>{
        setIsHover(true);
    };
    const handleOnLeave = (event)=>{
        setIsHover(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.AnimatePresence, {
            initial: false,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                className: "w-full h-full relative flex overflow-hidden rounded-xl",
                onHoverStart: handleOnEnter,
                onHoverEnd: handleOnLeave,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.AnimatePresence, {
                        initial: false,
                        custom: direction,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.img, {
                            src: "/api/img/path/" + arrImg[imageIndex].Path,
                            custom: direction,
                            variants: variants,
                            initial: "enter",
                            animate: "center",
                            exit: "exit",
                            onDoubleClick: (event)=>{
                                router.push(`/house/${houseId}`, undefined, {
                                    shallow: true
                                });
                            },
                            onTouchEnd: ()=>{
                            // router.push(`/house/${houseId}`, undefined, { shallow: true });
                            },
                            className: "w-full h-full absolute object-cover",
                            transition: {
                                x: {
                                    type: "spring",
                                    stiffness: 200,
                                    damping: 30
                                },
                                opacity: {
                                    duration: 0.5
                                }
                            },
                            drag: "x",
                            dragConstraints: {
                                left: 0,
                                right: 0
                            },
                            dragElastic: 1,
                            onDragEnd: (e, { offset , velocity  })=>{
                                const swipe = swipePower(offset.x, velocity.x);
                                if (swipe < -swipeConfidenceThreshold) {
                                    paginate(1);
                                } else if (swipe > swipeConfidenceThreshold) {
                                    paginate(-1);
                                }
                            }
                        }, page)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                        variants: variantsBtn,
                        onClick: ()=>paginate(-1),
                        initial: isHover ? "hiddenLeft" : "showLeft",
                        animate: isHover ? "showLeft" : "hiddenLeft",
                        whileHover: {
                            scale: 1.1,
                            backgroundColor: "rgba(239, 68, 68, .6)"
                        },
                        transition: {
                            duration: 0.5,
                            type: "tween"
                        },
                        className: `${styleBtn} left-[.6rem] mobile:hidden tablet:hidden `,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__.GrCaretPrevious, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                        variants: variantsBtn,
                        onClick: ()=>paginate(1),
                        initial: isHover ? "showRight" : "hiddenRight",
                        whileHover: {
                            scale: 1.1,
                            backgroundColor: "rgba(239, 68, 68, .6)"
                        },
                        animate: isHover ? "hiddenRight" : "showRight",
                        transition: {
                            duration: 0.5,
                            type: "tween"
                        },
                        className: `${styleBtn} right-[.6rem] mobile:hidden tablet:hidden `,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__.GrCaretNext, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                        variants: variantsBtn,
                        onClick: ()=>paginate(-1),
                        whileTap: {
                            scale: 1.1,
                            backgroundColor: "rgba(239, 68, 68, .6)"
                        },
                        transition: {
                            duration: 0.5,
                            type: "tween"
                        },
                        className: `${styleBtn} left-[.6rem] laptop:hidden desktop:hidden`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__.GrCaretPrevious, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                        variants: variantsBtn,
                        onClick: ()=>paginate(1),
                        whileTap: {
                            scale: 1.1,
                            backgroundColor: "rgba(239, 68, 68, .6)"
                        },
                        transition: {
                            duration: 0.5,
                            type: "tween"
                        },
                        className: `${styleBtn} right-[.6rem] laptop:hidden desktop:hidden`,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_5__.GrCaretNext, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Carousel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;