"use strict";
exports.id = 248;
exports.ids = [248];
exports.modules = {

/***/ 764:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _listButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7039);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const variants = {
    show: {
        maxHeight: [
            "0px",
            "500px"
        ],
        // border: ['none', '3px solid grey'],
        display: "block"
    },
    hidden: {
        maxHeight: [
            "500px",
            "0px"
        ],
        // border: ['3px solid grey', 'none'],
        transitionEnd: {
            display: "none"
        }
    }
};
const ButtonAccount = ()=>{
    const { user , resetDataUser  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__/* .userAccContext */ .G);
    const [isClick, setIsClick] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const controlBar = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const { status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_3__.useSession)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        // animation close control panel
        const handleControlPanel = (event)=>{
            const isClick = controlBar.current?.contains(event.target);
            if (!isClick) {
                setIsClick(false);
            }
        };
        document.addEventListener("mousedown", handleControlPanel);
        document.addEventListener("scroll", handleControlPanel);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        console.log(user);
    }, [
        user,
        status
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-fit p-1 rounded-full bg-white flex border-gray-400 hover:shadow-lg   transition-all duration-500 border-2 relative",
        ref: controlBar,
        onClick: ()=>{
            setIsClick(!isClick);
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__.BsList, {
                className: "w-[30px] h-[30px]"
            }),
            user?.Image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: "/api/img/path/" + user.Image,
                className: "w-[30px] h-[30px] rounded-full"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiUserCircle, {
                className: "w-[40px] h-[30px] "
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    variants: variants,
                    animate: isClick ? "show" : "hidden",
                    transition: {
                        duration: 0.5
                    },
                    className: "absolute translate-y-16 w-[250px] h-fit shadow-2xl right-0 rounded-2xl bg-white   overflow-hidden   ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_listButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonAccount);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5209:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_main_filter_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7533);
/* harmony import */ var _components_main_mobile_controlPlaneMobile__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5348);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1705);
/* harmony import */ var _contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8047);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _buttonAccount_ButtonAccount__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(764);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6648);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3565);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3708);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7607);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_main_filter_filter__WEBPACK_IMPORTED_MODULE_1__, _components_main_mobile_controlPlaneMobile__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_5__, _buttonAccount_ButtonAccount__WEBPACK_IMPORTED_MODULE_10__]);
([_components_main_filter_filter__WEBPACK_IMPORTED_MODULE_1__, _components_main_mobile_controlPlaneMobile__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_5__, _buttonAccount_ButtonAccount__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const HeaderForm = ({ children  })=>{
    const { isShow , setIsShow  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_4__/* .mobileContolPanelContext */ .N);
    const { setIsShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_3__/* .filterFormAnimateContext */ .b);
    const { user , resetDataUser  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_14__/* .userAccContext */ .G);
    const { isFilter , setIsFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_11__/* .getHouseContext */ .S);
    const { resetFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_12__/* .filterContext */ .u);
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_16__/* .selectPopoverContext */ .K);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-[80px]"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[80px]  bg-white z-30 fixed top-0",
                id: "header-root",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                        className: "w-full h-[80px] border-b-2 flex justify-center px-[80px]   tablet:hidden mobile:hidden   box-border absolute",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full h-full flex relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    href: "/homepage",
                                    onClick: ()=>{
                                        setIsShowHeader(false);
                                        setIsFilter("main");
                                        resetFilterForm();
                                    },
                                    className: "desktop:flex-1 laptop:mr-7  flex items-center text-red-500   z-30   ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                            src: "/icon.png",
                                            alt: "",
                                            width: 50,
                                            height: 50
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-[30px] w-0 overflow-hidden desktop:w-fit font-semibold",
                                            children: "Olympus"
                                        })
                                    ]
                                }),
                                children,
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex-1 flex items-center justify-end z-30",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            onClick: ()=>{
                                                if (user.UserId !== "none user") {
                                                    router.push("/hosting", undefined, {
                                                        shallow: true
                                                    });
                                                    return;
                                                }
                                                setIsLoginClick(true);
                                            },
                                            className: "rounded-full bg-white h-fit box-content px-4 py-2   hover:bg-slate-300 tablet:hidden mobile:hidden cursor-pointer",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-semibold",
                                                children: "Olympus your home"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            href: "",
                                            className: "rounded-full bg-white box-content p-1 mr-3 hover:bg-slate-300",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_9__.TbWorld, {
                                                className: "w-[30px] h-[30px]"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_buttonAccount_ButtonAccount__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
                        className: "w-full h-fit desktop:hidden laptop:hidden  box-border py-5 tablet:px-[80px]   mobile:px-[20px] mobile:relative tablet:relative   ",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                className: "w-full h-full shadow-xl rounded-full box-border px-4 py-2 flex cursor-pointer",
                                onClick: (event)=>setIsShow(true),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__.FiSearch, {
                                        className: "h-full text-[30px] m-auto"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "h-full w-fit flex flex-col ml-5 box-border",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-semibold",
                                                children: "Anywhere"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-[14px]",
                                                children: "Anyweek & Addguests"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex-1"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-fit h-full   mobile:absolute mobile:top-0 mobile:right-0   tablet:absolute tablet:top-0 tablet:right-0   ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_filter_filter__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    isInvisible: ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_mobile_controlPlaneMobile__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7533:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1705);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6648);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Filter = ({ isInvisible  })=>{
    const buttonFilter = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const { setIsClickOutSide  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__/* .filterFormAnimateContext */ .b);
    const { filterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const { isFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__/* .getHouseContext */ .S);
    const [isEmpty, setIsEmpty] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(true);
    const handleOnClickFilter = async (event)=>{
        window.scrollTo(0, 0);
        setIsClickOutSide(true);
        document.body.style.overflow = "hidden";
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const emptyObjJson = JSON.stringify({
            maxPrice: 250,
            minPrice: 10,
            beds: 0,
            bathRooms: 0,
            typeHouse: [],
            amenities: [],
            hostLanguage: ""
        });
        const filterFormJson = JSON.stringify(filterForm);
        if (filterFormJson === emptyObjJson) {
            setIsEmpty(true);
        } else {
            setIsEmpty(false);
        }
    }, [
        isFilter,
        filterForm
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `w-[150px] h-[80px] flex ${isInvisible} mobile:h-full mobile:w-[100px]
tablet:h-full tablet:w-[100px]
      `,
            onClick: handleOnClickFilter,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `flex m-auto p-3 border-2 rounded-2xl cursor-pointer
          mobile:w-[50px] mobile:h-full mobile:p-0 mobile:border-0
          tablet:w-[50px] tablet:h-full tablet:p-0 tablet:border-0 relative
          ${isEmpty && isFilter !== "main" || isFilter !== "favoriteHouse" ? " border-slate-800" : "border-red-500"}
          `,
                ref: buttonFilter,
                children: [
                    isEmpty && isFilter !== "main" || isFilter !== "favoriteHouse" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        animate: {
                            scale: 1.2
                        },
                        transition: {
                            repeat: Infinity,
                            duration: 1
                        },
                        className: "w-[20px] h-[20px] rounded-full bg-red-400 absolute -right-1 top-4 flex opacity-70 ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-[10px] h-[10px] bg-red-600 rounded-full m-auto"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex w-fit h-[30px] m-auto  mobile:h-full tablet:h-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiOutlineFilter, {
                                className: `w-[30px] h-full m-auto ${isEmpty && isFilter !== "main" || isFilter !== "favoriteHouse" ? "" : "text-red-500"}`
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-fit h-full flex items-center mobile:hidden tablet:hidden ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-semibold",
                                    children: "Filter"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Filter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9445);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);





const MapFilter = ({ keyMapBing  })=>{
    const { address , setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_2__/* .selectPlaceContext */ .t);
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__.whenLoaded.then(()=>{
            const map_ = document.getElementById("Mapfilter");
            if (map_) {
                const map = new Microsoft.Maps.Map(map_, {
                    /* No need to set credentials if already passed in URL */ center: new Microsoft.Maps.Location(16.047079, 108.206230),
                    mapTypeId: Microsoft.Maps.MapTypeId.road,
                    zoom: 16,
                    credentials: keyMapBing,
                    disableScrollWheelZoom: true
                });
                var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), undefined);
                var layer = new Microsoft.Maps.Layer();
                layer.add(pushpin);
                map.layers.insert(layer);
                Microsoft.Maps.loadModule("Microsoft.Maps.AutoSuggest", {
                    callback: ()=>{
                        var options = {
                            maxResults: 5,
                            businessSuggestions: true
                        };
                        var manager = new Microsoft.Maps.AutosuggestManager(options);
                        manager.attachAutosuggest("#searchBox9", "#searchBoxContainer9", (suggestionResult)=>{
                            map.entities.clear();
                            map.setView({
                                bounds: suggestionResult.bestView
                            });
                            var pushpin = new Microsoft.Maps.Pushpin(suggestionResult.location);
                            map.entities.push(pushpin);
                            console.log(suggestionResult);
                            setAddress({
                                ...address,
                                address: {
                                    ...address.address,
                                    ...suggestionResult?.address,
                                    ...suggestionResult?.location
                                }
                            });
                        });
                    }
                });
            }
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative w-full h-[450px]",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-full absolute top-0 left-0 rounded-3xl border-2 border-red-400
      overflow-hidden h-[350px]

      `,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    id: "Mapfilter",
                    className: "relative z-10"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "searchBoxContainer9",
                className: "border-b-2  absolute top-[350px] mt-5 left-0 w-full ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    placeholder: "Search location",
                    id: "searchBox9",
                    type: "text",
                    className: "w-full h-[50px] outline-none text-[25px]"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapFilter);


/***/ }),

/***/ 2287:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _arrAmenities__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7763);
/* harmony import */ var _checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__]);
_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Amenities = ()=>{
    const arrAmenities_ = _arrAmenities__WEBPACK_IMPORTED_MODULE_4__/* .arrAmenities */ ._;
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{}, [
        filterForm.amenities
    ]);
    const handleOnClick = (event, item)=>{
        const arrTemp = Array.isArray(filterForm.amenities) ? filterForm.amenities : [];
        if (arrTemp.includes(item)) {
            const updateArrTemp = arrTemp.filter((item_)=>{
                return item_ !== item;
            });
            setFilterForm({
                ...filterForm,
                amenities: updateArrTemp
            });
            return;
        }
        arrTemp.push(item);
        setFilterForm({
            ...filterForm,
            amenities: arrTemp
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full mb-14",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-fit grid grid-cols-2 gap-y-5 mt-3",
            children: arrAmenities_.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full cursor-pointer",
                    onClick: (event)=>handleOnClick(event, item),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex h-full box-border overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "my-auto",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        // filterForm.amenities.includes(item) ? true : false
                                        isCheckedProps: Array.isArray(filterForm.amenities) ? filterForm.amenities.includes(item) ? true : false : false
                                    }),
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "h-full flex items-center ml-5 text-[19px] ",
                                children: item
                            })
                        ]
                    })
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Amenities);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ arrAmenities)
/* harmony export */ });
const arrAmenities = [
    "Kitchen",
    "Air Conditioning",
    "TV",
    "Fridge",
    "Pool",
    "Washer",
    "Luxury interior",
    "Full interior",
    "Empty interior",
    "Basic interior"
];


/***/ }),

/***/ 2000:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const BedsBathRooms = ()=>{
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const styleButton = "w-[60px] h-[40px] rounded-full border-2 border-slate-600 ml-3 mobile:ml-0";
    const arrButton = [];
    for(let index = 0; index <= 8; index++){
        arrButton.push(index);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-fit",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-fit mb-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Beds"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full flex justify-start mt-2",
                        children: arrButton.map((item, index)=>{
                            if (index == 0) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                                    whileTap: {
                                        scale: 0.6
                                    },
                                    transition: {
                                        duration: 0.5
                                    },
                                    className: `${styleButton.replace("ml-3 ", "")}
                                ${filterForm.beds == 0 ? "bg-black text-white" : ""}
                              `,
                                    onClick: (event)=>setFilterForm({
                                            ...filterForm,
                                            beds: index
                                        }),
                                    children: "Any"
                                }, index);
                            }
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                                whileTap: {
                                    scale: 0.6
                                },
                                transition: {
                                    duration: 0.5
                                },
                                className: ` ${styleButton}
                            ${filterForm.beds == index ? "bg-black text-white" : ""}
                              `,
                                onClick: (event)=>setFilterForm({
                                        ...filterForm,
                                        beds: index
                                    }),
                                children: [
                                    index,
                                    index == 8 ? "+" : ""
                                ]
                            }, index);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-fit mb-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Bathrooms"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full flex justify-start mt-2",
                        children: arrButton.map((item, index)=>{
                            if (index == 0) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                                    whileTap: {
                                        scale: 0.6
                                    },
                                    transition: {
                                        duration: 0.5
                                    },
                                    className: `${styleButton.replace("ml-3", "")}
                                ${filterForm.bathRooms == 0 ? "bg-black text-white" : ""}
                              `,
                                    onClick: (event)=>setFilterForm({
                                            ...filterForm,
                                            bathRooms: index
                                        }),
                                    children: "Any"
                                }, index);
                            }
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                                whileTap: {
                                    scale: 0.6
                                },
                                transition: {
                                    duration: 0.5
                                },
                                className: ` ${styleButton}
                            ${filterForm.bathRooms == index ? "bg-black text-white" : ""}
                              `,
                                onClick: (event)=>setFilterForm({
                                        ...filterForm,
                                        bathRooms: index
                                    }),
                                children: [
                                    index,
                                    index == 8 ? "+" : ""
                                ]
                            }, index);
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BedsBathRooms);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3129:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const CompassFilter = ()=>{
    const compass = [
        "West",
        "South",
        "East",
        "North"
    ];
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const handeOcClick = (item)=>{
        setFilterForm({
            ...filterForm,
            orientation: item
        });
        console.log(filterForm);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-fit border-2 rounded-xl overflow-hidden",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
            className: "select px-0 w-full outline-none text-[25px]  text-center",
            onChange: (event)=>handeOcClick(event.target.value),
            children: compass.map((item, index)=>{
                if (index == 0) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        selected: true,
                        children: item
                    }, index);
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                    children: item
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CompassFilter);


/***/ }),

/***/ 9838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const HostLanguage = ()=>{
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const arrLanguage = [
        "English",
        "Vietnamese"
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-fit",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full grid grid-cols-2",
            children: [
                arrLanguage.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 h-[100px] flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: (event)=>setFilterForm({
                                    ...filterForm,
                                    hostLanguage: item
                                }),
                            className: `w-[80%] h-[70px] m-auto border-2 rounded-xl hover:bg-redIcon hover:text-white
                active:scale-[.8] transition-all duration-500
                ${filterForm.hostLanguage === item ? "bg-redIcon text-white" : ""}`,
                            children: item
                        })
                    }, index);
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-1 h-[100px] flex",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: (event)=>setFilterForm({
                                ...filterForm,
                                hostLanguage: ""
                            }),
                        className: `w-[80%] h-[70px] m-auto border-2 rounded-xl hover:bg-redIcon hover:text-white
                active:scale-[.8] transition-all duration-500
                ${filterForm.hostLanguage === "" ? "bg-redIcon text-white" : ""}`,
                        children: "All"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HostLanguage);


/***/ }),

/***/ 1856:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1817);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rc_slider__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__);





const PriceRange = ()=>{
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const handleOnChange = (value)=>{
        setFilterForm({
            ...filterForm,
            minPrice: value[0],
            maxPrice: value[1]
        });
        const inputMin = document.getElementById("inputMin");
        const inputMax = document.getElementById("inputMax");
        if (inputMin && inputMax) {
            inputMin.value = "";
            inputMax.value = "";
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full border-b-2 pb-10 border-slate-500",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-[100px] flex box-border px-6",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((rc_slider__WEBPACK_IMPORTED_MODULE_2___default()), {
                    range: true,
                    allowCross: false,
                    draggableTrack: true,
                    defaultValue: [
                        10,
                        250
                    ],
                    onChange: handleOnChange,
                    value: [
                        filterForm.minPrice,
                        filterForm.maxPrice
                    ],
                    className: "m-auto ",
                    min: 10,
                    max: 250,
                    trackStyle: {
                        backgroundColor: "black",
                        height: 2
                    },
                    railStyle: {
                        height: 2
                    },
                    handleStyle: {
                        backgroundColor: "#FFFFFF",
                        opacity: 1,
                        border: "1px solid grey",
                        width: 30,
                        height: 30,
                        marginTop: -13
                    }
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[70px] flex mobile:w-full mobile:flex-col mobile:h-fit ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 h-full border-2 rounded-2xl flex items-center mobile:py-3 mobile:mb-5 ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full h-fit flex flex-col box-border px-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Minimum"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full flex",
                                    children: [
                                        "$",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            id: "inputMin",
                                            placeholder: filterForm.minPrice + "",
                                            className: "outline-none overflow-y-hidden",
                                            onChange: (event)=>{
                                                const temp = Number.parseInt(event.target.value);
                                                if (temp < 10 || temp > filterForm.maxPrice || !temp) return;
                                                setFilterForm({
                                                    ...filterForm,
                                                    minPrice: temp
                                                });
                                            }
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[50px] h-full flex mobile:hidden ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineMinus, {
                            className: "m-auto text-[30px]"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 h-full border-2 rounded-2xl flex items-center mobile:py-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full h-fit flex flex-col box-border px-6 ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Maximum"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full flex",
                                    children: [
                                        "$",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            id: "inputMax",
                                            placeholder: filterForm.maxPrice + "",
                                            className: "outline-none overflow-y-hidden",
                                            onChange: (event)=>{
                                                const temp = Number.parseInt(event.target.value);
                                                if (temp > 250 || temp < filterForm.minPrice || !temp) return;
                                                setFilterForm({
                                                    ...filterForm,
                                                    maxPrice: temp
                                                });
                                            }
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PriceRange);


/***/ }),

/***/ 9125:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const variantsPropertyItems = {
    isHover: {
        scale: 1.1
    }
};
const PropertyHouse = ()=>{
    const arrPropertyItems = [
        {
            title: "House",
            imgPath: "https://a0.muscache.com/pictures/4d7580e1-4ab2-4d26-a3d6-97f9555ba8f9.jpg"
        },
        {
            title: "Apartment",
            imgPath: "https://a0.muscache.com/pictures/21cfc7c9-5457-494d-9779-7b0c21d81a25.jpg"
        },
        {
            title: "Guesthouse",
            imgPath: "https://a0.muscache.com/pictures/6f261426-2e47-4c91-8b1a-7a847da2b21b.jpg"
        }
    ];
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "grid grid-cols-3 grid-rows-1 mobile:grid-cols-1 mobile:grid-rows-3",
        children: arrPropertyItems.map((item, index)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full flex justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                    className: `w-[150px] h-[130px] border-2 rounded-2xl box-border p-2 mobile:w-full
              mobile:mb-5
                            ${filterForm.typeHouse.includes(item.title) ? "border-black" : ""}
                          `,
                    variants: variantsPropertyItems,
                    whileTap: {
                        scale: 0.6
                    },
                    transition: {
                        duration: 0.5
                    },
                    onClick: (event)=>{
                        const arrTemp = filterForm.typeHouse;
                        // if typeHouse have exist => remove it
                        if (filterForm.typeHouse.includes(item.title)) {
                            const updateArrTemp = arrTemp.filter((item_)=>{
                                return item_ !== item.title;
                            });
                            setFilterForm({
                                ...filterForm,
                                typeHouse: updateArrTemp
                            });
                            return;
                        }
                        arrTemp.push(item.title);
                        setFilterForm({
                            ...filterForm,
                            typeHouse: arrTemp
                        });
                        return;
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex flex-col h-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: `${item.imgPath}`,
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "m-auto mb-2 ml-2",
                                    children: item.title
                                })
                            })
                        ]
                    })
                }, index)
            }, index);
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PropertyHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 376:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export variantsAmenities */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1705);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6648);
/* harmony import */ var _contexts_isShowPt__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1069);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9445);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _filterFormComponent_amenities_amenities__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2287);
/* harmony import */ var _filterFormComponent_bedsBathrooms__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2000);
/* harmony import */ var _filterFormComponent_hostLanguage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9838);
/* harmony import */ var _filterFormComponent_priceRange__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1856);
/* harmony import */ var _filterFormComponent_property__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9125);
/* harmony import */ var _filterFormComponent_Mapfilter__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3890);
/* harmony import */ var _filterFormComponent_compass__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3129);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_6__, _filterFormComponent_amenities_amenities__WEBPACK_IMPORTED_MODULE_9__, _filterFormComponent_bedsBathrooms__WEBPACK_IMPORTED_MODULE_10__, _filterFormComponent_property__WEBPACK_IMPORTED_MODULE_13__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_6__, _filterFormComponent_amenities_amenities__WEBPACK_IMPORTED_MODULE_9__, _filterFormComponent_bedsBathrooms__WEBPACK_IMPORTED_MODULE_10__, _filterFormComponent_property__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const variantsAmenities = {
    showMore: {
        height: 100
    },
    show: {
        translateY: [
            2000,
            0
        ]
    },
    hidden: {
        translateY: [
            0,
            2000
        ]
    }
};
const FormFilter = ({ keyMapBing  })=>{
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const { setIsFilter , isFilter , setReRenderFilter , reRenderFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__/* .getHouseContext */ .S);
    const { isClickOutSide , setIsClickOutSide  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__/* .filterFormAnimateContext */ .b);
    const { address , setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__/* .selectPlaceContext */ .t);
    const { isShowAllPt  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_isShowPt__WEBPACK_IMPORTED_MODULE_4__/* .IsShowPtContext */ .Y);
    const formFilter = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        const handleOnClickOutSide = (event)=>{
            if (formFilter.current) {
                const formFilter_ = formFilter.current;
                const isClickOutSide_ = formFilter_.contains(event.target);
                if (!isClickOutSide_) {
                    document.body.style.overflow = "scroll";
                    document.body.style.overflowX = "hidden";
                    setIsClickOutSide(false);
                }
            }
        };
        document.addEventListener("mousedown", handleOnClickOutSide);
    }, [
        isShowAllPt
    ]);
    const isEmpty = ()=>{
        const emptyObj = {
            maxPrice: 250,
            minPrice: 10,
            beds: 0,
            bathRooms: 0,
            typeHouse: [],
            amenities: [],
            hostLanguage: "",
            orientation: ""
        };
        const emptyAddress = {
            countryRegion: "",
            locality: "",
            adminDistrict: "",
            countryRegionIso2: "",
            postalCode: "",
            addressLine: "",
            streetName: "",
            formattedAddress: "",
            latitude: 0,
            longitude: 0,
            title: ""
        };
        const emptyObjJson = JSON.stringify(emptyObj);
        const filterFormJson = JSON.stringify(filterForm);
        const emptyAddressJson = JSON.stringify(emptyAddress);
        const addressJson = JSON.stringify(address);
        console.log(filterForm.orientation);
        if (emptyObjJson === filterFormJson && emptyAddressJson === addressJson) return true;
        return false;
    };
    const fetchData = async ()=>{
        setIsClickOutSide(false);
        document.body.style.overflow = "scroll";
        document.body.style.overflowX = "hidden";
        // neu du lieu co ton tai thi la fetch lai du lieu neu khong thi bo qua
        if (!isEmpty()) {
            setIsFilter("noneAuthFilter");
            setReRenderFilter(reRenderFilter + 1);
            return;
        } else {
            setIsFilter("main");
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        console.log(filterForm);
    }, [
        filterForm
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.AnimatePresence, {
            initial: false,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.div, {
                variants: variantsAmenities,
                animate: isClickOutSide ? "show" : "hidden",
                transition: {
                    duration: 0.5,
                    type: "tween"
                },
                className: "w-[800px] h-[calc(100vh-50px)] bg-white m-auto rounded-3xl   flex flex-col   mobile:mt-0 mobile:rounded-none mobile:w-screen mobile:h-screen   tablet:h-[calc(100vh-90px)] tablet:mt-[10px] z-30   ",
                ref: formFilter,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: " flex-2 w-full border-b-2 flex relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "m-auto font-semibold text-[23px]",
                                children: "Filter"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.button, {
                                className: "absolute w-[70px] h-full flex desktop:hidden laptop:hidden",
                                onClick: (event)=>setIsClickOutSide(false),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-fit h-full m-auto",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_8__.GrClose, {
                                        className: "text-[30px]"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex-[9] h-[75vh] overflow-x-hidden  overflow-scroll box-border p-10",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full h-fit mb-5",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "w-full h-fit flex flex-col",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-bold text-[25px]",
                                                children: "Price range"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-[18px]",
                                                children: "The average nightly price is $79, not including fees or taxes."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_priceRange__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col  pb-3",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[25px] mb-5",
                                            children: "Map"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_Mapfilter__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                            keyMapBing: keyMapBing
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col  pb-3",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[25px] mb-5",
                                            children: "Beds & Bathrooms"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_bedsBathrooms__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mb-5 border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[25px] mb-5",
                                            children: "Property type"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_property__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mb-5 border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[25px] mb-5",
                                            children: "Amenities"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_amenities_amenities__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mb-5 border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[25px] mb-5",
                                            children: "Orientation"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_compass__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mb-5 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[25px] mb-5",
                                            children: "Host language"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_hostLanguage__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full border-t-2 flex items-center flex-2 py-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex justify-start",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "m-auto underline cursor-pointer",
                                    onClick: (event)=>{
                                        const filterFormTemp = {
                                            ...filterForm,
                                            maxPrice: 250,
                                            minPrice: 10,
                                            beds: 0,
                                            bathRooms: 0,
                                            typeHouse: [],
                                            amenities: [],
                                            hostLanguage: ""
                                        };
                                        const addressTemp = {
                                            countryRegion: "",
                                            locality: "",
                                            adminDistrict: "",
                                            countryRegionIso2: "",
                                            postalCode: "",
                                            addressLine: "",
                                            streetName: "",
                                            formattedAddress: "",
                                            latitude: 0,
                                            longitude: 0,
                                            title: ""
                                        };
                                        setFilterForm(filterFormTemp);
                                        setAddress({
                                            ...address,
                                            address: {
                                                ...address.address,
                                                ...addressTemp
                                            }
                                        });
                                    },
                                    children: "Clear all"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.button, {
                                    className: "w-[200px] h-[40px] rounded-lg border-2",
                                    whileHover: {
                                        backgroundColor: "rgba(255, 56, 92, 0.8)",
                                        color: "white"
                                    },
                                    onClick: fetchData,
                                    whileTap: {
                                        scale: 0.9
                                    },
                                    children: "Submit"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormFilter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5348:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_rootMaskHeader_controlPlan_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8673);
/* harmony import */ var _components_rootMaskHeader_controlPlan_controlBar_popOver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4983);
/* harmony import */ var _contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8047);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_rootMaskHeader_controlPlan_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
([_components_rootMaskHeader_controlPlan_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const variants = {
    show: {
        visibility: [
            "hidden",
            "visible"
        ],
        top: [
            30,
            0
        ],
        opacity: [
            0,
            1
        ]
    },
    hidden: {
        top: [
            0,
            30
        ],
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            visibility: "hidden"
        }
    }
};
const ControlPlanMobile = ()=>{
    const { isShow , setIsShow  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_3__/* .mobileContolPanelContext */ .N);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.AnimatePresence, {
        initial: false,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
            className: "relative z-40 ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                className: "fixed right-0 top-0 w-screen h-screen bg-white  flex flex-col",
                variants: variants,
                animate: isShow ? "show" : "hidden",
                transition: {
                    type: "tween",
                    duration: 0.5
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        className: "flex-[0.5] ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.button, {
                            className: "h-full w-[100px] overflow-hidden ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_6__.IoIosArrowRoundBack, {
                                className: "w-full text-[40px] font-bold  stroke-[50px] fill-red-500   text-red-500 ",
                                onClick: (event)=>setIsShow(false)
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        className: "flex-1 box-border px-[80px] mobile:px-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_rootMaskHeader_controlPlan_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        className: "flex-[7] box-border w-full mb-[70px] px-[80px] py-5 mobile:px-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                            className: "w-full h-full relative border-2 rounded-2xl mobile:px-0  overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_rootMaskHeader_controlPlan_controlBar_popOver__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ControlPlanMobile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8673:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_searchBox_searchBox__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1539);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7607);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1705);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6648);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9445);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6197);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5641);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_7__, react_hook_form__WEBPACK_IMPORTED_MODULE_10__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_7__, react_hook_form__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const ControlBar = ()=>{
    const [submit, setSubmit] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_2__/* .selectPopoverContext */ .K);
    const { address  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__/* .selectPlaceContext */ .t);
    // const { isFilter, setIsFilter } = useContext(getHouseContext;
    const { setIsFilter , isFilter , setReRenderFilter , reRenderFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_4__/* .getHouseContext */ .S);
    const { setIsShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_3__/* .filterFormAnimateContext */ .b);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const isEmpty = ()=>{
        if (!address.address.formattedAddress && !address.guest.adults && !address.guest.childrens && !address.guest.infants) {
            return true;
        } else {
            return false;
        }
    };
    const fetchData = (event)=>{
        if (router.asPath !== "/homepage") {
            setIsShowHeader(false);
            router.push("/homepage", undefined, {
                shallow: true
            });
        }
        if (isEmpty()) {
            return;
        } else {
            setIsShowHeader(false);
            setIsFilter("noneAuthFilter");
            setReRenderFilter(reRenderFilter + 1);
            return;
        }
    };
    const onSelected = (event)=>{
        setSelected(event.currentTarget.id);
    };
    // validate while submit
    const onSubmit = (data)=>{
        setSubmit(true);
        handleCreate(data);
    };
    // form validate
    const { register , handleSubmit , setValue , formState: { errors  } , watch  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_10__.useForm)({
        defaultValues: {}
    });
    const handleCreate = async (data)=>{};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-full flex relative mobile:text-[12px] mobile:flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-[0.6] flex mobile:text-[20px]",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-col flex m-auto w-full rounded-full box-border pl-7 z-10 relative mobile:pl-0 ",
                    id: "where",
                    onClick: onSelected,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "Where"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            action: "",
                            onSubmit: handleSubmit(onSubmit),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_searchBox_searchBox__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    styleBox: null
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: errors.address && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: errors.address.message
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 flex mobile:flex-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 flex ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col m-auto flex-1 box-border pl-3 z-10 relative mobile:pl-0 mobile:text-[20px] mobile:mt-5 ",
                            id: "checkin",
                            onClick: onSelected,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Appointment schedule"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-[12px]",
                                    children: (0,date_fns__WEBPACK_IMPORTED_MODULE_6__.format)(address.checkInDay, "eeee, ddMMM")
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 flex mobile:flex-col",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex-1 flex flex-col m-auto box-border pl-3 z-10 relative mobile:text-[20px] mobile:pl-0 mobile:mt-5 mobile:ml-0 ",
                                id: "who",
                                onClick: onSelected,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Who"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            address.guest.adults != 0 || address.guest.childrens != 0 ? address.guest.adults + address.guest.childrens + " guests" : "Add guests ",
                                            address.guest.infants != 0 && ", " + address.guest.infants + " infants"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex box-border p-3 w-full relative z-10 mobile:py-5 tablet:py-5 ",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.div, {
                                    whileTap: {
                                        scale: 0.8
                                    },
                                    className: "rounded-full w-full h-full bg-red-500 flex ",
                                    id: "btn-search-header",
                                    onClick: fetchData,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_11__.BiSearch, {
                                            className: "w-[30px] h-[30px] m-auto text-white tablet:w-[20px] tablet:h-[20px] mobile:w-[20px] mobile:h-[20px]"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-white font-semibold m-auto ml-0 tablet:hidden mobile:hidden",
                                            children: "Search"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ControlBar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4983:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7607);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _popOverDetail_checkIn_Out__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4141);
/* harmony import */ var _popOverDetail_who__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(779);





const Popover = ()=>{
    const { selected , setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_1__/* .selectPopoverContext */ .K);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "absolute tablet:w-full w-[850px] h-[480px] top-24 pointer-events-none mobile:w-full tablet:h-full mobile:h-full tablet:top-0 mobile:top-0 ",
        id: "root-popup",
        onClick: (event)=>event.stopPropagation(),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full h-full flex",
            children: [
                selected === "who" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popOverDetail_who__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    styleWho: null
                }),
                selected === "checkin" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popOverDetail_checkIn_Out__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    styleHorizontal: " mobile:hidden",
                    styleVerical: " laptop:hidden desktop:hidden tablet:hidden"
                }),
                selected === "checkout" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popOverDetail_checkIn_Out__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    styleHorizontal: "tablet:hidden mobile:hidden",
                    styleVerical: " laptop:hidden desktop:hidden tablet:hidden"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Popover);


/***/ }),

/***/ 7537:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7607);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1705);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _controlBar_controlBar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8673);
/* harmony import */ var _controlBar_popOver__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4983);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__, _controlBar_controlBar__WEBPACK_IMPORTED_MODULE_6__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_3__, _controlBar_controlBar__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const variants = {
    controlHeaderShow: {
        display: "flex",
        opacity: [
            0,
            1
        ],
        transition: {
            delay: 0.2
        }
    },
    controlHeaderHidden: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        }
    },
    slideDownControlBar: {
        scale: [
            1,
            1.2
        ],
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        },
        transition: {
            type: "tween",
            duration: 0.2,
            ease: "easeOut"
        }
    },
    slideUpControlBar: {
        scale: [
            1.2,
            1
        ],
        opacity: [
            0,
            1
        ],
        display: "flex",
        transition: {
            delay: 0.2
        }
    },
    showUpLinkControl: {
        opacity: [
            0,
            1
        ],
        display: "flex"
    },
    hiddenLinkControl: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        },
        transition: {
            duration: 0.2
        }
    }
};
const ControlPlan = ()=>{
    const { isShow , setIsShow , setIsShowHeader , isShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__/* .filterFormAnimateContext */ .b);
    const [isFirstLoading, setIsFirstLoading] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(true);
    const refHeader = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const refHeaderControl = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const arrLink = [
        {
            ref: "",
            title: "Stays"
        },
        {
            ref: "",
            title: "Experiences"
        },
        {
            ref: "",
            title: "Online Experiences"
        }
    ];
    const { setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_1__/* .selectPopoverContext */ .K);
    const onSelected = (popoverId)=>{
        setSelected(popoverId);
    };
    // animate by hand again :")))"
    const handleOnScaleDown = (event)=>{
        setIsShowHeader(true);
        const inputElement = document.getElementById("searchBox");
        if (inputElement) {
            inputElement.focus();
        }
    };
    const isClickOutSide = (event)=>{
        const isClickHeaderRoot = document.getElementById("header-root")?.contains(event.target);
        const isClickHeaderControl = refHeaderControl.current?.contains(event.target);
        if (!isClickHeaderRoot && !isClickHeaderControl) {
            setIsShowHeader(false);
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        document.addEventListener("click", isClickOutSide);
        document.addEventListener("scroll", isClickOutSide);
        setIsFirstLoading(false);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{}, [
        isShowHeader
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[550px] box-border p-4 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full h-full",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex overflow-hidden mb-1 ",
                            id: "link",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                variants: variants,
                                animate: isShowHeader ? "showUpLinkControl" : "hiddenLinkControl",
                                className: "m-auto mt-3 flex w-full justify-between",
                                children: arrLink.map((item, index)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        href: `${item.ref}`,
                                        className: " relative   before:bottom-0 before:h-[2px]  before:w-0 before:absolute   before:bg-slate-500 hover:before:w-full before:transition-all   before:duration-200   ",
                                        children: item.title
                                    }, index);
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                            ref: refHeader,
                            variants: variants,
                            animate: isShowHeader ? "slideDownControlBar" : "slideUpControlBar",
                            className: "w-full h-full box-border px-1 flex items-center   rounded-full border-slate-400 bg-[#f05123] text-slate-100 font-semibold   ",
                            id: "scaleUp",
                            onClick: handleOnScaleDown,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "flex-1 h-full",
                                    id: "header-control_bar-list-index-1",
                                    onClick: (event)=>{
                                        onSelected("where");
                                    },
                                    children: "Search Location"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "flex-1 border-x-2 border-slate-400 h-full",
                                    id: "header-control_bar-list-index-2",
                                    onClick: (event)=>onSelected("checkin"),
                                    children: "Schedule"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "flex-1 h-full",
                                    id: "header-control_bar-list-index-4",
                                    onClick: (event)=>onSelected("who"),
                                    children: "Guests"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                variants: variants,
                animate: isShowHeader ? "controlHeaderShow" : "controlHeaderHidden",
                ref: refHeaderControl,
                className: "absolute w-full h-[80px] mt-[80px] bg-white   box-border z-20   after:h-full after:left-0 after:top-0 after:absolute   after:w-[calc(100vw-(100vw-100%)/2)] after:bg-white after:-z-10      before:h-full before:right-0 before:top-0 before:absolute   before:w-[calc(100vw-(100vw-100%)/2)] before:bg-white before:-z-10   ",
                id: "ControlHeader",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-[850px] tablet:w-full h-[90%] box-border rounded-full m-auto flex   text-[15px] transition-all duration-300 border-2   cursor-pointer   ",
                    id: "controlBar",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_controlBar_popOver__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ControlPlan);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8248:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_loginPanel_LoginPanel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6905);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7607);
/* harmony import */ var _contexts_placeList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3903);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _controlPlan_controlPlan__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7537);
/* harmony import */ var _headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5209);
/* harmony import */ var _main_filter_formFilter_formFilter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(376);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6197);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1705);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_loginPanel_LoginPanel__WEBPACK_IMPORTED_MODULE_1__, _controlPlan_controlPlan__WEBPACK_IMPORTED_MODULE_5__, _headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_6__, _main_filter_formFilter_formFilter__WEBPACK_IMPORTED_MODULE_7__, framer_motion__WEBPACK_IMPORTED_MODULE_8__]);
([_components_loginPanel_LoginPanel__WEBPACK_IMPORTED_MODULE_1__, _controlPlan_controlPlan__WEBPACK_IMPORTED_MODULE_5__, _headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_6__, _main_filter_formFilter_formFilter__WEBPACK_IMPORTED_MODULE_7__, framer_motion__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const variants = {
    show: {
        display: "flex",
        opacity: [
            0,
            1
        ]
    },
    hidden: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        }
    }
};
const HeaderMain = ({ keyMapBing  })=>{
    const { setPlaceList  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_placeList__WEBPACK_IMPORTED_MODULE_3__/* .placeListContext */ .P);
    const { isLoginClick , setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_2__/* .selectPopoverContext */ .K);
    const { isClickOutSide , setIsClickOutSide , isShowHeader , setIsShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_9__/* .filterFormAnimateContext */ .b);
    const [isFirstLoading, setIsFirstLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    const loginPanel = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const mask = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const handleOnMask = (event)=>{
        setPlaceList([]);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        // animate de mo popup login
        const handleOnclickLogin = (event)=>{
            const isClick = loginPanel.current?.contains(event.target);
            if (!isClick && isLoginClick) {
                mask.current?.classList.remove("animate-transparentAnimateLogin2");
                loginPanel.current?.classList.remove("animate-slideUpLogin");
                mask.current?.classList.add("animate-transparentAnimateLoginReverse2");
                loginPanel.current?.classList.add("animate-slideDownLogin");
                setIsLoginClick(false);
                return;
            }
        };
        // animate de dong popup login
        const handleOnClickLogin2 = (event)=>{
            if (isFirstLoading) return;
            mask.current?.classList.remove("animate-transparentAnimateLogin2");
            loginPanel.current?.classList.remove("animate-slideUpLogin");
            mask.current?.classList.add("animate-transparentAnimateLoginReverse2");
            loginPanel.current?.classList.add("animate-slideDownLogin");
            setIsLoginClick(false);
        };
        // animate for dynamic event
        const handleIsClick = ()=>{
            if (isLoginClick) {
                mask.current?.classList.remove("animate-transparentAnimateLoginReverse2");
                loginPanel.current?.classList.remove("animate-slideDownLogin");
                mask.current?.classList.add("animate-transparentAnimateLogin2");
                loginPanel.current?.classList.add("animate-slideUpLogin");
                return;
            } else if (!isLoginClick && !isFirstLoading) {
                mask.current?.classList.remove("animate-transparentAnimateLogin2");
                loginPanel.current?.classList.remove("animate-slideUpLogin");
                mask.current?.classList.add("animate-transparentAnimateLoginReverse2");
                loginPanel.current?.classList.add("animate-slideDownLogin");
            }
        };
        document.addEventListener("mousedown", handleOnclickLogin);
        document.addEventListener("scroll", handleOnClickLogin2);
        handleIsClick();
        setIsFirstLoading(false);
    }, [
        isLoginClick
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        isShowHeader
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        isClickOutSide
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.div, {
                    variants: variants,
                    animate: isClickOutSide ? "show" : "hidden",
                    transition: {
                        duration: 0.5
                    },
                    className: "w-screen h-screen bg-mask absolute z-40   overflow-hidden ",
                    id: "maskFilter",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_main_filter_formFilter_formFilter__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        keyMapBing: keyMapBing
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-screen h-screen fixed top-0 left-0 transition-all duration-500 bg-mask z-40 flex   overflow-hidden invisible   ",
                ref: mask,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-full flex",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit  h-fit bg-white m-auto rounded-3xl",
                        ref: loginPanel,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loginPanel_LoginPanel__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.div, {
                variants: variants,
                animate: isShowHeader ? "show" : "hidden",
                className: "w-screen h-screen opacity-0 bg-mask z-20 fixed top-0 left-0",
                id: "mask",
                onClick: handleOnMask
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_controlPlan_controlPlan__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderMain);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;