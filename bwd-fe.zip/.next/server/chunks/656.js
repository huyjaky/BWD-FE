exports.id = 656;
exports.ids = [656];
exports.modules = {

/***/ 8903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



(0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__.initializeSSR)();
const MapEach = ({ latitude , longitude , zoom , keyMapBing , formattedAddress , idMap , style  })=>{
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__.initializeSSR)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__.whenLoaded.then(()=>{
            const map_ = document.getElementById("MapEach" + idMap);
            if (map_) {
                var map = new Microsoft.Maps.Map(map_, {
                    /* No need to set credentials if already passed in URL */ center: new Microsoft.Maps.Location(latitude, longitude),
                    mapTypeId: Microsoft.Maps.MapTypeId.road,
                    zoom: zoom,
                    credentials: keyMapBing
                });
                var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), undefined);
                var layer = new Microsoft.Maps.Layer();
                layer.add(pushpin);
                map.layers.insert(layer);
            }
        });
    }, [
        latitude,
        longitude,
        zoom
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-[30px]",
                children: formattedAddress
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-full rounded-3xl  border-2 border-red-400 overflow-hidden ${style}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    id: "MapEach" + idMap,
                    className: "relative z-10"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapEach);


/***/ }),

/***/ 391:
/***/ (() => {



/***/ }),

/***/ 1137:
/***/ (() => {



/***/ })

};
;