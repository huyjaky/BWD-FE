"use strict";
exports.id = 715;
exports.ids = [715];
exports.modules = {

/***/ 6648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ getHouseContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const getHouseDataDefault = {
    isFilter: "main",
    setIsFilter: ()=>{},
    reRenderFilter: 1,
    setReRenderFilter: ()=>{}
};
const getHouseContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(getHouseDataDefault);
const GetHouseProvider = ({ children  })=>{
    const [isFilter, setIsFilter_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(getHouseDataDefault.isFilter);
    const [reRenderFilter, setReRenderFilter_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(getHouseDataDefault.reRenderFilter);
    const setIsFilter = (payload)=>setIsFilter_(payload);
    const setReRenderFilter = (payload)=>setReRenderFilter_(payload);
    const getHouseDynamicData = {
        isFilter,
        setIsFilter,
        reRenderFilter,
        setReRenderFilter
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(getHouseContext.Provider, {
        value: getHouseDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetHouseProvider);


/***/ }),

/***/ 3708:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ userAccContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const userAccDefaultData = {
    user: {
        UserId: "",
        UserName: "",
        Password: "",
        Birth: new Date(),
        Gmail: "",
        Sex: "",
        Decentralization: "",
        PersonCode: "",
        CustomerType: "",
        Image: "",
        error: "",
        Phone: ""
    },
    setUser: ()=>{},
    resetDataUser: ()=>{}
};
const userAccContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(userAccDefaultData);
const UserAccProvider = ({ children  })=>{
    const [user, setUser_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(userAccDefaultData.user);
    const setUser = (payload)=>setUser_(payload);
    const resetDataUser = ()=>setUser_(userAccDefaultData.user);
    const userAccDynamicData = {
        user,
        setUser,
        resetDataUser
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(userAccContext.Provider, {
        value: userAccDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserAccProvider);


/***/ })

};
;