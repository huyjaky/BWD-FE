"use strict";
exports.id = 471;
exports.ids = [471];
exports.modules = {

/***/ 1069:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ IsShowPtContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const isShowPtDataDefault = {
    isShowAllPt: false,
    setIsShowAllPt: ()=>{}
};
const IsShowPtContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(isShowPtDataDefault);
const IsShowPtProvider = ({ children  })=>{
    const [isShowAllPt, setIsShowAllPt_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(isShowPtDataDefault.isShowAllPt);
    const setIsShowAllPt = (payload)=>setIsShowAllPt_(payload);
    const isShowPtDynamicData = {
        isShowAllPt,
        setIsShowAllPt
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(IsShowPtContext.Provider, {
        value: isShowPtDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IsShowPtProvider);


/***/ }),

/***/ 8047:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ mobileContolPanelContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const mobileContolPanelDataDefault = {
    isShow: false,
    setIsShow: ()=>{}
};
const mobileContolPanelContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(mobileContolPanelDataDefault);
const MobileContolPanelProvider = ({ children  })=>{
    const [isShow, setIsShow_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(mobileContolPanelDataDefault.isShow);
    const setIsShow = (payload)=>setIsShow_(payload);
    const mobileContolPanelDynamicData = {
        isShow,
        setIsShow
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(mobileContolPanelContext.Provider, {
        value: mobileContolPanelDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MobileContolPanelProvider);


/***/ }),

/***/ 3903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ placeListContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const placeListDefault = {
    placeList: [],
    isLoading: false,
    isFetch: true,
    setIsLoading: ()=>{},
    setPlaceList: ()=>{},
    setIsFetch: ()=>{}
};
const placeListContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(placeListDefault);
const PlaceListProvider = ({ children  })=>{
    const [placeList, setPlaceList_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(placeListDefault.placeList);
    const [isLoading, setIsLoading_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(placeListDefault.isLoading);
    const [isFetch, setIsFetch_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(placeListDefault.isFetch);
    const setIsLoading = (IsLoading)=>setIsLoading_(IsLoading);
    const setPlaceList = (placeList)=>setPlaceList_(placeList);
    const setIsFetch = (isFetch)=>setIsFetch_(isFetch);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{}, [
        setPlaceList
    ]);
    const placeListDynamicData = {
        placeList,
        setPlaceList,
        isLoading,
        setIsLoading,
        isFetch,
        setIsFetch
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(placeListContext.Provider, {
        value: placeListDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlaceListProvider);


/***/ })

};
;