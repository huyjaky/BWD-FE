"use strict";
exports.id = 565;
exports.ids = [565];
exports.modules = {

/***/ 3565:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "u": () => (/* binding */ filterContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const filterDataDefault = {
    filterForm: {
        maxPrice: 250,
        minPrice: 10,
        beds: 0,
        bathRooms: 0,
        typeHouse: [],
        amenities: [],
        hostLanguage: "",
        orientation: ""
    },
    emptyFilterForm: {
        maxPrice: 250,
        minPrice: 10,
        beds: 0,
        bathRooms: 0,
        typeHouse: [],
        amenities: [],
        hostLanguage: "",
        orientation: ""
    },
    setFilterForm: (payload)=>{},
    resetFilterForm: ()=>{},
    isEmpty: ()=>true
};
const filterContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(filterDataDefault);
const FilterProvider = ({ children  })=>{
    const [filterForm, setFilterForm_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(filterDataDefault.filterForm);
    const [emptyFilterForm, setEmptyFilterForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(filterDataDefault.filterForm);
    const setFilterForm = (payload)=>setFilterForm_(payload);
    const resetFilterForm = ()=>setFilterForm_(filterDataDefault.filterForm);
    const isEmpty = ()=>{
        const emptyObjJson = JSON.stringify(filterDataDefault.filterForm);
        const filterFormJson = JSON.stringify(filterForm);
        if (filterFormJson === emptyObjJson) {
            return true;
        } else {
            return false;
        }
    };
    const filterDynamicData = {
        filterForm,
        setFilterForm,
        resetFilterForm,
        isEmpty,
        emptyFilterForm
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(filterContext.Provider, {
        value: filterDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilterProvider);


/***/ })

};
;