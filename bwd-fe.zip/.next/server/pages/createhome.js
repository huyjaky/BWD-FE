(() => {
var exports = {};
exports.id = 29;
exports.ids = [29,748];
exports.modules = {

/***/ 8472:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Montserrat_097b2d', '__Montserrat_Fallback_097b2d'","fontStyle":"normal"},
	"className": "__className_097b2d",
	"variable": "__variable_097b2d"
};


/***/ }),

/***/ 8388:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/signature.50f358ec.jpg","height":227,"width":688,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAMACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAf/aAAwDAQACEAMQAAAAigv/xAAcEAABAwUAAAAAAAAAAAAAAAACAAESFTEyM0H/2gAIAQEAAT8AcRo+I6ZW6v/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z","blurWidth":8,"blurHeight":3});

/***/ }),

/***/ 6426:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ButtonHeader = ({ content  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "px-[16px] border-[1px] border-colorButtonHeader bg-transparent rounded-[32px] h-[40px] font-semibold hover:border-black ease-in duration-200 ml-[16px]",
        children: content
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonHeader);


/***/ }),

/***/ 1290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ChooDesPl = ({ title , icon , type , selected , setselected , selectedMany =[] , setselectedMany  })=>{
    const handleOnclick = ()=>{
        if (type === "select1") {
            setselected(title);
            if (selected == title) {
                setselected("");
            }
        } else if (type === "selectMany") {
            setselectedMany([
                ...selectedMany,
                title
            ]);
            if (selectedMany.includes(title)) {
                setselectedMany(selectedMany.filter((selected)=>selected !== title));
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        className: "rounded-[8px] border-[2px] border-colorButtonHeader px-[14px] pt-[9px] w-[100%] h-[105px] active:scale-[0.95] flex flex-col ease-in duration-200 mobile:w-[40vw] hover:border-[2px] hover:border-black ",
        style: {
            backgroundColor: title === selected || selectedMany.includes(title) ? "#F7F7F7" : "",
            borderColor: title === selected || selectedMany.includes(title) ? "black" : ""
        },
        onClick: handleOnclick,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[45px] h-[45px] mb-2",
                children: icon
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "font-semibold leading-5 text-left",
                children: title
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChooDesPl);


/***/ }),

/***/ 5731:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ChooTypeHo = ({ name , icon , description , selected , setselected  })=>{
    const handleOnclick = ()=>{
        setselected(name);
        if (selected == name) {
            setselected("");
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "w-[100%] mb-3 border-[2px] border-[rgb(221,221,221) rounded-[12px] hover:border-[2px] hover:border-black transition active:scale-[0.95]",
        style: {
            backgroundColor: name === selected ? "#F7F7F7" : "",
            borderColor: name === selected ? "black" : ""
        },
        onClick: handleOnclick,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "p-[24px] flex justify-between",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "text-start",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-[18px] font-semibold",
                            children: name
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-[14px] mt-[4px] text-[rgb(113,113,113)]",
                            children: description
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-[10%]",
                    children: icon
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChooTypeHo);


/***/ }),

/***/ 3722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7327);
/* harmony import */ var _components_searchBox_searchBox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1539);
/* harmony import */ var _components_main_showHouse_mapEach__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8903);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9445);






const Map = ({ keyMapBing  })=>{
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_2__/* .newHouseContext */ .y);
    const { address , setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__/* .selectPlaceContext */ .t);
    const [address_, setAddress_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.address.addressLine);
    function addressValueHandler(event) {
        const addressValue = event.currentTarget.value;
        setAddress_((prev)=>addressValue);
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP4",
            payload: address.address
        });
    }, [
        address
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // setAddress(state.address)
        console.log(state.address);
    }, [
        state
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-[100%] h-fit overflow-hidden rounded-2xl relative px-3 py-2",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-fit relative",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_searchBox_searchBox__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    styleBox: "w-full rounded-2xl h-[70px] px-2 shadow-xl"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-[400px] mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_mapEach__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    keyMapBing: keyMapBing,
                    latitude: address.address.latitude,
                    longitude: address.address.longitude,
                    zoom: address.address.formattedAddress ? 15 : 0,
                    idMap: "2",
                    formattedAddress: address.address.formattedAddress,
                    style: "h-[500px]"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Map);


/***/ }),

/***/ 9652:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const buttonVariants = {
    initial: {
        scale: 1,
        textShadow: "none",
        boxShadow: "none",
        transition: {
            duration: 1
        }
    },
    hover: {
        scale: [
            1,
            1.1,
            1,
            1.1,
            1
        ],
        textShadow: "0px 0px 8px rgb(255,255,255)",
        boxShadow: "0px 0px 8px rgb(255 ,255,255)",
        transition: {
            duration: 1
        }
    }
};
const ProgressBar = ({ steps , currentStep , handleBackStep , handleNextStep  })=>{
    const [isValidated, setValidated] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_3__/* .newHouseContext */ .y);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (currentStep == 10) {
            if (state[steps[currentStep - 1].data].length > 0) {
                setValidated(true);
            } else {
                setValidated(false);
            }
        } else if (steps[currentStep - 1].data) {
            if (state[steps[currentStep - 1].data] && typeof state[steps[currentStep - 1].data] !== "object") {
                setValidated(true);
            } else if (typeof state[steps[currentStep - 1].data] === "object") {
                if (currentStep === 7 || currentStep === 17) {
                    setValidated(true);
                } else {
                    const object = state[steps[currentStep - 1].data];
                    for(const key in object){
                        if (object[key]) {
                            setValidated(true);
                            break;
                        } else {
                            setValidated(false);
                        }
                    }
                }
            } else {
                setValidated(false);
            }
        } else {
            setValidated(true);
        }
    }, [
        currentStep,
        state
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "fixed bottom-0 left-0 w-full h-[80px] items-center bg-white z-40",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full bg-gray-200  h-2 ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    className: "bg-black h-2 ",
                    style: {
                        borderRadius: " 0 10px 10px 0"
                    },
                    animate: {
                        width: `${currentStep / steps.length * 100}%`
                    },
                    transition: {
                        duration: 1
                    }
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center justify-between mt-2 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                        variants: buttonVariants,
                        initial: "initial",
                        whileHover: "hover",
                        className: "py-4 px-8 bg-whiter text-[#222222] font-semibold text-[16px] rounded-xl inline ml-8 underline",
                        onClick: handleBackStep,
                        children: "Back"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                        variants: buttonVariants,
                        initial: "initial",
                        whileHover: "hover",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                            className: `py-4 px-8 text-white font-semibold text-[16px] rounded-xl inline mr- ${isValidated ? "bg-black" : "bg-gray-600 "}`,
                            onClick: handleNextStep,
                            disabled: !isValidated,
                            children: "Next"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProgressBar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4103:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ButtonHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6426);
/* harmony import */ var _public_assets_Logo_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2834);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_5__]);
framer_motion__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function Header() {
    const ImgVariants = {
        hidden: {
            opacity: 0,
            rotate: -180
        },
        visible: {
            opacity: 1,
            rotate: 0,
            transition: {
                duration: 2
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "px-[48px] pt-[32px] flex justify-between",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                href: "/homepage",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                    variants: ImgVariants,
                    initial: "hidden",
                    animate: "visible",
                    className: "cursor-pointer",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                        width: 80,
                        className: "",
                        src: _public_assets_Logo_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                        alt: " Logo"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                    href: "/homepage",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                        initial: {
                            opacity: 0,
                            x: -30
                        },
                        animate: {
                            opacity: 1,
                            x: 0
                        },
                        transition: {
                            type: "spring",
                            stiffness: 35
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ButtonHeader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            content: "Save & exit"
                        })
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2303:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step10Home)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2223);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4009);
/* harmony import */ var _ChooDesPl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1290);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_5__]);
([react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function Step10Home() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_6__/* .newHouseContext */ .y);
    // set Active thì để ngoài như này kh đc để trong lớp con
    // để trong lớp con thì khi render ra mỗi class sẽ có 1 state
    const [selectedMany, setselectedMany] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.amenities);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP10",
            payload: selectedMany
        });
    }, [
        selectedMany
    ]);
    const type = "selectMany";
    const [refButton, inViewButton] = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__.useInView)({
        triggerOnce: true,
        threshold: 0.01 // Ngưỡng nhìn thấy (tỷ lệ của phần tử nằm trong khung nhìn)
    });
    const [refButton2, inViewButton2] = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__.useInView)({
        triggerOnce: true,
        threshold: 0.01 // Ngưỡng nhìn thấy (tỷ lệ của phần tử nằm trong khung nhìn)
    });
    const [ref2, inView2] = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_3__.useInView)({
        triggerOnce: true,
        threshold: 0.02 // Ngưỡng nhìn thấy (tỷ lệ của phần tử nằm trong khung nhìn)
    });
    const animationVariants = {
        hidden: {
            opacity: 0,
            y: 20
        },
        visible: {
            opacity: 1,
            y: 0
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px] mobile:px-0  ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[60%] ml-auto mr-auto pl-[70px] mb-[150px] mobile:pl-0 laptop:w-[90%] tablet:w-[90%] mobile:w-full ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col px-10 w-[100%]",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-[32px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-[32px] h-[82px] tablet:mb-[62px] mobile:mb-[100px] w-[100%] ml-auto mr-auto ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.h1, {
                                        initial: {
                                            opacity: 0,
                                            y: -30
                                        },
                                        animate: {
                                            opacity: 1,
                                            y: 0
                                        },
                                        transition: {
                                            type: "spring",
                                            stiffness: 35,
                                            delay: 0.2
                                        },
                                        className: "text-[32px] font-semibold w-[100%] leading-10 mb-3",
                                        children: "Tell guests what your place has to offer"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.p, {
                                        initial: {
                                            opacity: 0,
                                            y: 30
                                        },
                                        animate: {
                                            opacity: 1,
                                            y: 0
                                        },
                                        transition: {
                                            type: "spring",
                                            stiffness: 35,
                                            delay: 0.2
                                        },
                                        className: "text-[18px] text-[#717171]",
                                        children: "You can add more amenities after you publish your listing."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid grid-cols-3 gap-[15px] w-[110%] laptop:grid-cols-2 tablet:grid-cols-2 mobile:grid-cols-2 ",
                                children: _utils_constant__WEBPACK_IMPORTED_MODULE_2__/* .categoriesStep10.map */ .Ei.map((category, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                        variants: animationVariants,
                                        initial: "hidden",
                                        animate: "visible",
                                        transition: {
                                            type: "spring",
                                            stiffness: 35,
                                            delay: 0.1 * index
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChooDesPl__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            title: category.name,
                                            icon: category.icon,
                                            type: type,
                                            selectedMany: selectedMany,
                                            setselectedMany: setselectedMany,
                                            selected: "",
                                            setselected: ()=>{}
                                        })
                                    }))
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-[22px]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                transition: {
                                    type: "spring",
                                    stiffness: 35,
                                    delay: 0.2
                                },
                                className: "h-[24px] mb-[22px] tablet:mb-[62px] mobile:mb-[40px] w-[100%]  ml-auto mr-auto ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-[18px] text-black font-semibold",
                                    children: "Do you have any standout amenities?"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                ref: refButton2,
                                className: "grid grid-cols-3 gap-[15px] w-[100%] laptop:grid-cols-2 tablet:grid-cols-2 mobile:grid-cols-2 ",
                                children: _utils_constant__WEBPACK_IMPORTED_MODULE_2__/* .standoutamenities.map */ .sf.map((category, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        ref: refButton2,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                            initial: "hidden",
                                            animate: inViewButton2 ? "visible" : "hidden",
                                            variants: animationVariants,
                                            transition: {
                                                type: "spring",
                                                stiffness: 35,
                                                delay: 0.1 * index
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChooDesPl__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                title: category.name,
                                                icon: category.icon,
                                                type: type,
                                                selectedMany: selectedMany,
                                                setselectedMany: setselectedMany,
                                                selected: "",
                                                setselected: ()=>{}
                                            })
                                        })
                                    }))
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                ref: ref2,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                    initial: "hidden",
                                    animate: inView2 ? "visible" : "hidden",
                                    variants: animationVariants,
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.1
                                    },
                                    className: "h-[24px] mb-[22px] tablet:mb-[62px] mobile:mb-[92px] w-[100%]  ml-auto mr-auto ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-[18px] text-black font-semibold",
                                        children: "Do you have any of the following safety amenities?"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid grid-cols-3 gap-[15px] w-[100%] laptop:grid-cols-2 tablet:grid-cols-2 mobile:grid-cols-2 ",
                                children: _utils_constant__WEBPACK_IMPORTED_MODULE_2__/* .safetyitems.map */ .VT.map((category, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        ref: refButton,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                            initial: "hidden",
                                            animate: inViewButton ? "visible" : "hidden",
                                            variants: animationVariants,
                                            transition: {
                                                type: "spring",
                                                stiffness: 35,
                                                delay: 0.1 * index
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChooDesPl__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                title: category.name,
                                                icon: category.icon,
                                                type: type,
                                                selectedMany: selectedMany,
                                                setselectedMany: setselectedMany,
                                                selected: "",
                                                setselected: ()=>{}
                                            })
                                        })
                                    }))
                            })
                        ]
                    })
                ]
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9469:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step11CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5178);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_filepond__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1137);
/* harmony import */ var filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1711);
/* harmony import */ var filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8984);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(391);
/* harmony import */ var filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _contexts_imgFile__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8705);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



// Import React FilePond

// Import FilePond styles

// Import the Image EXIF Orientation and Image Preview plugins
// Note: These need to be installed separately
// `npm i filepond-plugin-image-preview filepond-plugin-image-exif-orientation --save`




(0,react_filepond__WEBPACK_IMPORTED_MODULE_3__.registerPlugin)((filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_5___default()), (filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_6___default()));
function Step11CHome({ api_url_path  }) {
    const { imgArr , setImgArr  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_imgFile__WEBPACK_IMPORTED_MODULE_8__/* .imgFileContext */ .c);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px] mobile:px-0 ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[65%] ml-auto mr-auto pl-[70px] mt-[30px] mobile:pl-0 laptop:w-[90%] tablet:w-[90%] ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col px-10 w-[100%]",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-[32px]",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-[32px] h-[82px] tablet:mb-[62px] mobile:mb-[152px] w-[100%] ml-auto mr-auto ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.h1, {
                                initial: {
                                    opacity: 0,
                                    y: 30
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    type: "spring",
                                    stiffness: 35,
                                    delay: 0.2
                                },
                                className: "text-[32px] font-semibold w-[100%] leading-10 mb-3 ",
                                children: "Add some photos of your cabin"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.p, {
                                initial: {
                                    opacity: 0,
                                    y: -30
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    type: "spring",
                                    stiffness: 35,
                                    delay: 0.2
                                },
                                className: "text-[18px] text-[#717171]",
                                children: "You'll need 5 photos to get started. You can add more or make changes later."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mt-10"
                            })
                        ]
                    })
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3562:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step12CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function Step12CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_4__/* .newHouseContext */ .y);
    const [character, setCharacter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.title);
    const [warning, setWarning] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    let lengthChar = character.length;
    const handleChange = (event)=>{
        if (character.length < 32) {
            setWarning(false);
        } else {
            setWarning(true);
        }
        setCharacter(event.target.value);
    };
    const characterCount = character.length;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP12",
            payload: character
        });
    }, [
        character
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px] mobile:px-0 ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[65%] ml-auto mr-auto pl-[70px] mt-[30px] mobile:pl-0 laptop:w-[90%] tablet:w-[90%] ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col px-10 w-[100%]",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-[32px]",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-[32px] h-[82px] tablet:mb-[62px] mobile:mb-[152px] w-[100%] ml-auto mr-auto ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.h1, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "text-[32px] font-semibold w-[100%] leading-10 mb-3 ",
                                    children: "Now, let's give your cabin a title"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.p, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "text-[18px] text-[#717171]",
                                    children: "Short titles work best. Have fun with it—you can always change it later."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.textarea, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    value: character,
                                    onChange: handleChange,
                                    id: "message",
                                    rows: 7,
                                    className: "block p-2.5 text-[20px] w-full text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-black dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "mt-2",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-gray-400 ",
                                        children: [
                                            characterCount,
                                            "/32"
                                        ]
                                    })
                                }),
                                warning && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex items-center text-red-500 text-[12px]",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_2__.RiErrorWarningFill, {}),
                                            " The maximum number of characters allowed is 32."
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7485:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step13CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function Step13CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_4__/* .newHouseContext */ .y);
    const [character, setCharacter] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.description);
    const [warning, setWarning] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    let lengthChar = character.length;
    const handleChange = (event)=>{
        if (character.length < 500) {
            setWarning(false);
        } else {
            setWarning(true);
        }
        setCharacter(event.target.value);
    };
    const characterCount = character.length;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP13",
            payload: character
        });
    }, [
        character
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px] mobile:px-0 ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[65%] ml-auto mr-auto pl-[70px] mt-[30px] mobile:pl-0 laptop:w-[90%] tablet:w-[90%] ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col px-10 w-[100%]",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-[32px]",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-[32px] h-[82px] tablet:mb-[62px] mobile:mb-[152px] w-[100%] ml-auto mr-auto ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.h1, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "text-[32px] font-semibold w-[100%] leading-10 mb-3 ",
                                    children: "Create your description"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.p, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "text-[18px] text-[#717171]",
                                    children: "Share what makes your place special."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.textarea, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    value: character,
                                    placeholder: "You'll have a great time at this comfortable place to stay.",
                                    onChange: handleChange,
                                    id: "message",
                                    rows: 7,
                                    className: "block p-6 text-[20px] w-full h-[300px] text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-transparent dark:border-gray-600 dark:placeholder-gray-400 dark:text-black dark:focus:ring-blue-500 dark:focus:border-blue-500"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "mt-2",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-gray-400 ",
                                        children: [
                                            characterCount,
                                            "/500"
                                        ]
                                    })
                                }),
                                warning && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex items-center text-red-500 text-[12px]",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_2__.RiErrorWarningFill, {}),
                                            " The maximum number of characters allowed is 32."
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6983:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step14CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Step14CHome() {
    const videoRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (videoRef.current) {
            videoRef.current.onloadedmetadata = ()=>{
                videoRef.current?.play();
            };
        }
    }, [
        videoRef
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "mt-[88px] w-[98vw]",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[80%] ml-auto mr-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-[80px] flex  items-center w-[100%] tablet:flex-col-reverse mobile:flex-col-reverse ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-[65%] tablet:w-[100%] mobile:w-[100%] ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "text-[18px] font-semibold mb-[16px]",
                                children: "Step 3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-[48px] leading-[54px] font-semibold mb-[24px]",
                                children: "Finish up and publish"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "font-normal text-[18px] w-[100%]",
                                children: "Finally, you’ll choose if you'd like to start with an experienced guest, then you'll set your nightly price. Answer a few quick questions and publish when you're ready."
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[55%] tablet:w-[100%] mobile:w-[100%]",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                            className: "w-fit h-fit",
                            preload: "auto",
                            autoPlay: true,
                            muted: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                src: "./Step3.mp4",
                                className: "w-full h-full"
                            })
                        })
                    })
                ]
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9879:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step15CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function Step15CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_3__/* .newHouseContext */ .y);
    const [selectedOption, setSelectedOption] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.guest);
    const handleRadioChange = (event)=>{
        setSelectedOption((prevState)=>event.target.value);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP15",
            payload: selectedOption
        });
    }, [
        selectedOption
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px] mobile:px-0 mobile:pb-20 ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[65%] mobile:w-[100%] ml-auto mr-auto pl-[70px] mt-[30px] mobile:pl-0 laptop:w-[90%] tablet:w-[90%] ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col px-10 w-[100%]",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-[32px]",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-[62px] h-[82px] tablet:mb-[62px] laptop:mb-[22px] mobile:mb-[152px] w-[100%] ml-auto mr-auto ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.h1, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "text-[32px] font-semibold w-[100%] leading-10 mb-3 ",
                                    children: "Choose who to welcome for your first reservation"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.p, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "text-[18px] text-[#717171] ",
                                    children: [
                                        "After your first guest, anyone can book your place.",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "underline",
                                            children: "Learn more"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.1
                                    },
                                    className: `flex flex-col my-[16px] p-[24px] border
                            ${selectedOption === "Anyolympusguest" ? "bg-[#F7F7F7] border-[2px] hover:border-black border-black" : "border-gray-200 border-[2px] hover:border-black"}
                             rounded-[14px] hover:border-black cursor-pointer
                            `,
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                            className: "flex items-center justify-center cursor-pointer",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        value: "Anyolympusguest",
                                                        onChange: handleRadioChange,
                                                        id: "bordered-radio-1",
                                                        type: "radio",
                                                        name: "bordered-radio",
                                                        checked: selectedOption === "Anyolympusguest",
                                                        className: "w-4 h-4 text-black rounded-[50%] bg-black "
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "bordered-radio-1",
                                                    className: "w-full cursor-pointer ml-2 text-[18px] font-semibold text-black ",
                                                    children: "Any Olympus guest"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex justify-start",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "bordered-radio-1",
                                                className: "w-full ml-6 cursor-pointer text-sm font-medium text-gray-900 dark:text-gray-300",
                                                children: "Get reservations faster when you welcome anyone from the Olympus community."
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.3
                                    },
                                    className: `flex flex-col p-[24px] rounded-[14px] cursor-pointer  ${selectedOption === "AnExperiancedguest" ? "bg-[#F7F7F7] border-[2px] hover:border-black border-black" : "border-gray-200 border-[2px] hover:border-black"}`,
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-center items-center cursor-pointer",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "cursor-pointer",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        value: "AnExperiancedguest",
                                                        onChange: handleRadioChange,
                                                        checked: selectedOption === "AnExperiancedguest",
                                                        id: "bordered-radio-2",
                                                        type: "radio",
                                                        name: "bordered-radio",
                                                        className: "w-4 h-4 cursor-pointer "
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    htmlFor: "bordered-radio-2",
                                                    className: "w-full ml-2 text-[18px] font-semibold text-gray-900 cursor-pointer",
                                                    children: "An experienced guest"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "ml-6 flex justify-start cursor-pointer",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                htmlFor: "bordered-radio-2",
                                                className: "w-full text-sm cursor-pointer font-medium text-gray-900 dark:text-gray-300",
                                                children: "For your first guest, welcome someone with a good track record on Olympus who can offer tips for how to be a great Host."
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2818:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step16CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5452);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_rx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_6__]);
framer_motion__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function Step16CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_7__/* .newHouseContext */ .y);
    const [money, setMoney] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.price);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // hàm handleInput đc chạy vào khi mình chỉnh tiền bằng tay, nhấn nút tăng giảm onChange không có tác dụng
    const handleMoney = (event)=>{
        const inputValue = event.target.value;
        const moneyValue = parseInt(inputValue.slice(1));
        if (moneyValue <= 0 || isNaN(moneyValue)) {
            setError(true);
            setMoney(0);
        } else if (moneyValue >= 0 && moneyValue < 10) {
            setError(true);
            setMoney(moneyValue);
        } else {
            setError(false);
            setMoney(moneyValue);
        }
    };
    function cre() {
        if (money >= 10) {
            setError(false);
            setMoney((prev)=>prev + 1);
        } else if (money < 10 && money >= 0) {
            setError(true);
            setMoney((prev)=>prev + 1);
        }
    }
    function incre() {
        if (money > 10) {
            setError(false);
            setMoney((prev)=>prev - 1);
        } else if (money <= 10 && money > 0) {
            setError(true);
            setMoney((prev)=>prev - 1);
        } else {
            setError(true);
            setMoney(0);
        }
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP16",
            payload: money
        });
    }, [
        money
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px] mobile:px-0 ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[830px] ml-auto mr-auto pl-[70px] mt-[30px] h-[700px] mobile:w-[530px] mobile:pl-0  ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col px-10 w-[100%] ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-[32px]",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-[32px] h-[82px] tablet:mb-[62px] mobile:mb-[152px] w-[100%] ml-auto mr-auto ",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-[22px]",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.h1, {
                                        initial: {
                                            opacity: 0,
                                            y: 30
                                        },
                                        animate: {
                                            opacity: 1,
                                            y: 0
                                        },
                                        transition: {
                                            type: "spring",
                                            stiffness: 35,
                                            delay: 0.2
                                        },
                                        className: "text-[32px] font-semibold w-[100%] leading-10 mb-3 ",
                                        children: "Now, set your price"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.p, {
                                        initial: {
                                            opacity: 0,
                                            y: -30
                                        },
                                        animate: {
                                            opacity: 1,
                                            y: 0
                                        },
                                        transition: {
                                            type: "spring",
                                            stiffness: 35,
                                            delay: 0.2
                                        },
                                        className: "text-[18px] text-[#717171] ",
                                        children: "You can change it anytime."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.div, {
                                initial: {
                                    opacity: 0,
                                    y: 30
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    type: "spring",
                                    stiffness: 35,
                                    delay: 0.2
                                },
                                className: "w-[95%] bg-[#F7F7F7] h-[320px] border rounded-[12px] p-[32px] flex flex-col items-center mobile:h-[260px] ",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: " flex items-center flex-col w-[100%]",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center justify-around w-[430px] pb-[16px]",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        disabled: money < 1,
                                                        onClick: incre,
                                                        className: `border w-[55px] h-[48px] flex justify-center items-center rounded-full ${money >= 1 ? "hover:border-black text-black border-[#717171]" : "bg-[#FFF] text-[#EBEBEB] border-[#EBEBEB]"}`,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_3__.RxMinus, {})
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: `w-[400px] h-[96px]
                                  mobile:w-[200px] mobile:h-[56px]
                                        `,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            placeholder: "$00",
                                                            type: "text",
                                                            value: `$${money}`,
                                                            onChange: handleMoney,
                                                            className: `my-[8px] mx-[12px] w-[98%] h-[98%] border border-black rounded-[8px] text-[48px] text-center ${error ? " bg-red-50 border border-red-500 text-red-900" : ""}
                                            `
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        disabled: money > 10000,
                                                        onClick: cre,
                                                        className: `border ml-3 w-[55px] h-[48px] flex justify-center items-center rounded-full ${money <= 10000 ? "hover:border-black text-black border-[#717171]" : "bg-[#FFF] text-[#EBEBEB] border-[#EBEBEB]"}`,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsPlusLg, {})
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mt-4",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "per night"
                                                })
                                            }),
                                            error && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex justify-center items-center pt-3",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_4__.RiErrorWarningFill, {
                                                        className: "text-[14px] text-[#C13515]"
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-[12px] text-[#C13515]",
                                                        children: "Please enter a base price between $10 and $10,000."
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center text-[18px] relative pt-[16px] text-center",
                                        children: [
                                            "Places like yours in your area usually ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                            " range from $10 to $42.5",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_5__.HiOutlineInformationCircle, {
                                                    className: "absolute right-3 bottom-[5px]"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2970:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step17CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function Step17CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_4__/* .newHouseContext */ .y);
    const [note, setNote] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.note);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP17",
            payload: {
                camera: note.camera,
                weapons: note.weapons,
                dangerAnimals: note.dangerAnimals
            }
        });
    }, [
        note
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px] mobile:px-0 mobile:h-[630px] ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[65%] ml-auto mr-auto pl-[70px] mt-[30px] mobile:pl-0 laptop:w-[90%] tablet:w-[90%] ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col px-10 w-[100%] mobile:px-0",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-[32px]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mb-[0px] h-[65px] w-[100%] ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.h1, {
                                initial: {
                                    opacity: 0,
                                    y: 30
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    type: "spring",
                                    stiffness: 35,
                                    delay: 0.1
                                },
                                className: "text-[32px] font-semibold w-[100%] leading-10 mb-3 ",
                                children: "Just one last step!"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "border-b-[1px] flex flex-col gap-3 pb-[48px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mb-[20px]",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.h1, {
                                        initial: {
                                            opacity: 0,
                                            y: 30
                                        },
                                        animate: {
                                            opacity: 1,
                                            y: 0
                                        },
                                        transition: {
                                            type: "spring",
                                            stiffness: 35,
                                            delay: 0.2
                                        },
                                        className: "flex items-center text-[18px] font-semibold",
                                        children: [
                                            "Does your place have any of these? ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_2__.RiErrorWarningLine, {
                                                className: "ml-2"
                                            }),
                                            " "
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col gap-3",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                            initial: {
                                                opacity: 0,
                                                y: -30
                                            },
                                            animate: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            transition: {
                                                type: "spring",
                                                stiffness: 35,
                                                delay: 0.2
                                            },
                                            className: "flex items-center mb-4 justify-between",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "security-camera",
                                                        className: "text-[16px] text-gray-900 ",
                                                        children: "Security camera(s)"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    id: "security-camera",
                                                    type: "checkbox",
                                                    checked: note.camera,
                                                    onChange: (event)=>setNote((prevNote)=>({
                                                                ...prevNote,
                                                                camera: event.target.checked
                                                            })),
                                                    className: "w-[24px] h-[24px] text-white rounded-[20px] checked:bg-black focus:ring-black dark:focus:ring-black"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                            initial: {
                                                opacity: 0,
                                                y: -30
                                            },
                                            animate: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            transition: {
                                                type: "spring",
                                                stiffness: 35,
                                                delay: 0.3
                                            },
                                            className: "flex items-center mb-4 justify-between",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "Weapons",
                                                        className: "text-[16px]  focus:ring-black dark:focus:ring-black  text-gray-900 ",
                                                        children: "Weapons"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    id: "Weapons",
                                                    type: "checkbox",
                                                    onChange: (event)=>setNote((prevNote)=>({
                                                                ...prevNote,
                                                                weapons: event.target.checked
                                                            })),
                                                    checked: note.weapons,
                                                    className: "w-[24px] h-[24px] text-white rounded-[20px] checked:bg-black focus:ring-black dark:focus:ring-black"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                            initial: {
                                                opacity: 0,
                                                y: -30
                                            },
                                            animate: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            transition: {
                                                type: "spring",
                                                stiffness: 35,
                                                delay: 0.4
                                            },
                                            className: "flex items-center mb-4 justify-between",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "Dangerous-animals",
                                                        className: "text-[16px] text-gray-900 ",
                                                        children: "Dangerous animals"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    id: "Dangerous-animals",
                                                    onChange: (event)=>setNote((prevNote)=>({
                                                                ...prevNote,
                                                                dangerAnimals: event.target.checked
                                                            })),
                                                    type: "checkbox",
                                                    checked: note.dangerAnimals,
                                                    className: "w-[24px] h-[24px] text-white rounded-[20px] checked:bg-black focus:ring-black dark:focus:ring-black"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                            initial: {
                                opacity: 0,
                                y: -30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                type: "spring",
                                stiffness: 35,
                                delay: 0.2
                            },
                            className: "pt-[48px]",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: "mb-2 text-[18px] text-[#717171] font-semibold",
                                    children: "Important things to know"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "leading-5 text-[#717171]",
                                    children: [
                                        "Be sure to comply with your ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "underline",
                                            children: "local laws"
                                        }),
                                        " and review Olympus's ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "underline",
                                            children: "nondiscrimination policy"
                                        }),
                                        " and",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "underline",
                                            children: "guest and Host fees"
                                        }),
                                        "."
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2304:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step1CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Step1CHome() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "mt-[48px] w-[98vw] h-[100vh - 56px] mobile:h-[100vh]",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[80%] ml-auto mr-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-[80px] flex  items-center w-[100%] tablet:flex-col-reverse mobile:flex-col-reverse ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-[50%] tablet:w-[100%] mobile:w-[100%] ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "text-[18px] font-semibold mb-[16px]",
                                children: "Step 1"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-[48px] leading-[54px] font-semibold mb-[24px]",
                                children: "Tell us about your place"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "font-normal text-[18px] mobile:pb-[100px]",
                                children: "In this step, we'll ask you which type of property you have and if guests will book the entire place or just a room. Then let us know the location and how many guests can stay."
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[50%] tablet:w-[100%] mobile:w-[100%]",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                            className: "w-fit h-fit",
                            preload: "auto",
                            autoPlay: true,
                            muted: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                src: "./Step1.mp4",
                                className: "w-full h-full"
                            })
                        })
                    })
                ]
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1950:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step2CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_constant__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2223);
/* harmony import */ var _ChooDesPl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1290);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Step2CHome() {
    // set Active thì để ngoài như này kh đc để trong lớp con
    // để trong lớp con thì khi render ra mỗi class sẽ có 1 state
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_5__/* .newHouseContext */ .y);
    const [selected, setselected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.type);
    const type = "select1";
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP2",
            payload: selected
        });
    }, [
        selected
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px] h-[800px] mobile:px-0",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[60%] mobile:w-[100%] tablet:w-[100%] laptop:w-[100%] ml-auto mr-auto pl-[70px] mobile:pl-0  ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col px-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        className: "mb-[32px] h-[72px] ",
                        initial: {
                            opacity: 0,
                            y: 30
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            type: "spring",
                            stiffness: 35
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-[32px] font-semibold w-[530px] mobile:w-[450px] leading-10 mobile:text-[26px]",
                            children: "Which of these best describes \xa0 \xa0your place?"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "grid grid-cols-3 gap-[15px] w-[100%] laptop:grid-cols-2 tablet:grid-cols-2 mobile:grid-cols-2 ",
                        children: _utils_constant__WEBPACK_IMPORTED_MODULE_2__/* .categoriesStep2.map */ .DM.map((category, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                initial: {
                                    opacity: 0,
                                    y: -30
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    type: "spring",
                                    stiffness: 35,
                                    delay: 0.1 * index
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChooDesPl__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    title: category.name,
                                    icon: category.icon,
                                    selected: selected,
                                    setselected: setselected,
                                    type: type,
                                    selectedMany: [],
                                    setselectedMany: ()=>{}
                                })
                            }, index))
                    })
                ]
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6023:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step3CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ChooTypeHo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5731);
/* harmony import */ var _utils_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2223);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Step3CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_5__/* .newHouseContext */ .y);
    const [selected, setselected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.place);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP3",
            payload: selected
        });
    }, [
        selected
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-full h-[100vh -56px] flex justify-center mt-7 mobile:px-[24px] ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-[630px]",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mb-7",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "text-[30px] font-semibold mobile:text-[20px] ",
                        children: "What type of place will guests have?"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: _utils_constant__WEBPACK_IMPORTED_MODULE_3__/* .categoriesStep3.map */ .xc.map((categorie, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                            initial: {
                                opacity: 0,
                                y: -30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                type: "spring",
                                stiffness: 35,
                                delay: 0.3 * index
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChooTypeHo__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                selected: selected,
                                setselected: setselected,
                                name: categorie.name,
                                icon: categorie.icon,
                                description: categorie.description,
                                type: ""
                            }, index)
                        }, index))
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4422:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Map_Map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3722);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function Step4CHome({ keyMapBing  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "flex justify-start mt-10 md:justify-center w-full h-[100vh -56px]",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-[1000px]",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.h1, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                type: "spring",
                                stiffness: 35,
                                delay: 0.1
                            },
                            className: "font-sans text-2xl ml-2 md:ml-0 md:text-4xl font-semibold text-[#222222] mb-4",
                            children: "Where's your place located?"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.p, {
                            initial: {
                                opacity: 0,
                                y: -30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                type: "spring",
                                stiffness: 35,
                                delay: 0.2
                            },
                            className: "font-sans text-sm ml-2 md:ml-0 md:text-lg text-[#717171]",
                            children: "Your address is only shared with guests after they’ve made a reservation."
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Map_Map__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    keyMapBing: keyMapBing
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Step4CHome);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Step_Step5CHome)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "react-icons/ti"
const ti_namespaceObject = require("react-icons/ti");
// EXTERNAL MODULE: ./src/contexts/createHome.tsx
var createHome = __webpack_require__(7327);
// EXTERNAL MODULE: ./src/components/main/showHouse/mapEach.tsx
var mapEach = __webpack_require__(8903);
// EXTERNAL MODULE: ./src/contexts/selectPlace.tsx
var selectPlace = __webpack_require__(9445);
;// CONCATENATED MODULE: ./src/components/CreateHome/Step/Step5CHome.tsx






const Step5CHome = ({ keyMapBing  })=>{
    const { state , dispatch  } = (0,external_react_.useContext)(createHome/* newHouseContext */.y);
    const { address  } = (0,external_react_.useContext)(selectPlace/* selectPlaceContext */.t);
    const [toggle, setToggle] = (0,external_react_.useState)(false);
    const [country, setCountry] = (0,external_react_.useState)(state.addressConfirmation.country);
    const [subAddress, setSubAddress] = (0,external_react_.useState)({
        address1: state.addressConfirmation.subAddress[0],
        address2: state.addressConfirmation.subAddress[1],
        address3: state.addressConfirmation.subAddress[2],
        address4: state.addressConfirmation.subAddress[3]
    });
    const [city, setCity] = (0,external_react_.useState)(state.addressConfirmation.city);
    const [province, setProvince] = (0,external_react_.useState)(state.addressConfirmation.province);
    const [postCode, setPostCode] = (0,external_react_.useState)(state.addressConfirmation.postCode);
    function addCountry(event) {
        const selectedCountry = event.currentTarget.value;
        setCountry((prev)=>selectedCountry);
    }
    function subAddressHandler(event) {
        const { name , value  } = event.target;
        setSubAddress((prev)=>({
                ...prev,
                [name]: value
            }));
    }
    function cityValueHandler(event) {
        const city = event.currentTarget.value;
        setCity((prev)=>city);
    }
    function provinceValueHandler(event) {
        const province = event.currentTarget.value;
        setProvince((prev)=>province);
    }
    function postCodeValueHandler(event) {
        const post = event.currentTarget.value;
        setPostCode((prev)=>post);
    }
    (0,external_react_.useEffect)(()=>{
        dispatch({
            type: "STEP5",
            payload: {
                country: country,
                subAddress: Object.values(subAddress),
                city: city,
                province: province,
                postCode: postCode
            }
        });
    }, [
        country,
        subAddress,
        city,
        province,
        postCode
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full h-screen",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "px-6 sm:px-52 md:px-44 lg:px-52 xl:px-96 mt-[80px]",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mb-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "font-sans text-2xl ml-2 md:ml-0 md:text-4xl font-semibold text-[#222222] mb-4",
                                children: "Confirm your address"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "font-sans text-sm ml-2 md:ml-0 md:text-lg text-[#717171]",
                                children: "Your address is only shared with guests after they’ve made a reservation."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "border rounded-[11px] cursor-pointer",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                            className: "w-full relative cursor-pointer",
                            htmlFor: "countryCode",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "absolute top-[-18px] left-[12px] text-[#717171] text-sm",
                                    children: "Country/Region"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("select", {
                                    className: "w-full min-h-[56px] cursor-pointer border-[#717171] outline-none m-0 pt-[26px] pr-[36px] pb-[10px] pl-[12px] bg-transparent rounded-md focus:ring-0  overflow-y-scroll",
                                    name: "countryCode",
                                    id: "countryCode",
                                    // size='12'
                                    value: country,
                                    onChange: addCountry,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AF",
                                            children: "Afghanistan - AF"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AF",
                                            children: "Afghanistan - AF"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AL",
                                            children: "Albania - AL"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AL",
                                            children: "Albania - AL"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "DZ",
                                            children: "Algeria - DZ"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AS",
                                            children: "American Samoa - AS"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AD",
                                            children: "Andorra - AD"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AO",
                                            children: "Angola - AO"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AI",
                                            children: "Anguilla - AI"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AG",
                                            children: "Antigua & Barbuda - AG"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AG",
                                            children: "Antigua & Barbuda - AG"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AR",
                                            children: "Argentina - AR"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AM",
                                            children: "Armenia - AM"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AW",
                                            children: "Aruba - AW"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AU",
                                            children: "Australia - AU"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AU",
                                            children: "Australia - AU"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AT",
                                            children: "Austria - AT"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "AZ",
                                            children: "Azerbaijan - AZ"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "BS",
                                            children: "Bahamas - BS"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "BH",
                                            children: "Bahrain - BH"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "BD",
                                            children: "Bangladesh - BD"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "BB",
                                            children: "Barbados - BB"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("option", {
                                            value: "BY",
                                            children: "Belarus - BY"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "rounded-md border-[#717171] mt-6 w-full border-[1px]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full rounded-tr-md rounded-tl-md border-[#717171] border-b-[1px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    name: "address1",
                                    onChange: subAddressHandler,
                                    value: subAddress.address1,
                                    placeholder: "Address line 1",
                                    className: "w-full rounded-md border-none h-[50px] focus:ring-1 focus:ring-black placeholder:p-2 placeholder:font-medium"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full rounded-tr-md rounded-tl-md border-[#717171] border-b-[1px]  ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    name: "address2",
                                    onChange: subAddressHandler,
                                    value: subAddress.address2,
                                    placeholder: "Address line 2 (if applicable)",
                                    className: "w-full rounded-md border-none h-[50px] focus:ring-1 focus:ring-black placeholder:p-2 placeholder:font-medium"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full rounded-tr-md rounded-tl-md border-[#717171] border-b-[1px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    name: "address3",
                                    onChange: subAddressHandler,
                                    value: subAddress.address3,
                                    placeholder: "Address line 3 (if applicable)",
                                    className: "w-full rounded-md border-none h-[50px] focus:ring-1 focus:ring-black placeholder:p-2 placeholder:font-medium"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full rounded-tr-md rounded-tl-md border-[#717171] border-b-[1px] ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    name: "address4",
                                    onChange: subAddressHandler,
                                    value: subAddress.address4,
                                    placeholder: "Address line 4 (if applicable)",
                                    className: "w-full rounded-md border-none h-[50px] focus:ring-1 focus:ring-black placeholder:p-2 placeholder:font-medium"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full rounded-tr-md rounded-tl-md border-[#717171] border-b-[1px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    placeholder: "City/village (if applicable)",
                                    onChange: cityValueHandler,
                                    value: city,
                                    className: "w-full rounded-md border-none h-[50px] focus:ring-1 focus:ring-black placeholder:p-2 placeholder:font-medium"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full rounded-tr-md rounded-tl-md border-[#717171] border-b-[1px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    onChange: provinceValueHandler,
                                    value: province,
                                    placeholder: "Country/province/territory (if applicable)",
                                    className: "w-full rounded-md border-none h-[50px] focus:ring-1 focus:ring-black placeholder:p-2 placeholder:font-medium"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full border-[#717171]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    onChange: postCodeValueHandler,
                                    value: postCode,
                                    placeholder: "Post code (if applicable)",
                                    type: "text",
                                    className: "w-full rounded-md border-none h-[50px] focus:ring-1 focus:ring-black placeholder:p-2 placeholder:font-medium"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: "my-8 "
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full mb-[20px]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "w-full flex items-center mb-4",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                className: "text-[16px] font-semibold pb-1",
                                                children: "Show your specific location"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm text-[#717171]",
                                                children: [
                                                    "Make it clear to guests where your place is located. We'll only share your address after they've made a reservation.",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        href: "",
                                                        className: "underline",
                                                        children: "Learn more"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "pl-3",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            onClick: ()=>setToggle((prev)=>!prev),
                                            "aria-checked": "false",
                                            "aria-labelledby": "pin-type-toggle-label",
                                            "aria-describedby": "pin-type-toggle-description",
                                            role: "switch",
                                            type: "button",
                                            className: `${toggle ? "bg-black" : "bg-[#b0b0b0]"} rounded-[32px] h-8 w-12 min-w-[48px] relative cursor-pointer`,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: `${toggle ? "right-[-1px] border-black" : "left-[-1px] border-[#b0b0b0]"} top-[1px] absolute bg-white h-[30px] w-[30px] rounded-[50%] border-2 flex items-center justify-center`,
                                                children: toggle && /*#__PURE__*/ jsx_runtime_.jsx(ti_namespaceObject.TiTick, {})
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(mapEach/* default */.Z, {
                                keyMapBing: keyMapBing,
                                latitude: address.address.latitude,
                                longitude: address.address.longitude,
                                zoom: 15,
                                formattedAddress: address.address.formattedAddress,
                                idMap: "3",
                                style: "h-[500px]"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-ful h-[80px]"
            })
        ]
    });
};
/* harmony default export */ const Step_Step5CHome = (Step5CHome);


/***/ }),

/***/ 4522:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step6CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






let initial = true;
function Step6CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_5__/* .newHouseContext */ .y);
    const [guestCount, setguestCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.placeInfo.guests);
    const [BedroomCount, setBedroomCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.placeInfo.bedrooms);
    const [BedsCount, setBedsCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.placeInfo.beds);
    const [BathroomCount, setBathroomCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.placeInfo.bathrooms);
    const [showExtraRow, setShowExtraRow] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(!state.placeInfo.hasLock || state.placeInfo.hasLock === "no" ? true : false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP6",
            payload: {
                guests: guestCount,
                bedrooms: BedroomCount,
                beds: BedsCount,
                bathrooms: BathroomCount,
                hasLock: showExtraRow ? "no" : "yes"
            }
        });
    }, [
        guestCount,
        BedroomCount,
        BedsCount,
        BathroomCount,
        showExtraRow
    ]);
    const handleGuestCount = ()=>{
        if (guestCount <= 0) {
            return;
        } else {
            setguestCount((prev)=>prev - 1);
        }
    };
    const handleBedroomCount = ()=>{
        if (BedroomCount <= 0) {
            return;
        } else {
            setBedroomCount((prev)=>prev - 1);
        }
    };
    const handleBedsCount = ()=>{
        if (BedsCount <= 0) {
            return;
        } else {
            setBedsCount((prev)=>prev - 1);
        }
    };
    const handleBathroomCount = ()=>{
        if (BathroomCount <= 0) {
            return;
        } else {
            setBathroomCount((prev)=>prev - 1);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] h-[700px] px-[80px] tablet:px-[50px] mt-10",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[60%] tablet:w-[80%] laptop:w-[80%] mobile:w-[100%] ml-auto mr-auto pl-[70px] mobile:pl-0 ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.h1, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                type: "spring",
                                stiffness: 35,
                                delay: 0.1
                            },
                            className: "text-[32px] font-semibold mobile:text-[26px] tablet:text-[26px] ",
                            children: "Share some basics about your place"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.h2, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                type: "spring",
                                stiffness: 35,
                                delay: 0.2
                            },
                            className: "text-[18px] py-[18px] text-[#717171]",
                            children: "You'll add more details later, like bed types."
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col justify-between",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.3
                                    },
                                    className: "flex justify-between py-[24px] border-b-[1px]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-[18px] ",
                                                children: "Guests"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between gap-3 items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: `border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black `,
                                                    style: {},
                                                    onClick: handleGuestCount,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiMinus, {
                                                        className: `w-[32px] h-[32px] p-[5px] `
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-[16px] w-[16px]",
                                                    children: guestCount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsPlus, {
                                                        className: "w-[32px] h-[32px] p-[5px]",
                                                        onClick: ()=>setguestCount((prev)=>prev + 1)
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.4
                                    },
                                    className: "flex justify-between py-[24px] border-b-[1px]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-[18px] ",
                                                children: "Bedrooms"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between gap-3 items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: handleBedroomCount,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiMinus, {
                                                        className: "w-[32px] h-[32px] p-[5px]"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-[16px] w-[16px]",
                                                    children: BedroomCount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: ()=>setBedroomCount((prev)=>prev + 1),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsPlus, {
                                                        className: "w-[32px] h-[32px] p-[5px]"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.5
                                    },
                                    className: "flex justify-between py-[24px] border-b-[1px]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-[18px] ",
                                                children: "Beds"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between gap-3 items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: handleBedsCount,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiMinus, {
                                                        className: "w-[32px] h-[32px] p-[5px] "
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-[16px] w-[16px]",
                                                    children: BedsCount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: ()=>setBedsCount((prev)=>prev + 1),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsPlus, {
                                                        className: "w-[32px] h-[32px] p-[5px]"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.6
                                    },
                                    className: "flex justify-between py-[24px] ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "text-[18px] ",
                                                children: "Bathrooms"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between gap-3 items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: handleBathroomCount,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiMinus, {
                                                        className: "w-[32px] h-[32px] p-[5px] "
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-[16px] w-[16px]",
                                                    children: BathroomCount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: ()=>setBathroomCount((prev)=>prev + 1),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsPlus, {
                                                        className: "w-[32px] h-[32px] p-[5px]"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                            initial: {
                                opacity: 0,
                                y: 30
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                type: "spring",
                                stiffness: 35,
                                delay: 0.7
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                        className: "text-[18px] font-semibold py-[18px]",
                                        children: "Does every bedroom have a lock?"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex items-center mb-5",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        onClick: ()=>{
                                                            setShowExtraRow(false);
                                                            initial = false;
                                                        },
                                                        checked: !initial && !showExtraRow ? true : false,
                                                        id: "default-radio-1",
                                                        type: "radio",
                                                        value: "",
                                                        name: "default-radio",
                                                        className: "w-5 h-5 text-black bg-gray-100 border-gray-300 focus:ring-black dark:focus:ring-black dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                        htmlFor: "default-radio-1",
                                                        className: "ml-3 text-[16px]  text-gray-900 dark:text-gray-300",
                                                        children: "Yes"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                onClick: ()=>{
                                                                    setShowExtraRow(true);
                                                                    initial = false;
                                                                },
                                                                checked: !initial && showExtraRow ? true : false,
                                                                id: "default-radio-2",
                                                                type: "radio",
                                                                value: "",
                                                                name: "default-radio",
                                                                className: "w-5 h-5 text-black bg-gray-100 border-gray-300 focus:ring-black dark:focus:ring-black dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                                htmlFor: "default-radio-2",
                                                                className: "ml-3 text-[16px] text-gray-900 dark:text-gray-300",
                                                                children: "No"
                                                            })
                                                        ]
                                                    }),
                                                    showExtraRow && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                        className: "ml-8 text-[14px] text-[#717171]",
                                                        children: [
                                                            "Guests expect a lock for their room. We strongly recommend adding one.\xa0",
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-black font-semibold underline",
                                                                children: "Learn more"
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4898:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step7CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Step7CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_5__/* .newHouseContext */ .y);
    const [privateCount, setprivateCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.kindOfBathrooms.private);
    const [DedicatedCount, setDedicatedCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.kindOfBathrooms.dedicated);
    const [SharedCount, setSharedCount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.kindOfBathrooms.shared);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP7",
            payload: {
                private: privateCount,
                dedicated: DedicatedCount,
                shared: SharedCount
            }
        });
    }, [
        privateCount,
        DedicatedCount,
        SharedCount
    ]);
    const handleprivateCount = ()=>{
        if (privateCount <= 0) {
            return;
        } else {
            setprivateCount((prev)=>prev - 0.5);
        }
    };
    const handleDedicatedCount = ()=>{
        if (DedicatedCount <= 0) {
            return;
        } else {
            setDedicatedCount((prev)=>prev - 0.5);
        }
    };
    const handleSharedCount = ()=>{
        if (SharedCount <= 0) {
            return;
        } else {
            setSharedCount((prev)=>prev - 0.5);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[98vw] px-[80px]",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[52%] mobile:w-[100%] ml-auto mr-auto pl-[60px] mobile:pl-0 mt-[80px] tablet:w-[80%] laptop:w-[80%] ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.h1, {
                        initial: {
                            opacity: 0,
                            y: 30
                        },
                        animate: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            type: "spring",
                            stiffness: 35,
                            delay: 0.1
                        },
                        className: "text-[32px] font-semibold leading-9 mb-5 mobile:text-[26px] ",
                        children: "What kind of bathrooms are available to guests?"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col justify-between",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "flex justify-between py-[24px] border-b-[1px]",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-[18px] font-semibold",
                                                    children: "Private and attached"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-[#717171]",
                                                    children: "It’s connected to the guest’s room and is just for them."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between gap-3 items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: handleprivateCount,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiMinus, {
                                                        className: "w-[32px] h-[32px] p-[5px]"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-[16px] w-[16px]",
                                                    children: privateCount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsPlus, {
                                                        className: "w-[32px] h-[32px] p-[5px]",
                                                        onClick: ()=>setprivateCount((prev)=>prev + 0.5)
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.3
                                    },
                                    className: "flex justify-between py-[24px] border-b-[1px]",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-[18px] font-semibold ",
                                                    children: "Dedicated"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-[#717171]",
                                                    children: "It’s private, but accessed via a shared space, like a hallway."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between gap-3 items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: handleDedicatedCount,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiMinus, {
                                                        className: "w-[32px] h-[32px] p-[5px]"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-[16px] w-[16px]",
                                                    children: DedicatedCount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: ()=>setDedicatedCount((prev)=>prev + 0.5),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsPlus, {
                                                        className: "w-[32px] h-[32px] p-[5px]"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.4
                                    },
                                    className: "flex justify-between py-[24px]",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "text-[18px] font-semibold ",
                                                    children: "Shared"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-[#717171]",
                                                    children: "It’s shared with other people."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between gap-3 items-center",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: handleSharedCount,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_3__.FiMinus, {
                                                        className: "w-[32px] h-[32px] p-[5px] "
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "text-[16px] w-[16px]",
                                                    children: SharedCount
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-[1px] rounded-[50%] border-[#b0b0b0] ease-in duration-300 hover:border-black",
                                                    onClick: ()=>setSharedCount((prev)=>prev + 0.5),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsPlus, {
                                                        className: "w-[32px] h-[32px] p-[5px]"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7266:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step8CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ChooDesPl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1290);
/* harmony import */ var _utils_constant__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2223);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7327);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function Step8CHome() {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_5__/* .newHouseContext */ .y);
    const [selected, setselected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(state.encounter);
    const type = "select1";
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch({
            type: "STEP8",
            payload: selected
        });
    }, [
        selected
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[98vw] px-[80px] mt-10 mobile:px-0",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[60%] ml-auto mr-auto pl-[70px] mobile:pl-0] mobile:w-[100%]  ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col ",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-[32px] h-[72px] tablet:mb-[62px] mobile:mb-[92px] ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.h1, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.1
                                    },
                                    className: "text-[32px] font-semibold w-[530px] leading-10 mb-3 ",
                                    children: "Who else might be there?"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.p, {
                                    initial: {
                                        opacity: 0,
                                        y: 30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.2
                                    },
                                    className: "text-[18px] text-[#717171]",
                                    children: "Guests need to know whether they’ll encounter other people during their stay."
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "grid grid-cols-3 gap-[15px] w-[100%] mb-6 laptop:grid-cols-2 tablet:grid-cols-2 mobile:grid-cols-2 ",
                            children: _utils_constant__WEBPACK_IMPORTED_MODULE_3__/* .categoriesStep8.map */ .vb.map((category, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                    initial: {
                                        opacity: 0,
                                        y: -30
                                    },
                                    animate: {
                                        opacity: 1,
                                        y: 0
                                    },
                                    transition: {
                                        type: "spring",
                                        stiffness: 35,
                                        delay: 0.1 * index
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ChooDesPl__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        title: category.name,
                                        icon: category.icon,
                                        type: type,
                                        selected: selected,
                                        setselected: setselected,
                                        selectedMany: [],
                                        setselectedMany: ()=>{}
                                    })
                                }))
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.p, {
                                initial: {
                                    opacity: 0,
                                    y: -30
                                },
                                animate: {
                                    opacity: 1,
                                    y: 0
                                },
                                transition: {
                                    type: "spring",
                                    stiffness: 35,
                                    delay: 0.7
                                },
                                className: "text-[18px] text-[#717171]",
                                children: "We’ll show this information on your listing and in search results."
                            })
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9457:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step9CHome)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function Step9CHome() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "mt-[88px] w-[98vw]",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[80%] ml-auto mr-auto",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-[80px] flex  items-center w-[100%] tablet:flex-col-reverse mobile:flex-col-reverse ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-[70%] tablet:w-[100%] mobile:w-[100%] ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                className: "text-[18px] font-semibold mb-[16px]",
                                children: "Step 2"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "text-[48px] leading-[54px] font-semibold mb-[24px] w-[70%]",
                                children: "Make your place stand out"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "font-normal text-[18px] w-[90%]",
                                children: "In this step, you’ll add some of the amenities your place offers, plus 5 or more photos. Then, you’ll create a title and description."
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[55%] tablet:w-[100%] mobile:w-[100%]",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                            className: "w-fit h-fit",
                            preload: "auto",
                            autoPlay: true,
                            muted: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                src: "./Step2.mp4",
                                className: "w-full h-full"
                            })
                        })
                    })
                ]
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2767:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ StepCongratulation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_assets_signature_jpg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8388);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7327);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function StepCongratulation({ api_url_path  }) {
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_5__/* .newHouseContext */ .y);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{}, []);
    const handleClick = ()=>{
        router.push("/hosting");
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        initial: {
            opacity: 0
        },
        animate: {
            opacity: 1
        },
        exit: {
            opacity: 0
        },
        transition: {
            duration: 1
        },
        className: "w-[100%] h-screen bg-[#1B191B] text-white flex items-center justify-center ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bg-[#1B191B] flex items-center mobile:flex-col tablet:flex-col",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-[50%] mobile:mt-[200px]",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                        className: "w-[100%] h-fit",
                        loop: true,
                        preload: "auto",
                        autoPlay: true,
                        muted: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                            src: "./ShakeHands.mp4",
                            className: "w-full h-full"
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-[50%]",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-[100%]",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-[50%] mobile:w-[100%] h-fit flex mobile:flex-col mobile:justify-center mobile:items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "text-[48px] z-10 tablet:text-[36px] mobile:text-[36px] ",
                                            children: "Congratulations, Minh!"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                            className: "z-0 w-[70%] mobile:w-[286px] tablet:w-[286px]  ",
                                            loop: true,
                                            preload: "auto",
                                            autoPlay: true,
                                            muted: true,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                src: "./Congratulation.mp4",
                                                className: "w-fit h-full"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-[14px] z-10 relative tablet:text-[13px] mobile:text-[13px]  mt-[12px]",
                                    children: "From one Host to another—welcome aboard. Thank you for sharing your home and helping to create incredible experiences for our guests."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-[100%] flex flex-col items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        className: "w-[455px] mobile:w-[100%] h-[150px] mt-3",
                                        src: _public_assets_signature_jpg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                        alt: "Signature"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mt-[22px] mobile:mb-[22px]",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: handleClick,
                                        // style={{ transition: "2s" }}
                                        className: "transition ease-in-out delay-150 rounded-[10px] w-[200px] h-[48px] bg-gradient-to-r from-green-400 to-blue-500 hover:from-pink-500 hover:to-yellow-500 ",
                                        children: "Let's get started"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DM": () => (/* binding */ categoriesStep2),
/* harmony export */   "Ei": () => (/* binding */ categoriesStep10),
/* harmony export */   "VT": () => (/* binding */ safetyitems),
/* harmony export */   "sf": () => (/* binding */ standoutamenities),
/* harmony export */   "vb": () => (/* binding */ categoriesStep8),
/* harmony export */   "xc": () => (/* binding */ categoriesStep3)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6946);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_5__);










































const categoriesStep2 = [
    {
        name: "Home",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .House */ .TX, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Cabins",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Cabins */ .HF, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Tyni home",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .TynihomeIcon */ .FP, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Luxury",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Luxe */ .bN, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Camping",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Camping */ .If, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Historical home",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Historical_home */ .jK, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Island",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Islands */ .H4, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Private rooms",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Private_rooms */ .Rk, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Dammusi",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Dammusi */ .Wv, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Amazing pool",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Amazing_pools */ .$C, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Surfing",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Surfing */ .kP, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Tropical",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .TropicalIcon */ .XU, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Vineyard",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .VineYardIcon */ .Lw, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Beach front",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .BeachFronts */ .RJ, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Desert",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Desert */ .XZ, {
            className: "w-[45px] h-[45px]"
        })
    }
];
const categoriesStep8 = [
    {
        name: "Me",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_2__.AiOutlineUser, {
            className: "w-[40px] h-[45px]"
        })
    },
    {
        name: "My family",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_3__.MdFamilyRestroom, {
            className: "w-[40px] h-[45px]"
        })
    },
    {
        name: "Other guests",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_4__.HiOutlineUsers, {
            className: "w-[40px] h-[45px]"
        })
    },
    {
        name: "Roommates",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_5__.TbFriends, {
            className: "w-[40px] h-[45px]"
        })
    }
];
const categoriesStep10 = [
    {
        name: "Wifi",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Wifi */ .kF, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "TV",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__.TV, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Kitchen",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Kitchen */ .oy, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Washer",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Washer */ .O, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Free parking on premiese",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Freepark */ .By, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Paid parking on premises",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Paidpark */ .$d, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Air conditioning",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Aircond */ .NZ, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Dedicated workspace",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Dedwork */ .Gz, {
            className: "w-[45px] h-[45px]"
        })
    }
];
const standoutamenities = [
    {
        name: "Pool",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Amazing_pools */ .$C, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Hot tub",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Hottub */ .Pn, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Patio",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Patio */ ._x, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "BBQ grill",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .BBQ */ .fN, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Outdoor dining area",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .OutdoorDining */ .Ou, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Pool table",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Pooltable */ .yX, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Piano",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Piano */ .id, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Exercise equipment",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Excersise */ .DI, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Outdoor shower",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .OutdoorShow */ .Kq, {
            className: "w-[45px] h-[45px]"
        })
    }
];
const safetyitems = [
    {
        name: "Smoke alarm",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .SmokeA */ .vw, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "First aid kit",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Firstaid */ .gn, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Fire extinguisher",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .FireExting */ .Ff, {
            className: "w-[45px] h-[45px]"
        })
    },
    {
        name: "Carbon monoxide alarm",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Carbonmono */ ._f, {
            className: "w-[45px] h-[45px]"
        })
    }
];
const categoriesStep3 = [
    {
        name: "An entire place",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .House */ .TX, {
            className: "w-[45px] h-[45px]"
        }),
        description: "Guests have the whole place to themselves."
    },
    {
        name: "Apartment",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Apartment */ .qx, {
            className: "w-[45px] h-[45px]"
        }),
        description: "Spacious Apartment with Private Rooms and Shared Amenities."
    },
    {
        name: "Guesthouse",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_1__/* .Guesthouse */ .J9, {
            className: "w-[45px] h-[45px]"
        }),
        description: "Guests sleep in a room or common area that may be shared with you or others."
    }
];


/***/ }),

/***/ 6994:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6648);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3708);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mapOptions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1312);







const authWithoutAnimate = ({ children  })=>{
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_3__.useSession)();
    const { isFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_1__/* .getHouseContext */ .S);
    const { setUser , user  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__/* .userAccContext */ .G);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const setuser = async ()=>{
            const temp = await session?.userAcc;
            if (temp) {
                setUser({
                    ...user,
                    ...temp
                });
            } else {
                setUser({
                    ...user,
                    UserId: "none user"
                });
            }
        };
        setuser();
    }, [
        isFilter,
        status
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mapOptions__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            children: children
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authWithoutAnimate);


/***/ }),

/***/ 7327:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ CreateHouseProvider),
/* harmony export */   "y": () => (/* binding */ newHouseContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const initHouseData = {
    type: "",
    place: "",
    address: {
        countryRegion: "",
        locality: "",
        adminDistrict: "",
        countryRegionIso2: "",
        postalCode: "",
        addressLine: "",
        streetName: "",
        formattedAddress: "",
        latitude: 0,
        longitude: 0,
        title: ""
    },
    addressConfirmation: {
        country: "",
        subAddress: [],
        city: "",
        province: "",
        postCode: ""
    },
    placeInfo: {
        guests: 1,
        bedrooms: 1,
        beds: 1,
        bathrooms: 1,
        hasLock: null
    },
    kindOfBathrooms: {
        private: 0,
        dedicated: 0,
        shared: 0
    },
    encounter: "",
    amenities: [],
    title: "",
    description: "",
    guest: "",
    price: 0,
    note: {
        camera: false,
        weapons: false,
        dangerAnimals: false
    }
};
const newHouseContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    state: initHouseData,
    dispatch: ()=>{}
});
function reducer(state, action) {
    switch(action.type){
        case "STEP2":
            return {
                ...state,
                type: action.payload
            };
        case "STEP3":
            return {
                ...state,
                place: action.payload
            };
        case "STEP4":
            return {
                ...state,
                address: action.payload
            };
        case "STEP5":
            return {
                ...state,
                addressConfirmation: {
                    country: action.payload.country,
                    subAddress: action.payload.subAddress,
                    city: action.payload.city,
                    province: action.payload.province,
                    postCode: action.payload.postCode
                }
            };
        case "STEP6":
            return {
                ...state,
                placeInfo: {
                    guests: action.payload.guests,
                    bedrooms: action.payload.bedrooms,
                    beds: action.payload.beds,
                    bathrooms: action.payload.bathrooms,
                    hasLock: action.payload.hasLock
                }
            };
        case "STEP7":
            return {
                ...state,
                kindOfBathrooms: {
                    private: action.payload.private,
                    dedicated: action.payload.dedicated,
                    shared: action.payload.shared
                }
            };
        case "STEP8":
            return {
                ...state,
                encounter: action.payload
            };
        case "STEP10":
            return {
                ...state,
                amenities: action.payload
            };
        // case 'STEP11':
        //   return {
        //   };
        case "STEP12":
            return {
                ...state,
                title: action.payload
            };
        case "STEP13":
            return {
                ...state,
                description: action.payload
            };
        case "STEP15":
            return {
                ...state,
                guest: action.payload
            };
        case "STEP16":
            return {
                ...state,
                price: action.payload
            };
        case "STEP17":
            return {
                ...state,
                note: {
                    camera: action.payload.camera,
                    weapons: action.payload.weapons,
                    dangerAnimals: action.payload.dangerAnimals
                }
            };
        default:
            return state;
    }
}
function CreateHouseProvider({ children  }) {
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, initHouseData);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(newHouseContext.Provider, {
        value: {
            state,
            dispatch
        },
        children: children
    });
}



/***/ }),

/***/ 8705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "c": () => (/* binding */ imgFileContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const imgFileDefaultData = {
    imgArr: [],
    setImgArr: ()=>{}
};
const imgFileContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(imgFileDefaultData);
const ImgFileProvider = ({ children  })=>{
    const [imgArr, setImgArr_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(imgFileDefaultData.imgArr);
    const setImgArr = (payload)=>setImgArr_(payload);
    const imgFileDynamicData = {
        imgArr,
        setImgArr
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(imgFileContext.Provider, {
        value: imgFileDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImgFileProvider);


/***/ }),

/***/ 4517:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_pages_createhome_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(8472);
/* harmony import */ var next_font_google_target_css_path_src_pages_createhome_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_pages_createhome_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_CreateHome_Step_Header__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4103);
/* harmony import */ var _components_CreateHome_Step_Step1CHome__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2304);
/* harmony import */ var _components_CreateHome_Step_Step2CHome__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1950);
/* harmony import */ var _components_CreateHome_Step_Step3CHome__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6023);
/* harmony import */ var _components_CreateHome_Step_Step4CHome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4422);
/* harmony import */ var _components_CreateHome_Step_Step5CHome__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1588);
/* harmony import */ var _components_CreateHome_Step_Step6CHome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4522);
/* harmony import */ var _components_CreateHome_Step_Step7CHome__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4898);
/* harmony import */ var _components_CreateHome_Step_Step8CHome__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7266);
/* harmony import */ var _components_CreateHome_Step_Step9CHome__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9457);
/* harmony import */ var _components_CreateHome_Step_Step10Home__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2303);
/* harmony import */ var _components_CreateHome_Step_Step11CHome__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9469);
/* harmony import */ var _components_CreateHome_Step_Step12CHome__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3562);
/* harmony import */ var _components_CreateHome_Step_Step13CHome__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7485);
/* harmony import */ var _components_CreateHome_Step_Step14CHome__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6983);
/* harmony import */ var _components_CreateHome_Step_Step15CHome__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9879);
/* harmony import */ var _components_CreateHome_Step_Step16CHome__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2818);
/* harmony import */ var _components_CreateHome_Step_Step17CHome__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2970);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(6197);
/* harmony import */ var _contexts_createHome__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(7327);
/* harmony import */ var _components_CreateHome_ProcessBar_ProccessBar__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(9652);
/* harmony import */ var _components_CreateHome_Step_StepCongratulation__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(2767);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(883);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _components_layouts_authWithoutAnimate__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(6994);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_CreateHome_Step_Header__WEBPACK_IMPORTED_MODULE_2__, _components_CreateHome_Step_Step1CHome__WEBPACK_IMPORTED_MODULE_3__, _components_CreateHome_Step_Step2CHome__WEBPACK_IMPORTED_MODULE_4__, _components_CreateHome_Step_Step3CHome__WEBPACK_IMPORTED_MODULE_5__, _components_CreateHome_Step_Step4CHome__WEBPACK_IMPORTED_MODULE_6__, _components_CreateHome_Step_Step6CHome__WEBPACK_IMPORTED_MODULE_8__, _components_CreateHome_Step_Step7CHome__WEBPACK_IMPORTED_MODULE_9__, _components_CreateHome_Step_Step8CHome__WEBPACK_IMPORTED_MODULE_10__, _components_CreateHome_Step_Step9CHome__WEBPACK_IMPORTED_MODULE_11__, _components_CreateHome_Step_Step10Home__WEBPACK_IMPORTED_MODULE_12__, _components_CreateHome_Step_Step11CHome__WEBPACK_IMPORTED_MODULE_13__, _components_CreateHome_Step_Step12CHome__WEBPACK_IMPORTED_MODULE_14__, _components_CreateHome_Step_Step13CHome__WEBPACK_IMPORTED_MODULE_15__, _components_CreateHome_Step_Step14CHome__WEBPACK_IMPORTED_MODULE_16__, _components_CreateHome_Step_Step15CHome__WEBPACK_IMPORTED_MODULE_17__, _components_CreateHome_Step_Step16CHome__WEBPACK_IMPORTED_MODULE_18__, _components_CreateHome_Step_Step17CHome__WEBPACK_IMPORTED_MODULE_19__, framer_motion__WEBPACK_IMPORTED_MODULE_20__, _components_CreateHome_ProcessBar_ProccessBar__WEBPACK_IMPORTED_MODULE_22__, _components_CreateHome_Step_StepCongratulation__WEBPACK_IMPORTED_MODULE_23__]);
([_components_CreateHome_Step_Header__WEBPACK_IMPORTED_MODULE_2__, _components_CreateHome_Step_Step1CHome__WEBPACK_IMPORTED_MODULE_3__, _components_CreateHome_Step_Step2CHome__WEBPACK_IMPORTED_MODULE_4__, _components_CreateHome_Step_Step3CHome__WEBPACK_IMPORTED_MODULE_5__, _components_CreateHome_Step_Step4CHome__WEBPACK_IMPORTED_MODULE_6__, _components_CreateHome_Step_Step6CHome__WEBPACK_IMPORTED_MODULE_8__, _components_CreateHome_Step_Step7CHome__WEBPACK_IMPORTED_MODULE_9__, _components_CreateHome_Step_Step8CHome__WEBPACK_IMPORTED_MODULE_10__, _components_CreateHome_Step_Step9CHome__WEBPACK_IMPORTED_MODULE_11__, _components_CreateHome_Step_Step10Home__WEBPACK_IMPORTED_MODULE_12__, _components_CreateHome_Step_Step11CHome__WEBPACK_IMPORTED_MODULE_13__, _components_CreateHome_Step_Step12CHome__WEBPACK_IMPORTED_MODULE_14__, _components_CreateHome_Step_Step13CHome__WEBPACK_IMPORTED_MODULE_15__, _components_CreateHome_Step_Step14CHome__WEBPACK_IMPORTED_MODULE_16__, _components_CreateHome_Step_Step15CHome__WEBPACK_IMPORTED_MODULE_17__, _components_CreateHome_Step_Step16CHome__WEBPACK_IMPORTED_MODULE_18__, _components_CreateHome_Step_Step17CHome__WEBPACK_IMPORTED_MODULE_19__, framer_motion__WEBPACK_IMPORTED_MODULE_20__, _components_CreateHome_ProcessBar_ProccessBar__WEBPACK_IMPORTED_MODULE_22__, _components_CreateHome_Step_StepCongratulation__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






























const CreateHome = ({ keyMapBing , api_url_path  })=>{
    const [currentStep, setCurrentStep] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [isMounted, setIsMounted] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_26__.initializeSSR)();
    const handleNextStep = ()=>{
        setIsMounted(false); // Gán giá trị false để unmount component
        setTimeout(()=>{
            setCurrentStep((prevStep)=>prevStep + 1);
            setIsMounted(true); // Gán giá trị true để mount component tiếp theo
        }, 1000); // Thời gian delay trước khi chuyển sang component tiếp theo
    };
    const handleBackStep = ()=>{
        setIsMounted(false); // Gán giá trị false để unmount component
        setTimeout(()=>{
            setCurrentStep((prevStep)=>prevStep - 1);
            setIsMounted(true); // Gán giá trị true để mount component tiếp theo
        }, 1000); // Thời gian delay trước khi chuyển sang component tiếp theo
    };
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_createHome__WEBPACK_IMPORTED_MODULE_21__/* .newHouseContext */ .y);
    let steps = [
        {
            number: 1,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step1CHome__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            data: ""
        },
        {
            number: 2,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step2CHome__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            data: "type"
        },
        {
            number: 3,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step3CHome__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            data: "place"
        },
        {
            number: 4,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step4CHome__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                keyMapBing: keyMapBing
            }),
            data: "address"
        },
        {
            number: 5,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step5CHome__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                keyMapBing: keyMapBing
            }),
            data: "addressConfirmation"
        },
        {
            number: 6,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step6CHome__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
            data: "placeInfo"
        },
        {
            number: 7,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step7CHome__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
            data: "kindOfBathrooms"
        },
        {
            number: 8,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step8CHome__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
            data: "encounter"
        },
        {
            number: 9,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step9CHome__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
            data: ""
        },
        {
            number: 10,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step10Home__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
            data: "amenities"
        },
        {
            number: 11,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step11CHome__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                api_url_path: api_url_path
            }),
            data: ""
        },
        {
            number: 12,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step12CHome__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
            data: "title"
        },
        {
            number: 13,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step13CHome__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
            data: "description"
        },
        {
            number: 14,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step14CHome__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {}),
            data: ""
        },
        {
            number: 15,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step15CHome__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}),
            data: "guest"
        },
        {
            number: 16,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step16CHome__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
            data: "price"
        },
        {
            number: 17,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Step17CHome__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {}),
            data: "note"
        },
        {
            number: 18,
            component: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_StepCongratulation__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
                api_url_path: api_url_path
            }),
            data: ""
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_createHome__WEBPACK_IMPORTED_MODULE_21__/* .CreateHouseProvider */ .H, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(next_font_google_target_css_path_src_pages_createhome_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_28___default().className)}`,
                children: [
                    currentStep > 0 && currentStep <= 17 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_Step_Header__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_20__.AnimatePresence, {
                        children: currentStep > 0 && currentStep <= 18 && currentStep === steps[currentStep - 1].number && isMounted && steps[currentStep - 1].component
                    }),
                    currentStep > 0 && currentStep <= 17 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_CreateHome_ProcessBar_ProccessBar__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                        steps: steps,
                        handleBackStep: handleBackStep,
                        handleNextStep: handleNextStep,
                        currentStep: currentStep
                    })
                ]
            })
        })
    });
};
CreateHome.Layout = _components_layouts_authWithoutAnimate__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z;
const getServerSideProps = async ({ req , res  })=>{
    const session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_24__.getServerSession)(req, res, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_25__/* .authOptions */ .L);
    const keyMapBing = process.env.ACCESS_TOKEN_BINGMAP;
    const api_url_path = process.env.API_URL_PATH;
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_26__.initializeSSR)();
    // if user available not callback api from server
    if (!session?.userAcc) {
        res.setHeader("location", "/login");
        res.statusCode = 302;
        res.end();
        return {
            props: {}
        };
    }
    return {
        props: {
            keyMapBing: keyMapBing,
            api_url_path: api_url_path
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateHome);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7991:
/***/ ((module) => {

"use strict";
module.exports = require("bing-maps-loader");

/***/ }),

/***/ 5538:
/***/ ((module) => {

"use strict";
module.exports = require("bingmaps");

/***/ }),

/***/ 1711:
/***/ ((module) => {

"use strict";
module.exports = require("filepond-plugin-image-exif-orientation");

/***/ }),

/***/ 8984:
/***/ ((module) => {

"use strict";
module.exports = require("filepond-plugin-image-preview");

/***/ }),

/***/ 3227:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 5178:
/***/ ((module) => {

"use strict";
module.exports = require("react-filepond");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/hi");

/***/ }),

/***/ 4041:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/md");

/***/ }),

/***/ 8098:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ri");

/***/ }),

/***/ 5452:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/rx");

/***/ }),

/***/ 4152:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ }),

/***/ 4009:
/***/ ((module) => {

"use strict";
module.exports = import("react-intersection-observer");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,664,170,298,636,675,715,445,312,705,536,539,656,209], () => (__webpack_exec__(4517)));
module.exports = __webpack_exports__;

})();