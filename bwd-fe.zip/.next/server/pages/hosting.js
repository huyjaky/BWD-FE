(() => {
var exports = {};
exports.id = 225;
exports.ids = [225,748];
exports.modules = {

/***/ 6377:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Montserrat_097b2d', '__Montserrat_Fallback_097b2d'","fontStyle":"normal"},
	"className": "__className_097b2d",
	"variable": "__variable_097b2d"
};


/***/ }),

/***/ 7358:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const ButtonReservations = ({ content , number , selected , setSelected  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        onClick: ()=>setSelected(content),
        className: `px-[16px] border-[2px] ${content === selected ? "border-black bg-[#F7F7F7]" : "border-colorButtonHeader bg-transparent"} rounded-[32px] h-[40px]
            hover:border-black ease-in duration-200 mr-[16px] mb-[16px] text-[14px]`,
        children: [
            content,
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "ml-1",
                children: [
                    "(",
                    number,
                    ")"
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonReservations);


/***/ }),

/***/ 440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



function ButtonRounded(props) {
    const { image , icon , title  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        className: "w-[45px] h-[45px] rounded-[50%] border flex items-center justify-center p-1",
        children: [
            icon && icon,
            image && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                src: image,
                alt: "avatar",
                className: "object-cover"
            }),
            title && title
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonRounded);


/***/ }),

/***/ 5325:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _public_assets_Logo_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2834);
/* harmony import */ var _ButtonRounded__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(440);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6197);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _MenuMobile__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3743);
/* harmony import */ var _Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6946);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_7__, _MenuMobile__WEBPACK_IMPORTED_MODULE_9__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_7__, _MenuMobile__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













function Header() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const handleCreatehome = ()=>{
        router.push("/createhome");
    };
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [activeMenu, setActiveMenu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [toggleMenu, settoggleMenu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleActive = (title)=>{
        setActive(title);
    };
    const handleMenu = ()=>{
        setActiveMenu(!activeMenu);
        settoggleMenu(!toggleMenu);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex justify-between h-[70px] items-center px-[20px] border-[1px] border-b-[#e4e4e4]",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_12___default()), {
                href: "/homepage",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        width: 70,
                        height: 70,
                        src: _public_assets_Logo_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                        alt: "Logo"
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "flex gap-3 text-[14px] font-semibold mobile:hidden ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "relative",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>handleActive("Today"),
                                    className: `py-[10px] px-[16px] rounded-[30px] hover:bg-[#F7F7F7] ${active === "Today" ? "text-black" : "text-[#717171]"}
                        before:absolute before:content-[""] before:w-0 before:h-[2px] before:bg-black before:left-4 before:bottom-2
                        before::ease-in-out before:duration-500
                        hover:before:w-[60%]


                    `,
                                    children: "Today"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "relative",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>handleActive("Inbox"),
                                    className: `py-[10px] px-[16px] rounded-[30px] hover:bg-[#F7F7F7] ${active === "Inbox" ? "text-black" : "text-[#717171]"}
                        before:absolute before:content-[""] before:w-0 before:h-[2px] before:bg-black before:left-4 before:bottom-2
                        before::ease-in-out before:duration-500
                        hover:before:w-[60%]
                    `,
                                    children: "Inbox"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "relative",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>handleActive("Calendar"),
                                    className: `py-[10px] px-[16px] rounded-[30px] hover:bg-[#F7F7F7] ${active === "Calendar" ? "text-black" : "text-[#717171]"}
                        before:absolute before:content-[""] before:w-0 before:h-[2px] before:bg-black before:left-4 before:bottom-2
                        before::ease-in-out before:duration-500
                        hover:before:w-[60%]
                    `,
                                    children: "Calendar"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "relative",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                    onClick: ()=>handleMenu(),
                                    className: `py-[10px] px-[16px] rounded-[30px] hover:bg-[#F7F7F7] ${activeMenu ? "text-black" : "text-[#717171]"} flex items-center
                                before:absolute before:content-[""] before:w-0 before:h-[2px] before:bg-black before:left-4 before:bottom-2
                                before:ease-in-out before:duration-500
                                hover:before:w-[60%]
                    `,
                                    children: [
                                        "Menu ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_6__.IoIosArrowDown, {
                                            className: "ml-1"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-[200px] absolute right-[35%] top-[11%] bg-[rgba(255,255,255,.25)]
                shadow-shadowHeadhost  rounded-[13px] mobile:hidden ${toggleMenu ? "h-[40px] ease-in-out duration-500" : "h-0"}  `,
                children: toggleMenu && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.ul, {
                    className: "h-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.li, {
                        initial: {
                            opacity: 0
                        },
                        animate: {
                            opacity: 1
                        },
                        transition: {
                            duration: 0.5
                        },
                        className: "text-[12px] h-[0%]",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            onClick: handleCreatehome,
                            className: `w-[100%] h-[100%] p-[20px] text-start flex justify-between items-center rounded-[13px] hover:bg-[#F7F7F7] ${active === "Create a new listing" ? "text-black" : "text-[#717171]"} flex items-center justify-center
                            `,
                            children: [
                                "Create a new listing",
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-[20px]",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_10__/* .CreateList */ .tg, {
                                        className: ""
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MenuMobile__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                toggleMenu: toggleMenu,
                active: active,
                setActive: setActive
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex gap-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "desktop:hidden laptop:hidden tablet:hidden  ",
                        onClick: ()=>settoggleMenu(!toggleMenu),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ButtonRounded__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            icon: toggleMenu ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_8__.AiOutlineClose, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_8__.AiOutlineMenu, {})
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ButtonRounded__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__.BsBell, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ButtonRounded__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        image: _public_assets_Logo_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4300:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1403);
/* harmony import */ var _ButtonReserations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7358);
/* harmony import */ var _Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6946);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4009);
/* harmony import */ var _components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6813);
/* harmony import */ var _contexts_amountTabHosting__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(432);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3708);
/* harmony import */ var _components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1964);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_5__, react_intersection_observer__WEBPACK_IMPORTED_MODULE_6__, _components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_7__, _components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_10__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_5__, react_intersection_observer__WEBPACK_IMPORTED_MODULE_6__, _components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_7__, _components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












function Main({ keyMapBing , api_url_path  }) {
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Currently hosting");
    const { currentHosting  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_amountTabHosting__WEBPACK_IMPORTED_MODULE_8__/* .AmountTabHostingContext */ .b);
    const [refButton, inViewButton] = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_6__.useInView)({
        // Kích hoạt nhiều lần khi vào khung nhìn
        threshold: 0.01 // Ngưỡng nhìn thấy (tỷ lệ của phần tử nằm trong khung nhìn)
    });
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_9__/* .userAccContext */ .G);
    const componentVariants = {
        offscreen: {
            opacity: 0
        },
        onscreen: {
            opacity: 1
        }
    };
    const buttonVariants = {
        offscreen: {
            opacity: 0,
            y: -50
        },
        onscreen: {
            opacity: 1,
            y: 0
        }
    };
    const animationVariants = {
        hidden: {
            opacity: 0,
            y: 50
        },
        visible: {
            opacity: 1,
            y: 0
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        console.log(currentHosting);
    }, [
        currentHosting
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-[100%]",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-[100%] px-[80px] mobile:px-[0]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                        variants: componentVariants,
                        initial: "offscreen",
                        whileInView: "onscreen",
                        viewport: {
                            amount: 0.5
                        },
                        className: "w-[100%] pt-[64px] mobile:mx-[20px]",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                            className: "text-[32px] font-semibold",
                            children: [
                                "Welcome back ",
                                user.UserName
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[100%] py-[64px]",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                    variants: componentVariants,
                                    initial: "offscreen",
                                    whileInView: "onscreen",
                                    viewport: {
                                        amount: 0.5
                                    },
                                    className: "flex justify-between mb-[16px] mobile:mx-[20px]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                            className: "text-[26px] font-semibold",
                                            children: "Your reservations"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "underline text-[16px] font-semibold",
                                                children: "All reservations (0)"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                    variants: componentVariants,
                                    initial: "offscreen",
                                    whileInView: "onscreen",
                                    viewport: {
                                        amount: 0.5
                                    },
                                    className: "flex flex-wrap mobile:mx-[20px]",
                                    children: _utils_constants__WEBPACK_IMPORTED_MODULE_2__/* .reservations.map */ .Q.map((reservation, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                            initial: {
                                                opacity: 0,
                                                y: -30
                                            },
                                            animate: {
                                                opacity: 1,
                                                y: 0
                                            },
                                            whileInView: {
                                                opacity: 1
                                            },
                                            viewport: {
                                                amount: 0.5
                                            },
                                            className: "",
                                            transition: {
                                                type: "spring",
                                                stiffness: 35,
                                                delay: 0.1 * index
                                            },
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ButtonReserations__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                selected: selected,
                                                setSelected: setSelected,
                                                content: reservation.title,
                                                number: reservation.title === "Currently hosting" ? currentHosting : 0
                                            })
                                        }, index))
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                    variants: componentVariants,
                                    initial: "offscreen",
                                    whileInView: "onscreen",
                                    className: "bg-[#F7F7F7] h-fit flex items-center justify-center rounded-[12px] box-border   px-4 transition-all mobile:px-0   ",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "w-full h-fit transition-all duration-1000",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                                className: `w-full h-fit ${selected === "Currently hosting" ? "" : "hidden"}`,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                                        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_11__/* .staggerContainer */ .Jm)(null, null),
                                                        initial: "hidden",
                                                        whileInView: "show",
                                                        viewport: {
                                                            once: false,
                                                            amount: 0.25
                                                        },
                                                        className: ` mx-auto flex-col `,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                            title: "House for rent",
                                                            textStyles: " w-full h-fit "
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        infShow: "houseForRent",
                                                        keyMapBing: keyMapBing,
                                                        api_url_path: api_url_path
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                                        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_11__/* .staggerContainer */ .Jm)(null, null),
                                                        initial: "hidden",
                                                        whileInView: "show",
                                                        viewport: {
                                                            once: false,
                                                            amount: 0.25
                                                        },
                                                        className: ` mx-auto flex-col `,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                            title: "House for sale",
                                                            textStyles: " w-full h-fit "
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                                        infShow: "houseForSale",
                                                        keyMapBing: keyMapBing,
                                                        api_url_path: api_url_path
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: `${selected === "Currently hosting" ? "hidden" : ""} flex flex-col items-center justify-center gap-4 py-24 `,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_4__/* .AnyReview */ .U, {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-[14px] h-[36px] w-[200px] text-center",
                                                        children: "You don't have any guest reviews to write."
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                variants: componentVariants,
                initial: "offscreen",
                whileInView: "onscreen",
                viewport: {
                    amount: 0.01
                },
                className: "bg-[#F9F7F4] w-[100%] h-[195px]",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                    variants: componentVariants,
                    initial: "offscreen",
                    whileInView: "onscreen",
                    viewport: {
                        amount: 0.5
                    },
                    className: "px-[80px] mobile:px-0 py-[64px]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "text-[26px] font-semibold",
                            children: "Share more details"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-[15px] font-extralight",
                            children: "Check, check, check! You’re all set for now."
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[100%] px-[80px] mobile:px-0 flex flex-col gap-3 mt-[64px]",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.h1, {
                            variants: componentVariants,
                            initial: "offscreen",
                            whileInView: "onscreen",
                            viewport: {
                                amount: 0.5
                            },
                            className: "text-[26px] font-semibold mb-3",
                            children: "We’re here to help"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-[100%] flex mobile:flex-col gap-2 mb-10",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                    variants: buttonVariants,
                                    className: "w-[45%] laptop:w-[50%] mobile:w-[100%] tablet:w-full h-[92px] flex p-[16px] gap-3 border rounded-[10px] cursor-pointer",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "mb-[4px]",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_4__/* .SuperHost */ .tI, {})
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-[100%]",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                    className: "text-[16px] font-semibold",
                                                    children: "Guidance from a Superhost"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-[13px] text-[#717171] font-thin w-[90%]",
                                                    children: "We'll match you with an experienced Host who can you get started"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-[100%]",
                                    ref: refButton,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                        variants: animationVariants,
                                        className: "w-[45%] laptop:w-[50%] mobile:w-[100%] tablet:w-full h-[92px] flex p-[16px] gap-3 border rounded-[10px] cursor-pointer",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mb-[4px]",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_4__/* .ContactSupport */ .p8, {})
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "w-[100%]",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                        className: "text-[16px] font-semibold",
                                                        children: "Contact specialized support"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-[13px] text-[#717171] font-thin w-[90%]",
                                                        children: "As a new Host, you get one-tap access to a specially trained support team."
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Main);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3743:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6946);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const MenuMobile = ({ toggleMenu , active , setActive  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const handleCreatehome = ()=>{
        router.push("/createhome");
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `z-0 flex-col bg-[rgba(255,255,255,.25)]
                        shadow-shadowHeadhost  rounded-[13px] absolute
                        right-[20px] top-[80px] ${toggleMenu ? "h-[170px] ease-in-out duration-500" : "h-0"} tablet:hidden desktop:hidden laptop:hidden`,
        children: toggleMenu && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
            className: "flex text-[14px] font-semibold  z-50 flex-col bg-[rgba(255,255,255,.25)] shadow-shadowHeadhost backdrop-blur-[4px] rounded-[13px] right-[150px] w-[200px] h-full ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.li, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    transition: {
                        duration: 0.5,
                        delay: 0.1
                    },
                    className: "relative",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: ()=>setActive("Today"),
                        className: `w-[100%] h-[40px] p-[20px] text-start flex justify-between items-center rounded-b-none rounded-t-[13px] hover:bg-[#F7F7F7] ${active === "Today" ? "text-black" : "text-[#717171]"}                      
                            before:absolute before:content-[""] before:w-0 before:h-[2px] before:bg-black before:left-4 before:bottom-0
                            before::ease-in-out before:duration-500
                            hover:before:w-[85%]
                `,
                        children: [
                            "Today ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_2__/* .Today */ .tf, {})
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.li, {
                    className: "relative",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    transition: {
                        duration: 0.5,
                        delay: 0.2
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: ()=>setActive("Inbox"),
                        className: `w-[100%] h-[40px] p-[20px] text-start flex justify-between items-center rounded-none hover:bg-[#F7F7F7] ${active === "Inbox" ? "text-black" : "text-[#717171]"}
                            before:absolute before:content-[""] before:w-0 before:h-[2px] before:bg-black before:left-4 before:bottom-0
                        before::ease-in-out before:duration-500
                        hover:before:w-[85%]
                 `,
                        children: [
                            "Inbox",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_2__/* .Inbox */ .mn, {}),
                            " "
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.li, {
                    className: "relative",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    transition: {
                        duration: 0.5,
                        delay: 0.3
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: ()=>setActive("Calendar"),
                        className: `w-[100%] h-[40px] p-[20px] text-start flex justify-between items-center rounded-none hover:bg-[#F7F7F7] ${active === "Calendar" ? "text-black" : "text-[#717171]"}
                        before:absolute before:content-[""] before:w-0 before:h-[2px] before:bg-black before:left-4 before:bottom-0
                        before::ease-in-out before:duration-500
                        hover:before:w-[85%]
                `,
                        children: [
                            "Calendar",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_2__/* .Calendar */ .f, {}),
                            " "
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.li, {
                    className: "relative",
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    transition: {
                        duration: 0.5,
                        delay: 0.4
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: handleCreatehome,
                        className: `w-[100%] h-[44px] p-[20px] text-start flex justify-between items-center rounded-t-none rounded-b-[13px] hover:bg-[#F7F7F7]  text-[#717171]
                        before:absolute before:content-[""] before:w-0 before:h-[2px] before:bg-black before:left-4 before:bottom-0
                        before::ease-in-out before:duration-500
                        hover:before:w-[85%]
                `,
                        children: [
                            "Create a new listing ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Icon_BnB_svg__WEBPACK_IMPORTED_MODULE_2__/* .CreateList */ .tg, {
                                className: ""
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenuMobile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Q": () => (/* binding */ reservations)
});

// UNUSED EXPORTS: Resourcesandtips

;// CONCATENATED MODULE: ./src/components/Hosting/img/PaidforHosting.webp
/* harmony default export */ const PaidforHosting = ({"src":"/_next/static/media/PaidforHosting.4091c216.webp","height":240,"width":320,"blurDataURL":"data:image/webp;base64,UklGRlIAAABXRUJQVlA4IEYAAADwAQCdASoIAAYAAkA4JZgCdAEXfpnFfAAA4n3465E9G7/mTv1YSLXLSfz+epOEgJnI+Z/noiKqkFkn5YtYLljnfcbFSwAA","blurWidth":8,"blurHeight":6});
;// CONCATENATED MODULE: ./src/components/Hosting/img/WriteaDescription.webp
/* harmony default export */ const WriteaDescription = ({"src":"/_next/static/media/WriteaDescription.babd012a.webp","height":180,"width":320,"blurDataURL":"data:image/webp;base64,UklGRlAAAABXRUJQVlA4IEQAAADQAQCdASoIAAUAAkA4JYgCdAD0IMTqAADOPy37l9fl1XloOGnCt3P8qhnSEftfhWyXo9Er/asfOuGVEheYgOy3mInAAA==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/components/Hosting/img/PricingStrategy.webp
/* harmony default export */ const PricingStrategy = ({"src":"/_next/static/media/PricingStrategy.349fc0c6.webp","height":180,"width":320,"blurDataURL":"data:image/webp;base64,UklGRlYAAABXRUJQVlA4IEoAAAAQAgCdASoIAAUAAkA4JbACdLoAArmssL0gAP76tw1UQ0FFzBCNS8H8P4lYY0PHkPNI1jj04ITRV8+gzstI4B8nQRj1CK3xwAAAAA==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/components/Hosting/img/setCalendarAndBooking.webp
/* harmony default export */ const setCalendarAndBooking = ({"src":"/_next/static/media/setCalendarAndBooking.1f4b6f51.webp","height":180,"width":320,"blurDataURL":"data:image/webp;base64,UklGRkgAAABXRUJQVlA4IDwAAACwAQCdASoIAAUAAkA4JQBOgB6Rk9GwAP7uT+8hIuMgtUDFR9yQ/NawWOS5IHhbEbJNAuUmJdeGQAxQAAA=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/components/Hosting/utils/constants.tsx




const reservations = [
    {
        title: "Currently hosting",
        number: 0
    },
    {
        title: "Checking out",
        number: 0
    },
    {
        title: "Arriving soon",
        number: 0
    },
    {
        title: "Upcoming",
        number: 0
    },
    {
        title: "Pending review",
        number: 0
    }
];
const Resourcesandtips = [
    {
        ImgLink: PaidforHosting,
        title: "How to get paid for hosting"
    },
    {
        ImgLink: setCalendarAndBooking,
        title: "The best way to set your calendar and booking..."
    },
    {
        ImgLink: PricingStrategy,
        title: "How to set your pricing strategy"
    },
    {
        ImgLink: WriteaDescription,
        title: "How to write a listing description that work"
    }
];


/***/ }),

/***/ 9167:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_pages_hosting_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6377);
/* harmony import */ var next_font_google_target_css_path_src_pages_hosting_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_pages_hosting_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Hosting_components_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5325);
/* harmony import */ var _components_Hosting_components_Main__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4300);
/* harmony import */ var _components_footers_footerRooms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2883);
/* harmony import */ var _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(231);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(883);
/* harmony import */ var _components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3446);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Hosting_components_Header__WEBPACK_IMPORTED_MODULE_1__, _components_Hosting_components_Main__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_4__, _components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_8__]);
([_components_Hosting_components_Header__WEBPACK_IMPORTED_MODULE_1__, _components_Hosting_components_Main__WEBPACK_IMPORTED_MODULE_2__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_4__, _components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Index = ({ keyMapBing , api_url_path  })=>{
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_5__.initializeSSR)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: `${(next_font_google_target_css_path_src_pages_hosting_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_9___default().className)} overflow-x-hidden mobile:overflow-y-hidden`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Hosting_components_Header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Hosting_components_Main__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    keyMapBing: keyMapBing,
                    api_url_path: api_url_path
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footers_footerRooms__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
            ]
        })
    });
};
Index.Layout = _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);
const getServerSideProps = async ({ req , res  })=>{
    const session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_6__.getServerSession)(req, res, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_7__/* .authOptions */ .L);
    const keyMapBing = process.env.ACCESS_TOKEN_BINGMAP;
    const api_url_path = process.env.API_URL_PATH;
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_5__.initializeSSR)();
    if (!session?.userAcc) {
        res.setHeader("location", "/login");
        res.statusCode = 302;
        res.end();
        return {
            props: {}
        };
    }
    return {
        props: {
            keyMapBing: keyMapBing,
            api_url_path: api_url_path
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7991:
/***/ ((module) => {

"use strict";
module.exports = require("bing-maps-loader");

/***/ }),

/***/ 1711:
/***/ ((module) => {

"use strict";
module.exports = require("filepond-plugin-image-exif-orientation");

/***/ }),

/***/ 8984:
/***/ ((module) => {

"use strict";
module.exports = require("filepond-plugin-image-preview");

/***/ }),

/***/ 3227:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 808:
/***/ ((module) => {

"use strict";
module.exports = require("nprogress");

/***/ }),

/***/ 1817:
/***/ ((module) => {

"use strict";
module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 5178:
/***/ ((module) => {

"use strict";
module.exports = require("react-filepond");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 8547:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gr");

/***/ }),

/***/ 1111:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/hi");

/***/ }),

/***/ 924:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/im");

/***/ }),

/***/ 4751:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io");

/***/ }),

/***/ 4041:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/md");

/***/ }),

/***/ 8098:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ri");

/***/ }),

/***/ 4152:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/tb");

/***/ }),

/***/ 4336:
/***/ ((module) => {

"use strict";
module.exports = require("react-infinite-scroll-component");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ }),

/***/ 5563:
/***/ ((module) => {

"use strict";
module.exports = import("popmotion");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 4009:
/***/ ((module) => {

"use strict";
module.exports = import("react-intersection-observer");;

/***/ }),

/***/ 4275:
/***/ ((module) => {

"use strict";
module.exports = import("react-loading-skeleton");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,664,170,298,636,675,715,445,875,312,91,231,565,515,536,913,765,656,209,813], () => (__webpack_exec__(9167)));
module.exports = __webpack_exports__;

})();