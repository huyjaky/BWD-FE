(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 8725:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Montserrat_097b2d', '__Montserrat_Fallback_097b2d'","fontStyle":"normal"},
	"className": "__className_097b2d",
	"variable": "__variable_097b2d"
};


/***/ }),

/***/ 8194:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const axiosClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "/api",
    headers: {
        "Content-Type": "application/json"
    }
});
// Add a response interceptor
axiosClient.interceptors.response.use(function(response) {
    // Any status code that lie within the range of 2xx cause this function to trigger
    // Do something with response data
    return response;
}, function(error) {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    return {
        error: error
    };
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const EmptyLayout = ({ children  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmptyLayout);


/***/ }),

/***/ 8705:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export imgFileContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const imgFileDefaultData = {
    imgArr: [],
    setImgArr: ()=>{}
};
const imgFileContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(imgFileDefaultData);
const ImgFileProvider = ({ children  })=>{
    const [imgArr, setImgArr_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(imgFileDefaultData.imgArr);
    const setImgArr = (payload)=>setImgArr_(payload);
    const imgFileDynamicData = {
        imgArr,
        setImgArr
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(imgFileContext.Provider, {
        value: imgFileDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImgFileProvider);


/***/ }),

/***/ 9212:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_pages_app_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(8725);
/* harmony import */ var next_font_google_target_css_path_src_pages_app_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_pages_app_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8194);
/* harmony import */ var _components_layouts_empty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9465);
/* harmony import */ var _contexts_placeList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3903);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9445);
/* harmony import */ var _contexts_selectPopover__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3528);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(108);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var mapbox_gl_dist_mapbox_gl_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5991);
/* harmony import */ var mapbox_gl_dist_mapbox_gl_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(mapbox_gl_dist_mapbox_gl_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var rc_slider_assets_index_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2950);
/* harmony import */ var rc_slider_assets_index_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(rc_slider_assets_index_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(886);
/* harmony import */ var react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_date_range_dist_styles_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8130);
/* harmony import */ var react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_date_range_dist_theme_default_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6593);
/* harmony import */ var react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_loading_skeleton_dist_skeleton_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8890);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5941);
/* harmony import */ var _contexts_amountTabHosting__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(432);
/* harmony import */ var _contexts_bill__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2357);
/* harmony import */ var _contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1477);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3565);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1705);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6648);
/* harmony import */ var _contexts_houseTemp__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(1790);
/* harmony import */ var _contexts_imgFile__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8705);
/* harmony import */ var _contexts_isShowPt__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(1069);
/* harmony import */ var _contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(8047);
/* harmony import */ var _contexts_selectHouse__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(2586);
/* harmony import */ var _contexts_stepCreate__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(9747);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(3708);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_29__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__, swr__WEBPACK_IMPORTED_MODULE_13__]);
([_api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__, swr__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










 // main css file
 // theme css file



















function App({ Component , pageProps: { session , ...pageProps }  }) {
    const Layout = Component.Layout ?? _components_layouts_empty__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_28___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Olympus"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_29___default()), {
                        src: "https://www.bing.com/api/maps/mapcontrol?callback=GetMapCallback&key=AiWimzL8WC5fWxhKerTLiSvd63qgv22WhCiBLgm63xMJ-nn1Mv9SMqYpLPB4nkMI",
                        async: true,
                        defer: true
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swr__WEBPACK_IMPORTED_MODULE_13__.SWRConfig, {
                value: {
                    fetcher: (url)=>_api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(url),
                    shouldRetryOnError: false
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_selectPopover__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_placeList__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_filter__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_bill__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_auth_react__WEBPACK_IMPORTED_MODULE_27__.SessionProvider, {
                                                        session: session,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_isShowPt__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_amountTabHosting__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_imgFile__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_selectHouse__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_houseTemp__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_stepCreate__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Layout, {
                                                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                                            className: `${(next_font_google_target_css_path_src_pages_app_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_30___default().className)} bg-white
                                        `,
                                                                                            children: [
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((nextjs_progressbar__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                                                                    color: "#B80F0A",
                                                                                                    height: 7
                                                                                                }),
                                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                                                                                    ...pageProps
                                                                                                })
                                                                                            ]
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        })
                                                                    })
                                                                })
                                                            })
                                                        })
                                                    })
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5991:
/***/ (() => {



/***/ }),

/***/ 2950:
/***/ (() => {



/***/ }),

/***/ 886:
/***/ (() => {



/***/ }),

/***/ 8130:
/***/ (() => {



/***/ }),

/***/ 6593:
/***/ (() => {



/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 8890:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

"use strict";
module.exports = import("swr");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,170,298,864,445,565,856,186,667,665], () => (__webpack_exec__(9212)));
module.exports = __webpack_exports__;

})();