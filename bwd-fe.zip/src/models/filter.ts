export interface filterForm {
  maxPrice: number;
  minPrice: number;
  beds: number;
  bathRooms: number;
  typeHouse: string[];
  amenities: string[];
  hostLanguage: string;
  orientation:string;
}

export interface amenities {
  // essentials: string[];
  // features: string[];
  // location: string[];
  // safety: string[];
}
