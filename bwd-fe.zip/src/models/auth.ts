export interface LoginPayload {
  username: string;
  password: string;
}
