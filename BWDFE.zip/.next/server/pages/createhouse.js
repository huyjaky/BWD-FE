"use strict";
(() => {
var exports = {};
exports.id = 420;
exports.ids = [420,748];
exports.modules = {

/***/ 69:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _typeCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(380);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_typeCard__WEBPACK_IMPORTED_MODULE_2__]);
_typeCard__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const ChooseTypeHouse = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-fit grid grid-cols-2 grid-rows-1 mt-[6rem]   mobile:grid-cols-1 mobile:gap-y-3   mobile:grid-rows-2   ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "border-r-2 mobile:border-0",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typeCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    title: "House For Rent",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_3__.HiOutlineKey, {})
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typeCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                title: "House For Sale",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_1__.BsHouses, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChooseTypeHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 380:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1477);
/* harmony import */ var _contexts_stepCreate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9747);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const TypeCard = ({ children , title  })=>{
    const { typeHouseId , setTypeHouseId  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_1__/* .createHouseFormContext */ .F);
    const { setStepCreate  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_stepCreate__WEBPACK_IMPORTED_MODULE_2__/* .StepCreateHomeContext */ .G);
    const handleOnClick = (event)=>{
        const updatedTypeHouseId = [
            ...typeHouseId
        ];
        // Kiểm tra xem item.title đã tồn tại trong mảng hay chưa
        if (title === "House for rent") {
            const index = updatedTypeHouseId.indexOf("4");
            updatedTypeHouseId.splice(index, 1); // Loại bỏ phần tử nếu đã tồn tại
            updatedTypeHouseId.push("5"); // Thêm phần tử nếu chưa tồn tại
        } else {
            const index = updatedTypeHouseId.indexOf("5");
            updatedTypeHouseId.splice(index, 1); // Loại bỏ phần tử nếu đã tồn tại
            updatedTypeHouseId.push("4"); // Thêm phần tử nếu chưa tồn tại
        }
        // Cập nhật giá trị mới của typeHouseId
        setTypeHouseId(updatedTypeHouseId);
        setStepCreate(2);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-fit flex ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            onClick: handleOnClick,
            className: "w-[60%] h-[25rem] m-auto bg-emerald-400 flex rounded-2xl text-center   flex-col",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                    className: "m-auto rounded-full p-5 text-[15rem]",
                    children: children
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "text-[25px] box-border py-4",
                    children: title
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TypeCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1731:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1477);
/* harmony import */ var _contexts_stepCreate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9747);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1711);
/* harmony import */ var filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8984);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(391);
/* harmony import */ var filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1137);
/* harmony import */ var filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5178);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_filepond__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _api_client_houseApi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(860);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__, _api_client_houseApi__WEBPACK_IMPORTED_MODULE_11__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_3__, _api_client_houseApi__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












(0,react_filepond__WEBPACK_IMPORTED_MODULE_9__.registerPlugin)((filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_5___default()), (filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_6___default()));
const FinishPage = ({ api_url_path  })=>{
    const [key, setKey] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0);
    const { createHouseForm , imgArr , typeHouseId , Address  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_1__/* .createHouseFormContext */ .F);
    const { stepCreate  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_stepCreate__WEBPACK_IMPORTED_MODULE_2__/* .StepCreateHomeContext */ .G);
    const filePondRef = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_10__.useSession)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        setKey((prevKey)=>prevKey + 1);
    }, [
        stepCreate
    ]);
    const handleOnClick = async (event)=>{
        console.log(createHouseForm);
        console.log(imgArr);
        console.log(typeHouseId);
        if (filePondRef.current) {
            await filePondRef.current.processFiles();
        }
        try {
            if (createHouseForm) {
                const data0 = {
                    ...createHouseForm,
                    address: Address,
                    useracc: session?.userAcc
                };
                await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_11__/* .houseApi.createHouse */ .Y.createHouse(data0, typeHouseId);
            }
        } catch (error) {
            console.log(error);
            return;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_filepond__WEBPACK_IMPORTED_MODULE_9__.FilePond, {
                    ref: filePondRef,
                    files: imgArr,
                    allowMultiple: true,
                    instantUpload: false,
                    maxFiles: 30,
                    maxParallelUploads: 30,
                    // server={`${api_url_path}/api/post/img`}
                    server: {
                        url: api_url_path + "/api",
                        process: {
                            url: "/create/house/img",
                            method: "POST",
                            timeout: 120000
                        }
                    },
                    name: "files" /* sets the file input name, it's filepond by default */ ,
                    labelIdle: 'Drag and drop files <span class="filepond--label-action">Browse</span>',
                    acceptedFileTypes: [
                        "image/jpeg",
                        "image/jpg",
                        "image/png",
                        "image/gif",
                        "image/bmp",
                        "image/svg+xml",
                        "image/webp",
                        "image/tiff",
                        "image/x-icon",
                        "application/pdf"
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-full grid grid-cols-2 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full overflow-hidden flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                            className: "w-[calc(100%-15rem)] h-full m-auto",
                            preload: "auto",
                            autoPlay: true,
                            muted: true,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                src: "./Step3.mp4",
                                className: "w-full h-full"
                            })
                        }, key)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                            onClick: handleOnClick,
                            className: "w-[30rem] h-[3rem] border-2 border-slate-600 m-auto",
                            children: "Done"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FinishPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6564:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_main_showHouse_componentShowHouse_amenities_editAmenities__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8235);
/* harmony import */ var _components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9578);
/* harmony import */ var _contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1477);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1817);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(rc_slider__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _propertyCreateHouse__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2795);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_main_showHouse_componentShowHouse_amenities_editAmenities__WEBPACK_IMPORTED_MODULE_1__, _propertyCreateHouse__WEBPACK_IMPORTED_MODULE_6__]);
([_components_main_showHouse_componentShowHouse_amenities_editAmenities__WEBPACK_IMPORTED_MODULE_1__, _propertyCreateHouse__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const HouseProperties = ({})=>{
    const { createHouseForm , emptyCreateHouseForm , setCreateHouseForm , typeHouseId , setTypeHouseId  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_3__/* .createHouseFormContext */ .F);
    // const [typeHouseId, setTypeHouseId] = useState<string[]>([]);
    const styleInput = "box-border p-3";
    const compass = [
        "West",
        "South",
        "East",
        "North"
    ];
    const [tempHouse, setTempHouse] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(createHouseForm);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        setTempHouse(createHouseForm);
    }, [
        createHouseForm
    ]);
    const handleOnChange = async (value)=>{
        if (createHouseForm) {
            setCreateHouseForm({
                ...createHouseForm,
                Price: value
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-fit bg-white m-auto rounded-3xl   overflow-hidden flex flex-col ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full relative ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full h-fit",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full h-[2.4rem]"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full h-fit   box-border p-7   mobile:p-0   ",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full h-fit grid text-[2rem]   desktop:grid-areas-layoutCreateHouseDesktopLaptop   laptop:grid-areas-layoutCreateHouseDesktopLaptop   tablet:grid-areas-layoutCreateHouseTabletMobile   mobile:grid-areas-layoutCreateHouseTabletMobile      desktop:grid-cols-3 laptop:grid-cols-3   tablet:grid-cols-3 mobile:grid-cols-3   ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-capacity ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: "",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Capacity",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "number",
                                                value: createHouseForm?.Capacity,
                                                onChange: (event)=>{
                                                    if (createHouseForm) {
                                                        setCreateHouseForm({
                                                            ...createHouseForm,
                                                            Capacity: parseInt(event.target.value)
                                                        });
                                                    }
                                                },
                                                className: "w-full h-[3rem] outline-none text-[2rem]"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-baths ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: "",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Baths",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                value: createHouseForm?.NumsOfBath,
                                                onChange: (event)=>{
                                                    if (createHouseForm) {
                                                        setCreateHouseForm({
                                                            ...createHouseForm,
                                                            NumsOfBath: parseInt(event.target.value)
                                                        });
                                                    }
                                                },
                                                type: "number",
                                                className: "w-full h-[3rem] outline-none text-[2rem]"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-beds ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: "",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Beds",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                value: createHouseForm?.NumsOfBed,
                                                onChange: (event)=>{
                                                    if (createHouseForm) {
                                                        setCreateHouseForm({
                                                            ...createHouseForm,
                                                            NumsOfBed: parseInt(event.target.value)
                                                        });
                                                    }
                                                },
                                                type: "number",
                                                className: "w-full h-[3rem] outline-none text-[2rem]"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-orientation ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: "",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Orientation",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                onChange: (event)=>{
                                                    if (createHouseForm) {
                                                        setCreateHouseForm({
                                                            ...createHouseForm,
                                                            Orientation: event.target.value
                                                        });
                                                    }
                                                },
                                                value: createHouseForm?.Orientation,
                                                className: "select px-0 w-full outline-none text-[2rem]",
                                                children: compass.map((item, index)=>{
                                                    if (index == 0) {
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            selected: true,
                                                            children: item
                                                        }, index);
                                                    }
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                        children: item
                                                    }, index);
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-price ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: " before:hidden",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Price",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "w-full h-[3rem] flex mr-0",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((rc_slider__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                        // range
                                                        allowCross: false,
                                                        draggableTrack: true,
                                                        defaultValue: createHouseForm?.Price,
                                                        onChange: handleOnChange,
                                                        value: createHouseForm?.Price,
                                                        className: "m-auto ",
                                                        min: 10,
                                                        max: 7000,
                                                        trackStyle: {
                                                            backgroundColor: "black",
                                                            height: 2
                                                        },
                                                        railStyle: {
                                                            height: 2
                                                        },
                                                        handleStyle: {
                                                            backgroundColor: "#FFFFFF",
                                                            opacity: 1,
                                                            border: "1px solid grey",
                                                            width: 30,
                                                            height: 30,
                                                            marginTop: -13
                                                        }
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "w-[9.375rem] h-full flex ml-5",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            type: "number",
                                                            className: "w-[7.5rem] h-full m-auto   outline-none ",
                                                            value: createHouseForm?.Price,
                                                            onChange: (event)=>{
                                                                if (!createHouseForm) return;
                                                                const temp = parseFloat(event.target.value);
                                                                setCreateHouseForm({
                                                                    ...createHouseForm,
                                                                    Price: temp
                                                                });
                                                            }
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-title ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: "",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Title",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "text",
                                                className: "w-full h-[3rem] outline-none text-[2rem]",
                                                value: createHouseForm?.Title,
                                                onChange: (event)=>{
                                                    if (createHouseForm) {
                                                        setCreateHouseForm({
                                                            ...createHouseForm,
                                                            Title: event.target.value
                                                        });
                                                    }
                                                },
                                                placeholder: "Enter your house title..."
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-des ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: "",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Description",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                value: createHouseForm?.Description,
                                                onChange: (event)=>{
                                                    if (createHouseForm) {
                                                        setCreateHouseForm({
                                                            ...createHouseForm,
                                                            Description: event.target.value
                                                        });
                                                    }
                                                },
                                                placeholder: "Enter the description...",
                                                className: "w-full h-fit  outline-none text-[2rem]"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-placeoffer ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: "",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Amenities",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full h-full mb-5 border-b-2 border-slate-500 py-10",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full h-fit flex flex-col ",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_amenities_editAmenities__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        setTempHouse: setCreateHouseForm,
                                                        tempHouse: createHouseForm
                                                    })
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: `grid-in-typehouse ${styleInput}`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            styleDivAround: "",
                                            styleFieldset: "",
                                            styleLegend: "",
                                            title: "Type",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full h-full mb-5 border-b-2 border-slate-500 py-10",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full h-fit flex flex-col ",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_propertyCreateHouse__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                                        setTypeHouseId: setTypeHouseId,
                                                        typeHouseId: typeHouseId
                                                    })
                                                })
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HouseProperties);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2795:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const variantsPropertyItems = {
    isHover: {
        scale: 1.1
    }
};
const PropertyCreateHouse = ({ typeHouseId , setTypeHouseId  })=>{
    const arrPropertyItems = [
        {
            id: "1",
            title: "House",
            imgPath: "https://a0.muscache.com/pictures/4d7580e1-4ab2-4d26-a3d6-97f9555ba8f9.jpg"
        },
        {
            id: "2",
            title: "Apartment",
            imgPath: "https://a0.muscache.com/pictures/21cfc7c9-5457-494d-9779-7b0c21d81a25.jpg"
        },
        {
            id: "3",
            title: "Guesthouse",
            imgPath: "https://a0.muscache.com/pictures/6f261426-2e47-4c91-8b1a-7a847da2b21b.jpg"
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
    // Cập nhật giá trị mới của typeHouseId
    }, [
        typeHouseId
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "grid grid-cols-3 gap-x-10 mobile:gap-y-5   grid-rows-1 mobile:grid-cols-1 mobile:grid-rows-3",
        children: arrPropertyItems.map((item, index)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full flex justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                    className: `w-full h-[130px] border-2 rounded-2xl box-border p-2 mobile:w-full
              mobile:mb-5
                            ${typeHouseId.includes(item.id) ? "border-black" : ""}
                          `,
                    variants: variantsPropertyItems,
                    whileTap: {
                        scale: 0.8
                    },
                    transition: {
                        duration: 0.5
                    },
                    onClick: (event)=>{
                        const updatedTypeHouseId = [
                            ...typeHouseId
                        ];
                        // Kiểm tra xem item.title đã tồn tại trong mảng hay chưa
                        if (updatedTypeHouseId.includes(item.id)) {
                            const index = updatedTypeHouseId.indexOf(item.id);
                            updatedTypeHouseId.splice(index, 1); // Loại bỏ phần tử nếu đã tồn tại
                        } else {
                            updatedTypeHouseId.push(item.id); // Thêm phần tử nếu chưa tồn tại
                        }
                        // Cập nhật giá trị mới của typeHouseId
                        setTypeHouseId(updatedTypeHouseId);
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex flex-col h-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: `${item.imgPath}`,
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "m-auto mb-2 ml-2",
                                    children: item.title
                                })
                            })
                        ]
                    })
                }, index)
            }, index);
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PropertyCreateHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 865:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8194);
/* harmony import */ var _contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1477);
/* harmony import */ var filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1711);
/* harmony import */ var filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8984);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(391);
/* harmony import */ var filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1137);
/* harmony import */ var filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5178);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_filepond__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__]);
_api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









(0,react_filepond__WEBPACK_IMPORTED_MODULE_8__.registerPlugin)((filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_3___default()), (filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_4___default()));
const ImgCreateHouse = ({ api_url_path  })=>{
    // const [imgArr, setImgArr] = useState<any>([]);
    const { imgArr , setImgArr  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_2__/* .createHouseFormContext */ .F);
    const filePondRef = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{}, [
        imgArr
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_filepond__WEBPACK_IMPORTED_MODULE_8__.FilePond, {
            ref: filePondRef,
            files: imgArr,
            allowMultiple: true,
            instantUpload: false,
            onaddfile: (error, file)=>{
                if (error) return;
                let temp = imgArr;
                temp.push(file);
                setImgArr(temp);
            },
            onremovefile: (error, file)=>{
                if (error) return;
                let temp = imgArr.filter((item)=>{
                    return item.filename != file.filename;
                });
                setImgArr(temp);
            },
            beforeAddFile: async (file)=>{
                if (imgArr.length > 0) {
                    const isExist = await imgArr.some((items)=>items.filename === file.filename);
                    console.log(isExist);
                    return !isExist;
                }
                return true;
            },
            onprocessfilerevert: async (file)=>{
                try {
                    const temp = await _api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post(`/delete/img`, {
                        nameImg: file.filename
                    });
                    if (temp.status == 200) {
                        console.log(temp.data);
                    }
                } catch (error) {
                    console.log(error);
                    return;
                }
            },
            maxFiles: 30,
            maxParallelUploads: 30,
            // server={`${api_url_path}/api/post/img`}
            server: {
                url: api_url_path + "/api",
                process: {
                    url: "/create/house/img",
                    method: "POST",
                    timeout: 120000
                }
            },
            name: "files" /* sets the file input name, it's filepond by default */ ,
            labelIdle: 'Drag and drop files <span class="filepond--label-action">Browse</span>',
            acceptedFileTypes: [
                "image/jpeg",
                "image/jpg",
                "image/png",
                "image/gif",
                "image/bmp",
                "image/svg+xml",
                "image/webp",
                "image/tiff",
                "image/x-icon",
                "application/pdf"
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImgCreateHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1477);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




const MapCreateHouse = ({ setTempHouse , tempHouse , keyMapBing  })=>{
    const { setAddress , Address  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_1__/* .createHouseFormContext */ .F);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_2__.whenLoaded.then(()=>{
            const map_ = document.getElementById("MapEdit7");
            if (map_ && tempHouse) {
                const map = new Microsoft.Maps.Map(map_, {
                    /* No need to set credentials if already passed in URL */ center: new Microsoft.Maps.Location(tempHouse.address.latitude || 16.047079, tempHouse.address.longitude || 108.206230),
                    mapTypeId: Microsoft.Maps.MapTypeId.road,
                    zoom: 16,
                    credentials: keyMapBing,
                    disableScrollWheelZoom: true
                });
                var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), undefined);
                var layer = new Microsoft.Maps.Layer();
                layer.add(pushpin);
                map.layers.insert(layer);
                Microsoft.Maps.loadModule("Microsoft.Maps.AutoSuggest", {
                    callback: ()=>{
                        var options = {
                            maxResults: 5,
                            businessSuggestions: true
                        };
                        var manager = new Microsoft.Maps.AutosuggestManager(options);
                        manager.attachAutosuggest("#searchBox7", "#searchBoxContainer7", (suggestionResult)=>{
                            map.entities.clear();
                            map.setView({
                                bounds: suggestionResult.bestView
                            });
                            var pushpin = new Microsoft.Maps.Pushpin(suggestionResult.location);
                            map.entities.push(pushpin);
                            console.log(suggestionResult);
                            setAddress({
                                ...Address,
                                ...suggestionResult?.address,
                                ...suggestionResult?.location,
                                title: suggestionResult.title
                            });
                        });
                    }
                });
            }
        });
    }, [
        tempHouse?.address.formattedAddress
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-full rounded-3xl border-2 border-red-400 overflow-hidden h-[22rem]`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    id: "MapEdit7",
                    className: "relative z-10"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "searchBoxContainer7",
                className: "box-border px-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    placeholder: "Enter your house locale",
                    id: "searchBox7",
                    type: "text",
                    className: "w-full h-[3rem] outline-none text-[2rem] mt-[3rem]   border-b-2 border-slate-600   "
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapCreateHouse);


/***/ }),

/***/ 5659:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1477);
/* harmony import */ var _contexts_stepCreate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9747);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
framer_motion__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const FooterCreateHome = ()=>{
    const { createHouseForm , imgArr , typeHouseId  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_1__/* .createHouseFormContext */ .F);
    const { stepCreate , setStepCreate  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_stepCreate__WEBPACK_IMPORTED_MODULE_2__/* .StepCreateHomeContext */ .G);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed w-full bottom-0 border-t-2 h-[5rem] bg-white",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full h-full grid grid-cols-2",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-full flex justify-start box-border py-2 pl-5",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                        onClick: ()=>{
                            setStepCreate(stepCreate < 2 ? stepCreate : stepCreate - 1);
                        },
                        className: "h-full w-fit px-7",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "underline font-semibold text-[1.5rem]",
                            children: "Back"
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-full flex justify-end box-border py-2 pr-5",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                        onClick: (event)=>{
                            setStepCreate(stepCreate > 5 ? stepCreate : stepCreate + 1);
                        },
                        className: "h-full w-fit px-7 bg-red-500 rounded-xl",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: " font-semibold text-[1.5rem] rounded-xl  text-white   w-full h-full   ",
                            children: "Next"
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FooterCreateHome);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9213:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_stepCreate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9747);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const StepBall = ({ step , currentStep , title  })=>{
    let status = currentStep === step ? "active" : currentStep < step ? "inactive" : "complete";
    const { setStepCreate , stepCreate  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_stepCreate__WEBPACK_IMPORTED_MODULE_1__/* .StepCreateHomeContext */ .G);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-full flex flex-col cursor-pointer",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                onClick: (event)=>{
                    setStepCreate(step);
                },
                animate: {
                    backgroundColor: status === "complete" ? "rgb(239,68,68)" : "rgb(255,255,255)",
                    borderColor: status === "complete" || status === "active" ? "rgb(239,68,68)" : "rgb(51,65,85)"
                },
                transition: {
                    duration: 1
                },
                className: `w-[4rem] h-[4rem] rounded-full m-auto flex border-2 text-[1.5rem]
      ${status === "active" ? " border-red-500 text-red-500 bg-white" : status === "complete" ? "border-red-500 bg-red-500" : "border-slate-500 bg-white text-slate-700"}
      `,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `m-auto font-bold overflow-hidden`,
                    children: status === "complete" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex w-full h-full  ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_4__.FaCheck, {
                            className: "m-auto text-white"
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: step
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-center whitespace-nowrap font-semibold mobile:hidden",
                children: title
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StepBall);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1984:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_stepCreate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9747);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _stepBall__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9213);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_stepBall__WEBPACK_IMPORTED_MODULE_3__]);
_stepBall__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const StepCreateHome = ()=>{
    const { setStepCreate , stepCreate  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_stepCreate__WEBPACK_IMPORTED_MODULE_1__/* .StepCreateHomeContext */ .G);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-fit py-5 grid grid-cols-4 grid-rows-1",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stepBall__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                step: 1,
                currentStep: stepCreate,
                title: "Choose your type house"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stepBall__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                step: 2,
                currentStep: stepCreate,
                title: "House properties"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stepBall__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                step: 3,
                currentStep: stepCreate,
                title: "Address"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_stepBall__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                step: 4,
                currentStep: stepCreate,
                title: "Images"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StepCreateHome);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4821:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const variants = {
    show: {
        display: "block",
        scale: [
            .8,
            1
        ],
        opacity: [
            0,
            1
        ],
        transition: {
            delay: .6
        }
    },
    hidden: {
        scale: [
            1,
            .8
        ],
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        }
    }
};
const TransitionCreateHome = ({ children , isShow  })=>{
    const [shouldAnimate, setShouldAnimate] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        // Wait for the component to be rendered and then enable the animation
        setShouldAnimate(true);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.AnimatePresence, {
        initial: false,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: variants,
            initial: shouldAnimate ? "hidden" : false,
            animate: isShow ? "show" : "hidden",
            transition: {
                duration: .5
            },
            className: "mb-[5rem]",
            children: children
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TransitionCreateHome);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6994:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6648);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3708);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mapOptions__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1312);







const authWithoutAnimate = ({ children  })=>{
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_3__.useSession)();
    const { isFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_1__/* .getHouseContext */ .S);
    const { setUser , user  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__/* .userAccContext */ .G);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const setuser = async ()=>{
            const temp = await session?.userAcc;
            if (temp) {
                setUser({
                    ...user,
                    ...temp
                });
            } else {
                setUser({
                    ...user,
                    UserId: "none user"
                });
            }
        };
        setuser();
    }, [
        isFilter,
        status
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mapOptions__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            children: children
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (authWithoutAnimate);


/***/ }),

/***/ 8099:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_createHome_componentCreateHome_chooseTypeHouse_chooseTypeHouse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(69);
/* harmony import */ var _components_createHome_componentCreateHome_finishPage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1731);
/* harmony import */ var _components_createHome_componentCreateHome_houseProperties_houseProperties__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6564);
/* harmony import */ var _components_createHome_componentCreateHome_imgCreateHouse__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(865);
/* harmony import */ var _components_createHome_componentCreateHome_mapCreateHouse__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(881);
/* harmony import */ var _components_createHome_footerCreateHome__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5659);
/* harmony import */ var _components_createHome_stepCreateHome__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1984);
/* harmony import */ var _components_createHome_transitionCreateHome__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4821);
/* harmony import */ var _components_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5209);
/* harmony import */ var _components_layouts_authWithoutAnimate__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6994);
/* harmony import */ var _components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9578);
/* harmony import */ var _contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1477);
/* harmony import */ var _contexts_stepCreate__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9747);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(883);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_createHome_componentCreateHome_chooseTypeHouse_chooseTypeHouse__WEBPACK_IMPORTED_MODULE_1__, _components_createHome_componentCreateHome_finishPage__WEBPACK_IMPORTED_MODULE_2__, _components_createHome_componentCreateHome_houseProperties_houseProperties__WEBPACK_IMPORTED_MODULE_3__, _components_createHome_componentCreateHome_imgCreateHouse__WEBPACK_IMPORTED_MODULE_4__, _components_createHome_footerCreateHome__WEBPACK_IMPORTED_MODULE_6__, _components_createHome_stepCreateHome__WEBPACK_IMPORTED_MODULE_7__, _components_createHome_transitionCreateHome__WEBPACK_IMPORTED_MODULE_8__, _components_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_9__]);
([_components_createHome_componentCreateHome_chooseTypeHouse_chooseTypeHouse__WEBPACK_IMPORTED_MODULE_1__, _components_createHome_componentCreateHome_finishPage__WEBPACK_IMPORTED_MODULE_2__, _components_createHome_componentCreateHome_houseProperties_houseProperties__WEBPACK_IMPORTED_MODULE_3__, _components_createHome_componentCreateHome_imgCreateHouse__WEBPACK_IMPORTED_MODULE_4__, _components_createHome_footerCreateHome__WEBPACK_IMPORTED_MODULE_6__, _components_createHome_stepCreateHome__WEBPACK_IMPORTED_MODULE_7__, _components_createHome_transitionCreateHome__WEBPACK_IMPORTED_MODULE_8__, _components_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















(0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_14__.initializeSSR)();
const CreateHome = ({ keyMapBing , api_url_path  })=>{
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_14__.initializeSSR)();
    const { setStepCreate , stepCreate  } = (0,react__WEBPACK_IMPORTED_MODULE_16__.useContext)(_contexts_stepCreate__WEBPACK_IMPORTED_MODULE_13__/* .StepCreateHomeContext */ .G);
    const { createHouseForm , setCreateHouseForm , typeHouseId , imgArr  } = (0,react__WEBPACK_IMPORTED_MODULE_16__.useContext)(_contexts_createHouseForm__WEBPACK_IMPORTED_MODULE_12__/* .createHouseFormContext */ .F);
    (0,react__WEBPACK_IMPORTED_MODULE_16__.useEffect)(()=>{}, [
        createHouseForm
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_stepCreateHome__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_transitionCreateHome__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                isShow: stepCreate == 1,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-fit",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_componentCreateHome_chooseTypeHouse_chooseTypeHouse__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_transitionCreateHome__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                isShow: stepCreate == 2,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_componentCreateHome_houseProperties_houseProperties__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_transitionCreateHome__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                isShow: stepCreate == 3,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    styleDivAround: "",
                    styleFieldset: "",
                    styleLegend: "",
                    title: "Address",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_componentCreateHome_mapCreateHouse__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        keyMapBing: keyMapBing,
                        setTempHouse: setCreateHouseForm,
                        tempHouse: createHouseForm
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_transitionCreateHome__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                isShow: stepCreate == 4,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_componentShowHouse_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    styleDivAround: " before:hidden",
                    styleFieldset: "",
                    styleLegend: "",
                    title: "Images",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_componentCreateHome_imgCreateHouse__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        api_url_path: api_url_path
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_transitionCreateHome__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                isShow: stepCreate > 4,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_componentCreateHome_finishPage__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    api_url_path: api_url_path
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_createHome_footerCreateHome__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
        ]
    });
};
CreateHome.Layout = _components_layouts_authWithoutAnimate__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z;
const getServerSideProps = async ({ req , res  })=>{
    const session = await (0,next_auth__WEBPACK_IMPORTED_MODULE_15__.getServerSession)(req, res, _api_auth_nextauth___WEBPACK_IMPORTED_MODULE_17__/* .authOptions */ .L);
    const keyMapBing = process.env.ACCESS_TOKEN_BINGMAP;
    const api_url_path = process.env.API_URL_PATH;
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_14__.initializeSSR)();
    // if user available not callback api from server
    // if (!session?.userAcc) {
    //   res.setHeader('location', '/login');
    //   res.statusCode = 302;
    //   res.end();
    //   return { props: {} };
    // }
    return {
        props: {
            keyMapBing: keyMapBing,
            api_url_path: api_url_path
        }
    };
};
// export const getStaticProps: GetStaticProps = async ({ params }: GetStaticPropsContext) => {
//   initializeSSR();
//   const link = process.env.API_URL_PATH;
//   const keyMapBing = process.env.ACCESS_TOKEN_BINGMAP;
//   return {
//     props: {
//       keyMapBing: keyMapBing,
//       link: link
//     },
//     revalidate: 300
//   };
// };
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateHome);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7991:
/***/ ((module) => {

module.exports = require("bing-maps-loader");

/***/ }),

/***/ 5538:
/***/ ((module) => {

module.exports = require("bingmaps");

/***/ }),

/***/ 4146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1711:
/***/ ((module) => {

module.exports = require("filepond-plugin-image-exif-orientation");

/***/ }),

/***/ 8984:
/***/ ((module) => {

module.exports = require("filepond-plugin-image-preview");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1817:
/***/ ((module) => {

module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4304:
/***/ ((module) => {

module.exports = require("react-date-range");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 5178:
/***/ ((module) => {

module.exports = require("react-filepond");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

module.exports = import("framer-motion");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,664,170,298,636,675,864,445,565,489,543,413,856,209,925,536,665], () => (__webpack_exec__(8099)));
module.exports = __webpack_exports__;

})();