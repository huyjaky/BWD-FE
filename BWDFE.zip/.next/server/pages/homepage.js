(() => {
var exports = {};
exports.id = 883;
exports.ids = [883];
exports.modules = {

/***/ 6245:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Montserrat_097b2d', '__Montserrat_Fallback_097b2d'","fontStyle":"normal"},
	"className": "__className_097b2d",
	"variable": "__variable_097b2d"
};


/***/ }),

/***/ 6878:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3015);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3877);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_4__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




// import './styles.css';

const CarouselMain = ()=>{
    const arrImg = [
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
        "https://images.unsplash.com/photo-1448630360428-65456885c650?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1167&q=80",
        "https://images.unsplash.com/photo-1430285561322-7808604715df?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
        "https://images.unsplash.com/photo-1493809842364-78817add7ffb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80",
        "https://images.unsplash.com/photo-1623298317883-6b70254edf31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.Swiper, {
            loop: true,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false
            },
            pagination: {
                el: ".main-pagination",
                clickable: true
            },
            modules: [
                swiper__WEBPACK_IMPORTED_MODULE_4__.Pagination,
                swiper__WEBPACK_IMPORTED_MODULE_4__.Autoplay
            ],
            className: "w-full h-[32rem] justify-center",
            style: {
                width: "100vw"
            },
            children: arrImg.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                    style: {
                        width: "100vw"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: item,
                            alt: "",
                            className: "w-full h-full object-cover"
                        })
                    })
                });
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CarouselMain);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ imgArr)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__);



const imgArr = [
    {
        title: "House for sale",
        path: (type)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsFillHouseCheckFill, {
                className: type + "text-[2rem]"
            })
    },
    {
        title: "House for rent",
        path: (type)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_1__.BiSolidBuildingHouse, {
                className: type + "text-[2rem]"
            })
    },
    {
        title: "Whislist",
        path: (type)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_2__.BsBookmarkHeartFill, {
                className: type + "text-[2rem]"
            })
    }
];


/***/ }),

/***/ 2738:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3015);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var _api_client_houseApi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(860);
/* harmony import */ var _components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8772);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3565);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9445);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6197);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var swiper_css_effect_coverflow__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4242);
/* harmony import */ var swiper_css_effect_coverflow__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(swiper_css_effect_coverflow__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _showHouse_componentShowHouse_houseCard__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2931);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3708);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_3__, _api_client_houseApi__WEBPACK_IMPORTED_MODULE_4__, _components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_8__, _showHouse_componentShowHouse_houseCard__WEBPACK_IMPORTED_MODULE_16__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_1__, swiper__WEBPACK_IMPORTED_MODULE_3__, _api_client_houseApi__WEBPACK_IMPORTED_MODULE_4__, _components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_8__, _showHouse_componentShowHouse_houseCard__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


// import required modules

















const SlideShowHouse = ({ title , infShow , keyMapBing , setSelectUser , setSelectLocale , setIsOpenMaskMap , setIsOpenMask , isHover , setIsHover  })=>{
    const arrEmpty = [
        1,
        2,
        3,
        4,
        5,
        6,
        7
    ];
    const [houseTemp, setHouseTemp] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)([]);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_9__.useSession)();
    const { filterForm , setFilterForm , emptyFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_6__/* .filterContext */ .u);
    const { address , setAddress , emptyAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_7__/* .selectPlaceContext */ .t);
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_17__/* .userAccContext */ .G);
    const { isFilter , setIsFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_18__/* .getHouseContext */ .S);
    const isEmpty = (arr)=>{
        setHouseTemp(arr?.data);
    };
    const fetchAPI = async ()=>{
        if (status === "loading") return;
        const temp = await session?.userAcc;
        if (infShow === "favoriteHouse") {
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_4__/* .houseApi.authFavoriteList */ .Y.authFavoriteList(temp.UserId, -1);
            return isEmpty(arr);
        } else if (infShow === "houseForRent") {
            const tempFilterForm = {
                ...emptyFilterForm,
                typeHouse: [
                    ...emptyFilterForm.typeHouse,
                    "HouseForRent"
                ]
            };
            const tempSelectPlace = emptyAddress;
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_4__/* .houseApi.noneAuthFilter */ .Y.noneAuthFilter({
                filter: tempFilterForm,
                selectPlace: tempSelectPlace
            }, -1, status === "authenticated" ? temp.UserId : "");
            return isEmpty(arr);
        } else if (infShow === "houseForSale") {
            const tempFilterForm = {
                ...emptyFilterForm,
                typeHouse: [
                    ...emptyFilterForm.typeHouse,
                    "HouseForSale"
                ]
            };
            const tempSelectPlace = emptyAddress;
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_4__/* .houseApi.noneAuthFilter */ .Y.noneAuthFilter({
                filter: tempFilterForm,
                selectPlace: tempSelectPlace
            }, -1, status === "authenticated" ? temp.UserId : "");
            return isEmpty(arr);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        fetchAPI();
    }, [
        status
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{}, [
        houseTemp
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-[6.25rem]   relative z-10 text-center flex   text-[2.5rem] tablet:text-[2rem] mobile:text-[1.5rem] ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-fit h-fit m-auto ",
                            children: title
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_1__.Swiper, {
                            effect: "coverflow",
                            grabCursor: true,
                            centeredSlides: true,
                            initialSlide: 3,
                            allowTouchMove: true,
                            slidesPerView: "auto",
                            coverflowEffect: {
                                rotate: 0,
                                stretch: 0,
                                depth: 100,
                                modifier: 2.5
                            },
                            pagination: {
                                el: ".swiper-pagination",
                                clickable: true
                            },
                            navigation: {
                                nextEl: ".swiper-button-next",
                                prevEl: ".swiper-button-prev",
                                enabled: true
                            },
                            modules: [
                                swiper__WEBPACK_IMPORTED_MODULE_3__.EffectCoverflow,
                                swiper__WEBPACK_IMPORTED_MODULE_3__.Pagination,
                                swiper__WEBPACK_IMPORTED_MODULE_3__.Navigation
                            ],
                            className: "swiper_container laptop:hidden desktop:hidden   desktop:h-[34.3rem] laptop:h-[34.3rem] mobile:h-[28rem] tablet:h-[28rem]   ",
                            style: {
                                width: "calc(100vw-5rem)"
                            },
                            children: [
                                !houseTemp || houseTemp.length === 0 && arrEmpty.map((item, index)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                                        style: {
                                            width: "25rem",
                                            paddingTop: "1rem"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                                    }, index);
                                }),
                                houseTemp && houseTemp.length > 0 && houseTemp.map((item, index)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_1__.SwiperSlide, {
                                        style: {
                                            width: "25rem",
                                            paddingTop: "1rem"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_showHouse_componentShowHouse_houseCard__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                            index: index,
                                            keyMapBing: keyMapBing,
                                            infShow: infShow,
                                            isHover: {
                                                ishover: false,
                                                id: index
                                            },
                                            item: item,
                                            setIsHover: setIsHover,
                                            setIsOpenMask: setIsOpenMask,
                                            setIsOpenMaskMap: setIsOpenMaskMap,
                                            setSelectLocale: setSelectLocale,
                                            setSelectUser: setSelectUser,
                                            isEdit: null,
                                            setIsEdit: null,
                                            isRemoveReq: undefined,
                                            setIsRemoveReq: ()=>{}
                                        }, index)
                                    }, index);
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "slider-controler mobile:hidden tablet:hidden",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "swiper-button-prev slider-arrow",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_2__.GrLinkPrevious, {})
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "swiper-button-next slider-arrow rounded-full",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_2__.GrLinkNext, {})
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "swiper-pagination",
                                            style: {
                                                position: "relative",
                                                bottom: "-.6rem"
                                            }
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.button, {
                whileHover: {
                    backgroundColor: "rgba(239,68,68,1)",
                    color: "white"
                },
                className: "w-[80%] m-auto h-[4.5rem] flex border-2 border-red-500   rounded-2xl transition-all duration-500 mb-[6.25rem]   ",
                onClick: (event)=>{
                    window.scrollTo(0, 0);
                    if (infShow === "houseForRent") {
                        const temp = filterForm.typeHouse.filter((item)=>item != "HouseForSale");
                        temp.push("HouseForRent");
                        setFilterForm({
                            ...filterForm,
                            typeHouse: temp
                        });
                        setIsFilter("houseForRent");
                    } else if (infShow === "houseForSale") {
                        const temp = filterForm.typeHouse.filter((item)=>item != "HouseForRent");
                        temp.push("HouseForSale");
                        setFilterForm({
                            ...filterForm,
                            typeHouse: temp
                        });
                        setIsFilter("houseForSale");
                    } else if (infShow === "favoriteHouse") {
                        setIsFilter(infShow);
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-fit h-fit m-auto flex flex-col",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.div, {
                            className: "m-auto relative w-[2rem] h-[2rem]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.div, {
                                animate: {
                                    y: [
                                        -10,
                                        0,
                                        -10
                                    ]
                                },
                                transition: {
                                    repeat: Infinity
                                },
                                className: "absolute left-0",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_11__.BsChevronDoubleDown, {
                                    className: "text-[2rem]"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-semibold",
                            children: "Show more"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SlideShowHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8156:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_houseDetail_host_hostUser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1600);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_css_effect_coverflow__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4242);
/* harmony import */ var swiper_css_effect_coverflow__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css_effect_coverflow__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _showHouse_mapEach__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8903);
/* harmony import */ var _showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8462);
/* harmony import */ var _slideShowHouse__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2738);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3708);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_houseDetail_host_hostUser__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_2__, _slideShowHouse__WEBPACK_IMPORTED_MODULE_11__]);
([_components_houseDetail_host_hostUser__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_2__, _slideShowHouse__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// import required modules













const TabShowHouse = ({ keyMapBing  })=>{
    const maskUser = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const maskMap = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const [isOpenMask, setIsOpenMask] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [selectUser, setSelectUser] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const [selectLocale, setSelectLocale] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const [isOpenMaskMap, setIsOpenMaskMap] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [isHover, setIsHover] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({
        ishover: false,
        id: -1
    });
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_3__.useSession)();
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_12__/* .userAccContext */ .G);
    const handleOnClickOutSideMaskUser = (event)=>{
        const isClickInSide = maskUser.current?.contains(event.target);
        if (!isClickInSide) {
            setIsOpenMask(false);
            return;
        } else {
            return;
        }
    };
    const handleOnClickOutSideMaskMap = (event)=>{
        const isClickInSide = maskMap.current?.contains(event.target);
        if (!isClickInSide) {
            setIsOpenMaskMap(false);
            return;
        } else {
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        console.log(user);
    }, [
        user.UserId
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    variants: _showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_10__/* .variants */ .o,
                    animate: isOpenMask ? "showMask" : "hiddenMask",
                    onClick: handleOnClickOutSideMaskUser,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0 ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                        className: "w-fit h-fit bg-[#f0efe9] p-7 m-auto mt-[10%] rounded-2xl",
                        ref: maskUser,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_host_hostUser__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                description: "",
                                imgPath: selectUser?.Image,
                                gmail: selectUser?.Gmail,
                                userName: selectUser?.UserName
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    variants: _showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_10__/* .variants */ .o,
                    animate: isOpenMaskMap ? "showMaskMap" : "hiddenMaskMap",
                    onClick: handleOnClickOutSideMaskMap,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0 flex ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        ref: maskMap,
                        className: "w-[50%] h-fit bg-[#f0efe9] p-7 m-auto rounded-2xl",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_showHouse_mapEach__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            longitude: selectLocale?.longitude ? selectLocale.longitude : 1,
                            latitude: selectLocale?.latitude ? selectLocale?.latitude : 1,
                            zoom: selectLocale?.zoom ? selectLocale.zoom : 15,
                            keyMapBing: keyMapBing,
                            formattedAddress: selectLocale?.formattedAddress ? selectLocale.formattedAddress : "",
                            style: "h-[32rem]",
                            idMap: "6"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "h-fit mt-[4.5rem] tablet:mt-[3rem] mobile:mt-[3rem] relative  bg-[#fffdf8]   rounded-xl shadow-2xl   ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                        variants: _showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_10__/* .variants */ .o,
                        exit: "exitFavor",
                        className: "",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_slideShowHouse__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            setIsOpenMask: setIsOpenMask,
                            setIsOpenMaskMap: setIsOpenMaskMap,
                            setSelectLocale: setSelectLocale,
                            setSelectUser: setSelectUser,
                            isHover: isHover,
                            setIsHover: setIsHover,
                            infShow: "houseForSale",
                            title: "House for sale",
                            keyMapBing: keyMapBing
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                        variants: _showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_10__/* .variants */ .o,
                        exit: "exitFavor",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_slideShowHouse__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            setIsOpenMask: setIsOpenMask,
                            setIsOpenMaskMap: setIsOpenMaskMap,
                            setSelectLocale: setSelectLocale,
                            setSelectUser: setSelectUser,
                            isHover: isHover,
                            setIsHover: setIsHover,
                            infShow: "houseForRent",
                            title: "House for rent",
                            keyMapBing: keyMapBing
                        })
                    }),
                    status === "authenticated" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                        variants: _showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_10__/* .variants */ .o,
                        exit: "exitFavor",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_slideShowHouse__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            setIsOpenMask: setIsOpenMask,
                            setIsOpenMaskMap: setIsOpenMaskMap,
                            setSelectLocale: setSelectLocale,
                            setSelectUser: setSelectUser,
                            isHover: isHover,
                            setIsHover: setIsHover,
                            infShow: "favoriteHouse",
                            title: "Whislist",
                            keyMapBing: keyMapBing
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabShowHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2418:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1705);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _imgArr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7790);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3565);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6648);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7607);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const DesktopLaptop = ()=>{
    const [isHoverTypehouse, setIsHoverTypehouse] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [keyHover, setKeyHover] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(-1);
    const [keyHoverControl, setKeyHoverControl] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(-1);
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_6__/* .filterContext */ .u);
    const { isFilter , setIsFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_7__/* .getHouseContext */ .S);
    const [keyClickTypehouse, setKeyClickTypehouse] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(-1);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_8__.useSession)();
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_9__/* .selectPopoverContext */ .K);
    const { setIsClickOutSide  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_1__/* .filterFormAnimateContext */ .b);
    const mainDivRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const secondaryDivRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const classIcon = "w-full h-[4.5rem] p-3";
    const controlBtn = [
        {
            title: "Filter",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_4__.HiOutlineFilter, {
                className: classIcon
            })
        }
    ];
    // useEffect nay lam popup khi the div kia scroll thi the div con lai scroll theo
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const mainDiv = mainDivRef.current;
        const secondaryDiv = secondaryDivRef.current;
        if (!mainDiv || !secondaryDiv) return;
        const handleScroll = ()=>{
            const scrollPosition = mainDiv.scrollTop;
            secondaryDiv.scrollTop = scrollPosition;
        };
        mainDiv.addEventListener("scroll", handleScroll);
        return ()=>{
            mainDiv.removeEventListener("scroll", handleScroll);
        };
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "fixed top-[calc(50vh-230px+2.4rem)] left-0 z-[15]",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                className: "w-[3rem] h-fit   rounded-r-2xl border-2 border-slate-500 border-l-0 bg-white z-10 overflow-hidden   ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    className: "w-full h-fit",
                    ref: mainDivRef,
                    children: [
                        controlBtn.map((item, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                onHoverStart: ()=>{
                                    setIsHoverTypehouse(true);
                                    setKeyHoverControl(index);
                                },
                                onHoverEnd: ()=>{
                                    setIsHoverTypehouse(false);
                                    setKeyHoverControl(-1);
                                },
                                onClick: (event)=>{
                                    if (item.title === "Filter") {
                                        window.scrollTo(0, 0);
                                        setIsClickOutSide(true);
                                        document.body.style.overflow = "hidden";
                                    }
                                },
                                className: "border-b-2 border-slate-700",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                    className: "w-full h-fit",
                                    children: item.icon
                                })
                            }, index);
                        }),
                        _imgArr__WEBPACK_IMPORTED_MODULE_5__/* .imgArr.map */ .T.map((item, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                onHoverStart: ()=>{
                                    setIsHoverTypehouse(true);
                                    setKeyHover(index);
                                },
                                onHoverEnd: ()=>{
                                    setIsHoverTypehouse(false);
                                    setKeyHover(-1);
                                },
                                onClick: (event)=>{
                                    setKeyClickTypehouse(index);
                                    window.scrollTo(0, 0);
                                    if (item.title === "House for rent") {
                                        const temp = filterForm.typeHouse.filter((item)=>item != "HouseForSale");
                                        temp.push("HouseForRent");
                                        setFilterForm({
                                            ...filterForm,
                                            typeHouse: temp
                                        });
                                        setIsFilter("houseForRent");
                                    } else if (item.title === "House for sale") {
                                        const temp = filterForm.typeHouse.filter((item)=>item != "HouseForRent");
                                        temp.push("HouseForSale");
                                        setFilterForm({
                                            ...filterForm,
                                            typeHouse: temp
                                        });
                                        setIsFilter("houseForSale");
                                    } else if (item.title === "Whislist") {
                                        if (status === "unauthenticated") {
                                            setIsLoginClick(true);
                                            return;
                                        }
                                        setIsFilter("favoriteHouse");
                                    }
                                },
                                className: "p-1 h-[4.5rem]",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                    className: " relative flex",
                                    children: item.path(`m-auto w-full  hover:text-red-500 transition-all
                  ${keyClickTypehouse === index ? "bg-red-400 rounded-full text-white" : ""}
                  `)
                                })
                            }, index);
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                className: "absolute left-[5.625rem] top-0 w-fit h-full flex flex-col   z-30 overflow-scroll overflow-x-hidden  overflow-y-hidden pointer-events-non   ",
                ref: secondaryDivRef,
                children: [
                    controlBtn.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-1 ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                className: `w-fit flex-1 h-full
              ${isHoverTypehouse && keyHoverControl === index ? "visible" : "invisible"}
              `,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex rounded-xl bg-white p-3 border-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "m-auto",
                                        children: item.title
                                    })
                                })
                            })
                        }, index);
                    }),
                    _imgArr__WEBPACK_IMPORTED_MODULE_5__/* .imgArr.map */ .T.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-1",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                className: `w-fit flex-1 h-full
              ${isHoverTypehouse && keyHover === index ? "visible" : "invisible"}
              `,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex rounded-xl bg-white p-3 border-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "m-auto  whitespace-nowrap",
                                        children: item.title
                                    })
                                })
                            })
                        }, index);
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DesktopLaptop);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9492:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _imgArr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7790);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3565);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6648);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7607);







const TabletMobile = ()=>{
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_3__/* .filterContext */ .u);
    const { isFilter , setIsFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_4__/* .getHouseContext */ .S);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_5__.useSession)();
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_6__/* .selectPopoverContext */ .K);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-[6.25rem] mobile:h-fit  flex",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "m-auto grid tablet:grid-cols-3 mobile:grid-cols-3 mobile:mb-5   gap-7 gap-x-12   ",
            children: _imgArr__WEBPACK_IMPORTED_MODULE_2__/* .imgArr.map */ .T.map((item, index)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    onClick: (event)=>{
                        if (item.title === "House for rent") {
                            const temp = filterForm.typeHouse.filter((item)=>item != "HouseForSale");
                            temp.push("HouseForRent");
                            setFilterForm({
                                ...filterForm,
                                typeHouse: temp
                            });
                            setIsFilter("houseForRent");
                        } else if (item.title === "House for sale") {
                            const temp = filterForm.typeHouse.filter((item)=>item != "HouseForRent");
                            temp.push("HouseForSale");
                            setFilterForm({
                                ...filterForm,
                                typeHouse: temp
                            });
                            setIsFilter("houseForSale");
                        } else if (item.title === "Whislist") {
                            if (status === "authenticated") {
                                setIsFilter("favoriteHouse");
                            } else if (status === "unauthenticated") {
                                setIsLoginClick(true);
                            }
                        }
                    },
                    className: "w-full h-full flex flex-col ",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "m-auto",
                            children: item.path(" text-[55px] ")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-fit h-fit overflow-hidden m-auto whitespace-nowrap",
                            children: item.title
                        })
                    ]
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TabletMobile);


/***/ }),

/***/ 9530:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _desktopLaptop__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2418);
/* harmony import */ var _tabletMobile__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9492);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_desktopLaptop__WEBPACK_IMPORTED_MODULE_1__]);
_desktopLaptop__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const TypeHouse = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mobile:hidden tablet:hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_desktopLaptop__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "desktop:hidden laptop:hidden mt-6",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabletMobile__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TypeHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9877:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_pages_homepage_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6245);
/* harmony import */ var next_font_google_target_css_path_src_pages_homepage_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_pages_homepage_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3446);
/* harmony import */ var _components_footers_footerRooms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2883);
/* harmony import */ var _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(231);
/* harmony import */ var _components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6813);
/* harmony import */ var _components_main_typeHouse_typeHouse__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9530);
/* harmony import */ var _components_rootMaskHeader_headerMain__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8248);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6648);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3708);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6197);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_main_tabShowHouse_tabShowHouse__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8156);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_main_carousel_carouselMain__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6878);
/* harmony import */ var _components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1964);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_1__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_3__, _components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_4__, _components_main_typeHouse_typeHouse__WEBPACK_IMPORTED_MODULE_5__, _components_rootMaskHeader_headerMain__WEBPACK_IMPORTED_MODULE_6__, framer_motion__WEBPACK_IMPORTED_MODULE_10__, _components_main_tabShowHouse_tabShowHouse__WEBPACK_IMPORTED_MODULE_13__, _components_main_carousel_carouselMain__WEBPACK_IMPORTED_MODULE_15__, _components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_16__]);
([_components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_1__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_3__, _components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_4__, _components_main_typeHouse_typeHouse__WEBPACK_IMPORTED_MODULE_5__, _components_rootMaskHeader_headerMain__WEBPACK_IMPORTED_MODULE_6__, framer_motion__WEBPACK_IMPORTED_MODULE_10__, _components_main_tabShowHouse_tabShowHouse__WEBPACK_IMPORTED_MODULE_13__, _components_main_carousel_carouselMain__WEBPACK_IMPORTED_MODULE_15__, _components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














// import { authOptions } from './api/auth/[...nextauth]';





const variants = {
    show: {
        opacity: [
            0,
            1
        ],
        transition: {
            duration: 1
        }
    },
    showTypeHouse: {
        opacity: [
            0,
            1
        ],
        display: "flex",
        transition: {
            duration: 0.5,
            delay: 0.2
        }
    },
    hiddenTypeHouse: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        },
        transition: {
            duration: 0.5
        }
    }
};
(0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_9__.initializeSSR)();
const Home = ({ user_ , props , keyMapBing  })=>{
    const { user , setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_8__/* .userAccContext */ .G);
    const { isFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_7__/* .getHouseContext */ .S);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_14__.useSession)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{
        if (session?.userAcc) {
            setUser(session?.userAcc);
        }
    }, [
        status
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{
        window.scrollTo(0, 0);
    }, [
        pathname
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{}, [
        isFilter
    ]);
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_9__.initializeSSR)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.main, {
            initial: {
                opacity: 0
            },
            animate: {
                opacity: 1
            },
            transition: {
                delay: 1,
                duration: 0.7
            },
            className: `${(next_font_google_target_css_path_src_pages_homepage_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_18___default().className)} relative overflow-hidden`,
            id: "root",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.AnimatePresence, {
                    initial: false,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_rootMaskHeader_headerMain__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        keyMapBing: keyMapBing
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_typeHouse_typeHouse__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("figure", {
                    className: "w-full h-fit",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full h-[calc(100vh-40vh)] overflow-hidden relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "absolute top-0 left-0 w-full h-full  z-10   p-7 rounded-xl   ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full h-full flex",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "m-auto text-[#ef5c76]  bg-[rgba(253,245,244,.8)] p-3 rounded-lg",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                                            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_17__/* .staggerContainer */ .Jm)(null, null),
                                            initial: "hidden",
                                            whileInView: "show",
                                            viewport: {
                                                once: false,
                                                amount: 0.25
                                            },
                                            className: ` mx-auto flex-col `,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_animateTitle__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                title: "Welcome to Olympus",
                                                textStyles: " w-full h-fit "
                                            })
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_carousel_carouselMain__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-fit px-[5rem] box-border   tablet:px-0 mobile:px-0   ",
                    children: isFilter != "main" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                        variants: variants,
                        animate: "show",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_showHouse__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            infShow: isFilter === "houseForRent" || isFilter === "houseForSale" ? "noneAuthFilter" : isFilter,
                            keyMapBing: keyMapBing,
                            api_url_path: undefined
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                        variants: variants,
                        animate: "show",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_tabShowHouse_tabShowHouse__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            keyMapBing: keyMapBing
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "relative z-10",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footers_footerRooms__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                    ]
                })
            ]
        })
    });
};
Home.Layout = _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);
const getServerSideProps = async ({ req , res  })=>{
    const keyMapBing = process.env.ACCESS_TOKEN_BINGMAP;
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_9__.initializeSSR)();
    return {
        props: {
            keyMapBing: keyMapBing
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4242:
/***/ (() => {



/***/ }),

/***/ 9176:
/***/ (() => {



/***/ }),

/***/ 2996:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ }),

/***/ 7991:
/***/ ((module) => {

"use strict";
module.exports = require("bing-maps-loader");

/***/ }),

/***/ 5538:
/***/ ((module) => {

"use strict";
module.exports = require("bingmaps");

/***/ }),

/***/ 4146:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 1711:
/***/ ((module) => {

"use strict";
module.exports = require("filepond-plugin-image-exif-orientation");

/***/ }),

/***/ 8984:
/***/ ((module) => {

"use strict";
module.exports = require("filepond-plugin-image-preview");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 808:
/***/ ((module) => {

"use strict";
module.exports = require("nprogress");

/***/ }),

/***/ 1817:
/***/ ((module) => {

"use strict";
module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 4304:
/***/ ((module) => {

"use strict";
module.exports = require("react-date-range");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 5178:
/***/ ((module) => {

"use strict";
module.exports = require("react-filepond");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 8547:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gr");

/***/ }),

/***/ 1111:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/hi");

/***/ }),

/***/ 924:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/im");

/***/ }),

/***/ 4751:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io");

/***/ }),

/***/ 9989:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io5");

/***/ }),

/***/ 4041:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/md");

/***/ }),

/***/ 8098:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ri");

/***/ }),

/***/ 4152:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/tb");

/***/ }),

/***/ 4336:
/***/ ((module) => {

"use strict";
module.exports = require("react-infinite-scroll-component");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

"use strict";
module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ }),

/***/ 5563:
/***/ ((module) => {

"use strict";
module.exports = import("popmotion");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 4275:
/***/ ((module) => {

"use strict";
module.exports = import("react-loading-skeleton");;

/***/ }),

/***/ 3877:
/***/ ((module) => {

"use strict";
module.exports = import("swiper");;

/***/ }),

/***/ 3015:
/***/ ((module) => {

"use strict";
module.exports = import("swiper/react");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,664,170,298,636,675,864,445,565,489,731,543,413,231,856,209,751,905,925,765,186,667,813,248], () => (__webpack_exec__(9877)));
module.exports = __webpack_exports__;

})();