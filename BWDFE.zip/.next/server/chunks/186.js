"use strict";
exports.id = 186;
exports.ids = [186];
exports.modules = {

/***/ 432:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "b": () => (/* binding */ AmountTabHostingContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const AmountTabHostingDataDefault = {
    currentHosting: 0,
    setCurrentHosting: ()=>{}
};
const AmountTabHostingContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(AmountTabHostingDataDefault);
const AmountTabHostingProviders = ({ children  })=>{
    const [currentHosting, setCurrentHosting_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(AmountTabHostingDataDefault.currentHosting);
    const setCurrentHosting = (payload)=>setCurrentHosting_(payload);
    const AmountCurrentHostingDynamicData = {
        currentHosting,
        setCurrentHosting
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AmountTabHostingContext.Provider, {
        value: AmountCurrentHostingDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AmountTabHostingProviders);


/***/ }),

/***/ 1790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ houseTempContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const houseTempDefaultData = {
    houseTemp: [],
    setHouseTemp: ()=>{}
};
const houseTempContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(houseTempDefaultData);
const HouseTempProvider = ({ children  })=>{
    const [houseTemp, setHouseTemp_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(houseTempDefaultData.houseTemp);
    const setHouseTemp = (payload)=>setHouseTemp_(payload);
    const imgFileDynamicData = {
        houseTemp,
        setHouseTemp
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(houseTempContext.Provider, {
        value: imgFileDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HouseTempProvider);


/***/ }),

/***/ 2586:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "q": () => (/* binding */ selectHouseContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const selectHouseDefaultData = {
    selectHouse: {
        address: {
            countryRegion: "",
            locality: "",
            adminDistrict: "",
            countryRegionIso2: "",
            postalCode: "",
            addressLine: "",
            streetName: "",
            formattedAddress: "",
            latitude: 0,
            longitude: 0,
            title: ""
        },
        AddressId: "",
        Area: "",
        arrImg: [],
        Capacity: 0,
        DateUp: new Date(),
        Description: "",
        HouseId: "",
        IsFavorite: false,
        JudicalId: "",
        NumsOfBath: 0,
        NumsOfBed: 0,
        Orientation: "",
        placeOffer: [],
        PostBy: "",
        Price: 0,
        Title: "",
        Type: "",
        useracc: {
            UserId: "",
            UserName: "",
            Password: "",
            Birth: new Date(),
            Gmail: "",
            Sex: "",
            Decentralization: "",
            PersonCode: "",
            CustomerType: "",
            Image: "",
            error: "",
            Phone: ""
        }
    },
    resetSelectHouse: ()=>{},
    setSelectHouse: ()=>{}
};
const selectHouseContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(selectHouseDefaultData);
const SelectHouseProvider = ({ children  })=>{
    const [selectHouse, setSelectHouse_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const resetSelectHouse = ()=>setSelectHouse_(selectHouseDefaultData.selectHouse);
    const setSelectHouse = (payload)=>setSelectHouse_(payload);
    const selectHouseDynamicData = {
        selectHouse,
        resetSelectHouse,
        setSelectHouse
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(selectHouseContext.Provider, {
        value: selectHouseDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectHouseProvider);


/***/ })

};
;