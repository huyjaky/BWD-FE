exports.id = 925;
exports.ids = [925];
exports.modules = {

/***/ 8194:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const axiosClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "/api",
    headers: {
        "Content-Type": "application/json"
    }
});
// Add a response interceptor
axiosClient.interceptors.response.use(function(response) {
    // Any status code that lie within the range of 2xx cause this function to trigger
    // Do something with response data
    return response;
}, function(error) {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    return {
        error: error
    };
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 860:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ houseApi)
/* harmony export */ });
/* harmony import */ var _axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const houseApi = {
    noneAuthHouseApi (page, UserId) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/get/house/page/${page ? page : ""}`, {
            params: {
                userid: UserId
            }
        });
    },
    noneAuthFilter (payload, page, UserId) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/get/house/filter/${page}`, {
            datafil: payload,
            UserId: UserId
        });
    },
    authFavoriteHouse (HouseId, UserId) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/create/favorite`, {
            HouseId: HouseId,
            UserId: UserId
        });
    },
    authUnFavoriteHouse (HouseId, UserId) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/delete/favorite`, {
            HouseId: HouseId,
            UserId: UserId
        });
    },
    authListHouse (UserId) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/get/house/userid/${UserId}`);
    },
    authFavoriteList (UserId, offset) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/get/house/userid/favorite/${UserId}`, {
            offset: offset
        });
    },
    editHouse (dataEdit) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/modifier/all/house`, dataEdit);
    },
    DeleteHouse (HouseId, AddressId) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/delete/house`, {
            HouseId: HouseId,
            AddressId: AddressId
        });
    },
    createHouse (house, typehouse) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/create/house/house", {
            house,
            typehouse
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4993:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ arrEditAmeneties)
/* harmony export */ });
const arrEditAmeneties = [
    // 'Kitchen', 'Air Conditioning', 'TV', 'Fridge',
    // 'Pool', 'Washer'
    {
        PlaceOfferId: "1",
        PlaceOffer: "Kitchen"
    },
    {
        PlaceOfferId: "2",
        PlaceOffer: "Air Conditioning"
    },
    {
        PlaceOfferId: "3",
        PlaceOffer: "TV"
    },
    {
        PlaceOfferId: "4",
        PlaceOffer: "Fridge"
    },
    {
        PlaceOfferId: "5",
        PlaceOffer: "Pool"
    },
    {
        PlaceOfferId: "6",
        PlaceOffer: "Washer"
    },
    {
        PlaceOfferId: "7",
        PlaceOffer: "Luxury interior"
    },
    {
        PlaceOfferId: "8",
        PlaceOffer: "Full interior"
    },
    {
        PlaceOfferId: "9",
        PlaceOffer: "Empty interior"
    },
    {
        PlaceOfferId: "10",
        PlaceOffer: "Basic interior"
    }
];


/***/ }),

/***/ 8235:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _arrEditAmenities__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4993);
/* harmony import */ var _components_main_filter_formFilter_filterFormComponent_amenities_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_main_filter_formFilter_filterFormComponent_amenities_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__]);
_components_main_filter_formFilter_filterFormComponent_amenities_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const EditAmenities = ({ tempHouse , setTempHouse  })=>{
    // const arrAmenities_: string[] = arrAmenities;
    const [arrAmenities_, setArrAmenities] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(_arrEditAmenities__WEBPACK_IMPORTED_MODULE_2__/* .arrEditAmeneties */ .a);
    const handleOnClick = (event, item)=>{
        if (!tempHouse) return;
        const arrTemp = Array.isArray(tempHouse?.placeOffer) ? tempHouse?.placeOffer : [];
        if (tempHouse.placeOffer.some((item_)=>item_.PlaceOffer === item.PlaceOffer)) {
            console.log("exist");
            const updateArrTemp = arrTemp.filter((item_)=>{
                return item_.PlaceOffer !== item.PlaceOffer;
            });
            setTempHouse({
                ...tempHouse,
                placeOffer: updateArrTemp
            });
            return;
        }
        arrTemp.push(item);
        setTempHouse({
            ...tempHouse,
            placeOffer: arrTemp
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full mb-14",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-fit grid grid-cols-2 gap-y-5 mt-3",
            children: arrAmenities_.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full cursor-pointer",
                    onClick: (event)=>handleOnClick(event, item),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex h-full box-border overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "my-auto",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_filter_formFilter_filterFormComponent_amenities_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        // filterForm.amenities.includes(item) ? true : false
                                        isCheckedProps: tempHouse?.placeOffer ? // isCheck(item, tempHouse?.placeOffer)
                                        tempHouse.placeOffer.some((item_)=>item_.PlaceOffer === item.PlaceOffer) : false
                                    }),
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "h-full flex items-center   ml-5 text-[19px]   ",
                                children: item.PlaceOffer
                            })
                        ]
                    })
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditAmenities);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9578:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const InputFormEdit = ({ children , styleFieldset , styleLegend , styleDivAround , title  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("fieldset", {
        className: `border-2 h-fit rounded-xl pb-2 px-4 ${styleFieldset}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("legend", {
                className: `font-semibold text-[22px] ml-5 ${styleLegend}`,
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-full h-fit relative before:bottom-0 before:h-[.2rem] before:absolute
                    before:bg-slate-500 before:w-full before:transition-all before:duration-200
                    ${styleDivAround}
                    `,
                children: children
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InputFormEdit);


/***/ }),

/***/ 391:
/***/ (() => {



/***/ }),

/***/ 1137:
/***/ (() => {



/***/ })

};
;