"use strict";
exports.id = 445;
exports.ids = [445];
exports.modules = {

/***/ 9445:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "t": () => (/* binding */ selectPlaceContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const selectPlaceDefaultData = {
    address: {
        address: {
            countryRegion: "",
            locality: "",
            adminDistrict: "",
            countryRegionIso2: "",
            postalCode: "",
            addressLine: "",
            streetName: "",
            formattedAddress: "",
            latitude: 0,
            longitude: 0,
            title: ""
        },
        checkInDay: new Date(),
        checkOutDay: new Date(),
        guest: {
            adults: 0,
            childrens: 0,
            infants: 0
        }
    },
    emptyAddress: {
        address: {
            title: "",
            countryRegion: "",
            locality: "",
            adminDistrict: "",
            countryRegionIso2: "",
            postalCode: "",
            addressLine: "",
            streetName: "",
            formattedAddress: "",
            latitude: 0,
            longitude: 0
        },
        checkInDay: new Date(),
        checkOutDay: new Date(),
        guest: {
            adults: 0,
            childrens: 0,
            infants: 0
        }
    },
    setAddress: ()=>{}
};
const selectPlaceContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(selectPlaceDefaultData);
const SelectPlaceProvider = ({ children  })=>{
    const [address, setAddress_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(selectPlaceDefaultData.address);
    const [emptyAddress, setEmptyAddress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(selectPlaceDefaultData.emptyAddress);
    const setAddress = (payload)=>setAddress_(payload);
    const selectPlaceDynamicData = {
        address,
        setAddress,
        emptyAddress
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(selectPlaceContext.Provider, {
        value: selectPlaceDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SelectPlaceProvider);


/***/ })

};
;