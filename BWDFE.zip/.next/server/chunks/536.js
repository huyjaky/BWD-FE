"use strict";
exports.id = 536;
exports.ids = [536];
exports.modules = {

/***/ 883:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ authOptions)
/* harmony export */ });
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7449);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__);


// export default async function auth(req: NextApiRequest, res: NextApiResponse) {
//   // Do whatever you want here, before the request is passed down to `NextAuth`
//   return await NextAuth(req, res, {
//     session: {
//       strategy: 'jwt',
//       maxAge: 24 * 60 * 60
//       // updateAge: 24 * 60 * 60,
//     },
//     jwt: {
//       maxAge: 24 * 60 * 60
//     },
//     callbacks: {
//       async jwt({ token, user }: { token: JWT; user: User | AdapterUser }): Promise<JWT> {
//         if (user) {
//           token.loginVl = user;
//         }
//         return token;
//       },
//       async session({ session, token, user }) {
//         session.token = { ...token?.loginVl?.token };
//         session.userAcc = { ...token?.loginVl?.userAcc };
//         return session;
//       }
//     },
//     providers: [
//       CredentialsProvider({
//         name: 'Credentials',
//         credentials: {
//           username: { label: 'Username', type: 'text' },
//           password: { label: 'Password', type: 'password' }
//         },
//         async authorize(credentials, req) {
//           const accessToken = await fetch(process.env.API_URL_AUTH + '/api/login', {
//             method: 'POST',
//             body: JSON.stringify(credentials),
//             headers: { 'Content-Type': 'application/json' }
//           });
//           const token = await accessToken.json();
//           if (accessToken.ok && token) {
//             return token;
//           }
//           return null;
//         }
//       })
//     ]
//   });
// }
const refreshToken = async (token)=>{
    const accessToken = await fetch(process.env.API_URL_AUTH + "/api/refresh", {
        method: "POST",
        body: JSON.stringify({
            refreshToken: token.token.refreshToken
        }),
        headers: {
            "Content-Type": "application/json"
        }
    });
    const token_ = await accessToken.json();
    if (token_.userAcc) {
        token.token.accessToken = token_.token.accessToken;
        token.exp = token.exp + 3600;
        return token;
    }
    return token;
};
const authOptions = {
    // your configs
    secret: process.env.SECRET_COOKIE_PASSWORD,
    session: {
        strategy: "jwt",
        maxAge: 24 * 60 * 60,
        updateAge: 24 * 60 * 60
    },
    jwt: {
        maxAge: 24 * 60 * 60
    },
    callbacks: {
        async jwt ({ token , user , account  }) {
            const temp = user;
            if (temp) {
                token.userAcc = await temp.userAcc;
                token.token = await temp.token;
                console.log("FIRST TIME LOGIN EXTENDED TOKEN", token.token);
                return token;
            }
            console.log(token);
            if ((Date.now() + 300) / 1000 < token.exp) {
                console.log("access token still valid, returning extended token");
                return token;
            }
            console.log("access token expired, refreshing...");
            return refreshToken(token);
        },
        async session ({ session , token , user  }) {
            session.userAcc = await token.userAcc;
            session.token = await token.token;
            return session;
        }
    },
    providers: [
        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1___default()({
            name: "Credentials",
            credentials: {
                username: {
                    label: "Username",
                    type: "text"
                },
                password: {
                    label: "Password",
                    type: "password"
                }
            },
            async authorize (credentials, req) {
                const accessToken = await fetch(process.env.API_URL_AUTH + "/api/login", {
                    method: "POST",
                    body: JSON.stringify(credentials),
                    headers: {
                        "Content-Type": "application/json"
                    }
                });
                const token = await accessToken.json();
                if (token.userAcc) {
                    return token;
                }
                return null;
            }
        })
    ]
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_0___default()(authOptions));


/***/ })

};
;