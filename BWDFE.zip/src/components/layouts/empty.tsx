import { LayoutProps } from '@/models/layoutprops';

const EmptyLayout = ({ children }: LayoutProps) => {
  return <>{children}</>;
};

export default EmptyLayout;
