export  const compassUtils: string[] = ['All' , 'West', 'South', 'East', 'North', 'NorthEast',
'SouthEast', 'SouthWest', 'NorthWest'];