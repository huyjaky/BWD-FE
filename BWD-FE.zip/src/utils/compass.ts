export  const compassUtils: string[] = ['West', 'South', 'East', 'North', 'NorthEast',
'SouthEast', 'SouthWest', 'NorthEast']