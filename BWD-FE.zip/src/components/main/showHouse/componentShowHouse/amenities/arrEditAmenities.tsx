export const arrEditAmeneties: { PlaceOfferId: string; PlaceOffer: string }[] = [
  // 'Kitchen', 'Air Conditioning', 'TV', 'Fridge',
  // 'Pool', 'Washer'
  {
    PlaceOfferId: '1',
    PlaceOffer: 'Kitchen'
  },
  {
    PlaceOfferId: '2',
    PlaceOffer: 'Air Conditioning'
  },
  {
    PlaceOfferId: '3',
    PlaceOffer: 'TV'
  },
  {
    PlaceOfferId: '4',
    PlaceOffer: 'Fridge'
  },
  {
    PlaceOfferId: '5',
    PlaceOffer: 'Pool'
  },
  {
    PlaceOfferId: '6',
    PlaceOffer: 'Washer'
  },
  {
    PlaceOfferId: '7',
    PlaceOffer: 'Luxury interior'
  },
  {
    PlaceOfferId: '8',
    PlaceOffer: 'Full interior'
  },
  {
    PlaceOfferId: '9',
    PlaceOffer: 'Empty interior'
  },
  {
    PlaceOfferId: '10',
    PlaceOffer: 'Basic interior'
  }
]