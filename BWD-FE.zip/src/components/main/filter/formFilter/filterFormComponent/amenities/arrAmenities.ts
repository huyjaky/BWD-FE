import { amenities } from '@/models/filter';

export const arrAmenities: string[] = [
  'Kitchen', 'Air Conditioning', 'TV', 'Fridge',
  'Pool', 'Washer', 'Luxury interior',
  'Full interior', 'Empty interior', 'Basic interior'
]
