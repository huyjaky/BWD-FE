import { getHouseContext } from '@/contexts/getHouse';
import { userAccContext } from '@/contexts/userAcc';
import { LayoutProps } from '@/models/layoutprops';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/router';
import { useContext, useEffect } from 'react';
import Animate from './animate';
import MapOptions from './mapOptions';

const AuthWithAnimate = ({ children }: LayoutProps) => {
  const { data: session, status } = useSession();
  const { isFilter } = useContext(getHouseContext);
  const { setUser, user } = useContext(userAccContext);
  useEffect(() => {
    const setuser = async () => {
      const temp = await session?.userAcc;
      console.log(temp);
      if (temp) {
        setUser({ ...user, ...temp });
      } else {
        setUser({ ...user, UserId: 'none user' });
      }
    };
    setuser();
  }, [isFilter, status]);

  return (
    <>
      <MapOptions>
        <Animate>{children}</Animate>
      </MapOptions>
    </>
  );
};

export default AuthWithAnimate;
