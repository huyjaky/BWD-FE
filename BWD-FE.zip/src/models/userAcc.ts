export interface userAcc {
  UserId: string;
  UserName: string;
  Password: string;
  Image: string;
  Birth: Date;
  Gmail: string;
  Sex: string;
  Decentralization: string;
  PersonCode: string;
  CustomerType: string;
  error: any;
  Phone: string;
}
