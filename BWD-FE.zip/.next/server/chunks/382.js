"use strict";
exports.id = 382;
exports.ids = [382];
exports.modules = {

/***/ 5382:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ DashboardContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const DashboardDefaultData = {
    selectOption: "Schedule",
    setSelectOption: ()=>{},
    eventArr: [],
    setEventArr: ()=>{},
    selectHousePopup: undefined,
    setSelectHousePopup: ()=>{}
};
const DashboardContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(DashboardDefaultData);
const DashboardProvider = ({ children  })=>{
    const [selectOption, setSelectOption_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(DashboardDefaultData.selectOption);
    const [eventArr, setEventArr_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(DashboardDefaultData.eventArr);
    const [selectHousePopup, setSelectHousePopup_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(DashboardDefaultData.selectHousePopup);
    const setSelectOption = (payload)=>setSelectOption_(payload);
    const setEventArr = (payload)=>setEventArr_(payload);
    const setSelectHousePopup = (payload)=>setSelectHousePopup_(payload);
    const DasboardDynamicData = {
        selectOption,
        setSelectOption,
        eventArr,
        setEventArr,
        selectHousePopup,
        setSelectHousePopup
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DashboardContext.Provider, {
        value: DasboardDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DashboardProvider);


/***/ })

};
;