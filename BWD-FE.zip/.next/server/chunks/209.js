"use strict";
exports.id = 209;
exports.ids = [209];
exports.modules = {

/***/ 764:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _listButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7039);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const variants = {
    show: {
        maxHeight: [
            "0px",
            "32rem"
        ],
        // border: ['none', '3px solid grey'],
        display: "block"
    },
    hidden: {
        maxHeight: [
            "32rem",
            "0px"
        ],
        // border: ['3px solid grey', 'none'],
        transitionEnd: {
            display: "none"
        }
    }
};
const ButtonAccount = ()=>{
    const { user , resetDataUser  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__/* .userAccContext */ .G);
    const [isClick, setIsClick] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const controlBar = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const { status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_3__.useSession)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        // animation close control panel
        const handleControlPanel = (event)=>{
            const isClick = controlBar.current?.contains(event.target);
            if (!isClick) {
                setIsClick(false);
            }
        };
        document.addEventListener("mousedown", handleControlPanel);
        document.addEventListener("scroll", handleControlPanel);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        console.log(user);
    }, [
        user,
        status
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-fit p-1 rounded-full bg-white flex border-gray-400 hover:shadow-lg   transition-all duration-500 border-2 relative",
        ref: controlBar,
        onClick: ()=>{
            setIsClick(!isClick);
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_5__.BsList, {
                className: "w-[2rem] h-[2rem]"
            }),
            user?.Image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: "/api/img/path/" + user.Image,
                className: "w-[2rem] h-[2rem] rounded-full"
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiUserCircle, {
                className: "w-[2.4rem] h-[2rem] "
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    variants: variants,
                    animate: isClick ? "show" : "hidden",
                    transition: {
                        duration: 0.5
                    },
                    className: "absolute translate-y-16 w-[16rem] h-fit shadow-2xl right-0 rounded-2xl bg-white   overflow-hidden   ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_listButton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ButtonAccount);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5209:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_main_filter_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7533);
/* harmony import */ var _components_main_mobile_controlPlaneMobile__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5348);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1705);
/* harmony import */ var _contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8047);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2750);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _buttonAccount_ButtonAccount__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(764);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6648);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3565);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3708);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7607);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_main_filter_filter__WEBPACK_IMPORTED_MODULE_1__, _components_main_mobile_controlPlaneMobile__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_5__, _buttonAccount_ButtonAccount__WEBPACK_IMPORTED_MODULE_10__]);
([_components_main_filter_filter__WEBPACK_IMPORTED_MODULE_1__, _components_main_mobile_controlPlaneMobile__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_5__, _buttonAccount_ButtonAccount__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













// import Image from 'next/image';



const HeaderForm = ({ children  })=>{
    const { isShow , setIsShow  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_4__/* .mobileContolPanelContext */ .N);
    const { setIsShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_3__/* .filterFormAnimateContext */ .b);
    const { user , resetDataUser  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_13__/* .userAccContext */ .G);
    const { isFilter , setIsFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_11__/* .getHouseContext */ .S);
    const { resetFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_12__/* .filterContext */ .u);
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_15__/* .selectPopoverContext */ .K);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_14__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-[5rem]"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[5rem]  bg-white z-30 fixed top-0",
                id: "header-root",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                        className: "w-full h-[5rem] border-b-2 flex justify-center px-[5rem]   tablet:hidden mobile:hidden   box-border absolute",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full h-full flex relative",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    href: "/homepage",
                                    onClick: ()=>{
                                        setIsShowHeader(false);
                                        setIsFilter("main");
                                        resetFilterForm();
                                    },
                                    className: "desktop:flex-1 laptop:mr-7  flex items-center text-red-500   z-30   ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/icon.png",
                                            alt: "",
                                            width: 50,
                                            height: 50
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-[2rem] w-0 overflow-hidden desktop:w-fit font-semibold",
                                            children: "Olympus"
                                        })
                                    ]
                                }),
                                children,
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex-1 flex items-center justify-end z-30",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            onClick: ()=>{
                                                if (user.UserId !== "none user") {
                                                    router.push("/hosting", undefined, {
                                                        shallow: true
                                                    });
                                                    return;
                                                }
                                                setIsLoginClick(true);
                                            },
                                            className: "rounded-full bg-white h-fit box-content px-4 py-2   hover:bg-slate-300 tablet:hidden mobile:hidden cursor-pointer",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-semibold",
                                                children: "Olympus your home"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            href: "",
                                            className: "rounded-full bg-white box-content p-1 mr-3 hover:bg-slate-300",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_9__.TbWorld, {
                                                className: "w-[2rem] h-[2rem]"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_buttonAccount_ButtonAccount__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
                        className: "w-full h-fit desktop:hidden laptop:hidden  box-border py-5 tablet:px-[5rem]   mobile:px-[1rem] mobile:relative tablet:relative   ",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.div, {
                                className: "w-full h-full shadow-xl rounded-full box-border px-4 py-2 flex cursor-pointer",
                                onClick: (event)=>setIsShow(true),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_8__.FiSearch, {
                                        className: "h-full text-[2rem] m-auto"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "h-full w-fit flex flex-col ml-5 box-border",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-semibold",
                                                children: "Anywhere"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-[1rem]",
                                                children: "Anyweek & Addguests"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex-1"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-fit h-full   mobile:absolute mobile:top-0 mobile:right-0   tablet:absolute tablet:top-0 tablet:right-0   ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_filter_filter__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    isInvisible: ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_mobile_controlPlaneMobile__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7533:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1705);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6648);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Filter = ({ isInvisible  })=>{
    const buttonFilter = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const { setIsClickOutSide  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__/* .filterFormAnimateContext */ .b);
    const { filterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const { isFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__/* .getHouseContext */ .S);
    const [isEmpty, setIsEmpty] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(true);
    const handleOnClickFilter = async (event)=>{
        window.scrollTo(0, 0);
        setIsClickOutSide(true);
        document.body.style.overflow = "hidden";
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const emptyObjJson = JSON.stringify({
            maxPrice: 250,
            minPrice: 10,
            beds: 0,
            bathRooms: 0,
            typeHouse: [],
            amenities: [],
            hostLanguage: ""
        });
        const filterFormJson = JSON.stringify(filterForm);
        if (filterFormJson === emptyObjJson) {
            setIsEmpty(true);
        } else {
            setIsEmpty(false);
        }
    }, [
        isFilter,
        filterForm
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `w-[9.375rem] h-[5rem] flex ${isInvisible} mobile:h-full mobile:w-[6.25rem]
tablet:h-full tablet:w-[6.25rem]
      `,
            onClick: handleOnClickFilter,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `flex m-auto p-3 border-2 rounded-2xl cursor-pointer
          mobile:w-[3rem] mobile:h-full mobile:p-0 mobile:border-0
          tablet:w-[3rem] tablet:h-full tablet:p-0 tablet:border-0 relative
          ${isEmpty && isFilter !== "main" || isFilter !== "favoriteHouse" ? " border-slate-800" : "border-red-500"}
          `,
                ref: buttonFilter,
                children: [
                    isEmpty && isFilter !== "main" || isFilter !== "favoriteHouse" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        animate: {
                            scale: 1.2
                        },
                        transition: {
                            repeat: Infinity,
                            duration: 1
                        },
                        className: "w-[1rem] h-[1rem] rounded-full bg-red-400 absolute -right-1   top-4 flex opacity-70   ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-[.6rem] h-[.6rem] bg-red-600 rounded-full m-auto"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex w-fit h-[2rem] m-auto  mobile:h-full tablet:h-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiOutlineFilter, {
                                className: `w-[2rem] h-full m-auto ${isEmpty && isFilter !== "main" || isFilter !== "favoriteHouse" ? "" : "text-red-500"}`
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-fit h-full flex items-center mobile:hidden tablet:hidden ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "font-semibold",
                                    children: "Filter"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Filter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5348:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_rootMaskHeader_controlPlan_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8673);
/* harmony import */ var _components_rootMaskHeader_controlPlan_controlBar_popOver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4983);
/* harmony import */ var _contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8047);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_rootMaskHeader_controlPlan_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
([_components_rootMaskHeader_controlPlan_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const variants = {
    show: {
        visibility: [
            "hidden",
            "visible"
        ],
        top: [
            30,
            0
        ],
        opacity: [
            0,
            1
        ]
    },
    hidden: {
        top: [
            0,
            30
        ],
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            visibility: "hidden"
        }
    }
};
const ControlPlanMobile = ()=>{
    const { isShow , setIsShow  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_mobileControlPanel__WEBPACK_IMPORTED_MODULE_3__/* .mobileContolPanelContext */ .N);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.AnimatePresence, {
        initial: false,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
            className: "relative z-40 ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                className: "fixed right-0 top-0 w-screen h-screen bg-white  flex flex-col",
                variants: variants,
                animate: isShow ? "show" : "hidden",
                transition: {
                    type: "tween",
                    duration: 0.5
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        className: "flex-[0.5] ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.button, {
                            className: "h-full w-[6.25rem] overflow-hidden ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_6__.IoIosArrowRoundBack, {
                                className: "w-full text-[2.4rem] font-bold  stroke-[3rem] fill-red-500   text-red-500 ",
                                onClick: (event)=>setIsShow(false)
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        className: "flex-1 box-border px-[5rem] mobile:px-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_rootMaskHeader_controlPlan_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        className: "flex-[7] box-border w-full mb-[4.5rem] px-[5rem] py-5 mobile:px-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                            className: "w-full h-full relative border-2 rounded-2xl mobile:px-0  overflow-hidden",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_rootMaskHeader_controlPlan_controlBar_popOver__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ControlPlanMobile);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8673:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_searchBox_searchBox__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1539);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7607);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1705);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6648);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9445);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4146);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6197);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5641);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_7__, react_hook_form__WEBPACK_IMPORTED_MODULE_10__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_7__, react_hook_form__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const ControlBar = ()=>{
    const [submit, setSubmit] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_2__/* .selectPopoverContext */ .K);
    const { address  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__/* .selectPlaceContext */ .t);
    // const { isFilter, setIsFilter } = useContext(getHouseContext;
    const { setIsFilter , isFilter , setReRenderFilter , reRenderFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_4__/* .getHouseContext */ .S);
    const { setIsShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_3__/* .filterFormAnimateContext */ .b);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const isEmpty = ()=>{
        if (!address.address.formattedAddress && !address.guest.adults && !address.guest.childrens && !address.guest.infants) {
            return true;
        } else {
            return false;
        }
    };
    const fetchData = (event)=>{
        if (router.asPath !== "/homepage") {
            setIsShowHeader(false);
            router.push("/homepage", undefined, {
                shallow: true
            });
        }
        if (isEmpty()) {
            return;
        } else {
            setIsShowHeader(false);
            setIsFilter("noneAuthFilter");
            setReRenderFilter(reRenderFilter + 1);
            return;
        }
    };
    const onSelected = (event)=>{
        setSelected(event.currentTarget.id);
    };
    // validate while submit
    const onSubmit = (data)=>{
        setSubmit(true);
        handleCreate(data);
    };
    // form validate
    const { register , handleSubmit , setValue , formState: { errors  } , watch  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_10__.useForm)({
        defaultValues: {}
    });
    const handleCreate = async (data)=>{};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-full flex relative mobile:text-[1rem] mobile:flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-[0.6] flex mobile:text-[1rem]",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-col flex m-auto w-full rounded-full box-border pl-7   z-10 relative mobile:pl-0   ",
                    id: "where",
                    onClick: onSelected,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "Where"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            action: "",
                            onSubmit: handleSubmit(onSubmit),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_searchBox_searchBox__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    styleBox: null
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: errors.address && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: errors.address.message
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 flex mobile:flex-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 flex ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col m-auto flex-1 box-border pl-3   z-10 relative mobile:pl-0 mobile:text-[1rem] mobile:mt-5   ",
                            id: "checkin",
                            onClick: onSelected,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Appointment schedule"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-[1rem]",
                                    children: (0,date_fns__WEBPACK_IMPORTED_MODULE_6__.format)(address.checkInDay, "eeee, ddMMM")
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 flex mobile:flex-col",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex-1 flex flex-col m-auto box-border pl-3   z-10 relative mobile:text-[1rem] mobile:pl-0 mobile:mt-5   mobile:ml-0   ",
                                id: "who",
                                onClick: onSelected,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Who"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            address.guest.adults != 0 || address.guest.childrens != 0 ? address.guest.adults + address.guest.childrens + " guests" : "Add guests ",
                                            address.guest.infants != 0 && ", " + address.guest.infants + " infants"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex box-border p-3 w-full relative z-10 mobile:py-5 tablet:py-5 ",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.div, {
                                    whileTap: {
                                        scale: 0.8
                                    },
                                    className: "rounded-full w-full h-full bg-red-500 flex ",
                                    id: "btn-search-header",
                                    onClick: fetchData,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_11__.BiSearch, {
                                            className: "w-[2rem] h-[2rem] m-auto text-white tablet:w-[1rem] tablet:h-[1rem] mobile:w-[1rem] mobile:h-[1rem]"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-white font-semibold m-auto ml-0 tablet:hidden mobile:hidden",
                                            children: "Search"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ControlBar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4983:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7607);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _popOverDetail_checkIn_Out__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4141);
/* harmony import */ var _popOverDetail_who__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(779);





const Popover = ()=>{
    const { selected , setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_1__/* .selectPopoverContext */ .K);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "absolute tablet:w-full w-[850px] h-[480px] top-24 pointer-events-none   mobile:w-full tablet:h-full mobile:h-full tablet:top-0 mobile:top-0   ",
        id: "root-popup",
        onClick: (event)=>event.stopPropagation(),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full h-full flex",
            children: [
                selected === "who" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popOverDetail_who__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    styleWho: null
                }),
                selected === "checkin" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popOverDetail_checkIn_Out__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    styleHorizontal: " mobile:hidden",
                    styleVerical: " laptop:hidden desktop:hidden tablet:hidden"
                }),
                selected === "checkout" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popOverDetail_checkIn_Out__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    styleHorizontal: "tablet:hidden mobile:hidden",
                    styleVerical: " laptop:hidden desktop:hidden tablet:hidden"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Popover);


/***/ }),

/***/ 1539:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1705);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9445);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var bingmaps__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5538);
/* harmony import */ var bingmaps__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bingmaps__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);




 // <--  Microsoft supported types library for Microsoft.Maps

const SearchBox = ({ styleBox  })=>{
    const { address , setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_2__/* .selectPlaceContext */ .t);
    const { isShowHeader , setIsShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_1__/* .filterFormAnimateContext */ .b);
    const inputBox = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    // luu y la chi cho nhung doan code ve map vao useEffect con nhung doan code ve input nhap lieu thi
    // khong duoc cho vao useEffect
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__.whenLoaded.then(()=>{
            Microsoft.Maps.loadModule("Microsoft.Maps.AutoSuggest", {
                callback: onLoad
            });
        });
        function onLoad() {
            var options = {
                maxResults: 5,
                businessSuggestions: true
            };
            var manager = new Microsoft.Maps.AutosuggestManager(options);
            manager.attachAutosuggest("#searchBox", "#searchBoxContainer", (suggestionResult)=>{
                setIsShowHeader(true);
                setAddress({
                    ...address,
                    address: {
                        ...address.address,
                        ...suggestionResult?.address,
                        ...suggestionResult?.location
                    }
                });
            });
        }
        const temp = document.getElementById("searchBox");
        temp?.addEventListener("change", (event)=>{
            setAddress({
                ...address,
                address: {
                    ...address.address,
                    formattedAddress: event.target.value
                }
            });
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            id: "searchBoxContainer",
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "text",
                name: "input-place",
                id: "searchBox",
                ref: inputBox,
                placeholder: "Search your locations",
                className: `outline-none focus:border-b-2 focus:border-slate-600 w-[calc(100%-2.4rem)] ${styleBox} pointer-events-auto text-ellipsis `
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SearchBox);


/***/ })

};
;