"use strict";
exports.id = 248;
exports.ids = [248];
exports.modules = {

/***/ 3890:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9445);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);





const MapFilter = ({ keyMapBing  })=>{
    const { address , setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_2__/* .selectPlaceContext */ .t);
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__.whenLoaded.then(()=>{
            const map_ = document.getElementById("Mapfilter");
            if (map_) {
                const map = new Microsoft.Maps.Map(map_, {
                    /* No need to set credentials if already passed in URL */ center: new Microsoft.Maps.Location(16.047079, 108.206230),
                    mapTypeId: Microsoft.Maps.MapTypeId.road,
                    zoom: 16,
                    credentials: keyMapBing,
                    disableScrollWheelZoom: true
                });
                var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), undefined);
                var layer = new Microsoft.Maps.Layer();
                layer.add(pushpin);
                map.layers.insert(layer);
                Microsoft.Maps.loadModule("Microsoft.Maps.AutoSuggest", {
                    callback: ()=>{
                        var options = {
                            maxResults: 5,
                            businessSuggestions: true
                        };
                        var manager = new Microsoft.Maps.AutosuggestManager(options);
                        manager.attachAutosuggest("#searchBox9", "#searchBoxContainer9", (suggestionResult)=>{
                            map.entities.clear();
                            map.setView({
                                bounds: suggestionResult.bestView
                            });
                            var pushpin = new Microsoft.Maps.Pushpin(suggestionResult.location);
                            map.entities.push(pushpin);
                            console.log(suggestionResult);
                            const addressSuggest = suggestionResult?.address;
                            const locationSuggest = suggestionResult?.location;
                            setAddress({
                                ...address,
                                address: {
                                    addressLine: addressSuggest.addressLine + "",
                                    adminDistrict: addressSuggest.adminDistrict + "",
                                    countryRegion: addressSuggest.countryRegion + "",
                                    countryRegionISO2: addressSuggest.countryRegionISO2 + "",
                                    district: addressSuggest.district + "",
                                    formattedAddress: addressSuggest.formattedAddress + "",
                                    locality: addressSuggest.locality + "",
                                    postalCode: addressSuggest.postalCode + "",
                                    latitude: locationSuggest.latitude,
                                    longitude: locationSuggest.longitude,
                                    title: suggestionResult?.title + "",
                                    streetName: ""
                                }
                            });
                        });
                    }
                });
            }
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative w-full h-[28rem]",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-full absolute top-0 left-0 rounded-3xl border-2 border-red-400
      overflow-hidden h-[21.875rem]

      `,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    id: "Mapfilter",
                    className: "relative z-10"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "searchBoxContainer9",
                className: "border-b-2  absolute top-[21.875rem] mt-5 left-0 w-full ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    placeholder: "Search location",
                    id: "searchBox9",
                    type: "text",
                    className: "w-full h-[3rem] outline-none text-[2rem]"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapFilter);


/***/ }),

/***/ 2287:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _arrAmenities__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7763);
/* harmony import */ var _checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8183);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__]);
_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const Amenities = ()=>{
    const arrAmenities_ = _arrAmenities__WEBPACK_IMPORTED_MODULE_4__/* .arrAmenities */ ._;
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{}, [
        filterForm
    ]);
    const handleOnClick = (event, item)=>{
        const arrTemp = Array.isArray(filterForm.amenities) ? filterForm.amenities : [];
        if (arrTemp.includes(item)) {
            const updateArrTemp = arrTemp.filter((item_)=>{
                return item_ !== item;
            });
            setFilterForm({
                ...filterForm,
                amenities: updateArrTemp
            });
            return;
        }
        arrTemp.push(item);
        setFilterForm({
            ...filterForm,
            amenities: arrTemp
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full mb-14",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-fit grid grid-cols-2 gap-y-5 mt-3",
            children: arrAmenities_.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full cursor-pointer",
                    onClick: (event)=>handleOnClick(event, item),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex h-full box-border overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "my-auto",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkBox_checkBox__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        // filterForm.amenities.includes(item) ? true : false
                                        isCheckedProps: Array.isArray(filterForm.amenities) ? filterForm.amenities.includes(item) ? true : false : false
                                    }),
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "h-full flex items-center   ml-5 text-[19px]   ",
                                children: item
                            })
                        ]
                    })
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Amenities);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ arrAmenities)
/* harmony export */ });
const arrAmenities = [
    "Kitchen",
    "Air Conditioning",
    "TV",
    "Fridge",
    "Pool",
    "Washer",
    "Luxury interior",
    "Full interior",
    "Empty interior",
    "Basic interior"
];


/***/ }),

/***/ 2000:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const BedsBathRooms = ()=>{
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const styleButton = "w-[4rem] h-[2.4rem] rounded-full border-2 border-slate-600 ml-3 mobile:ml-0";
    const arrButton = [];
    for(let index = 0; index <= 8; index++){
        arrButton.push(index);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-fit",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-fit mb-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Beds"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full flex justify-start mt-2",
                        children: arrButton.map((item, index)=>{
                            if (index == 0) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                                    whileTap: {
                                        scale: 0.6
                                    },
                                    transition: {
                                        duration: 0.5
                                    },
                                    className: `${styleButton.replace("ml-3 ", "")}
                                ${filterForm.beds == 0 ? "bg-black text-white" : ""}
                              `,
                                    onClick: (event)=>setFilterForm({
                                            ...filterForm,
                                            beds: index
                                        }),
                                    children: "Any"
                                }, index);
                            }
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                                whileTap: {
                                    scale: 0.6
                                },
                                transition: {
                                    duration: 0.5
                                },
                                className: ` ${styleButton}
                            ${filterForm.beds == index ? "bg-black text-white" : ""}
                              `,
                                onClick: (event)=>setFilterForm({
                                        ...filterForm,
                                        beds: index
                                    }),
                                children: [
                                    index,
                                    index == 8 ? "+" : ""
                                ]
                            }, index);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-fit mb-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Bathrooms"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full flex justify-start mt-2",
                        children: arrButton.map((item, index)=>{
                            if (index == 0) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                                    whileTap: {
                                        scale: 0.6
                                    },
                                    transition: {
                                        duration: 0.5
                                    },
                                    className: `${styleButton.replace("ml-3", "")}
                                ${filterForm.bathRooms == 0 ? "bg-black text-white" : ""}
                              `,
                                    onClick: (event)=>setFilterForm({
                                            ...filterForm,
                                            bathRooms: index
                                        }),
                                    children: "Any"
                                }, index);
                            }
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                                whileTap: {
                                    scale: 0.6
                                },
                                transition: {
                                    duration: 0.5
                                },
                                className: ` ${styleButton}
                            ${filterForm.bathRooms == index ? "bg-black text-white" : ""}
                              `,
                                onClick: (event)=>setFilterForm({
                                        ...filterForm,
                                        bathRooms: index
                                    }),
                                children: [
                                    index,
                                    index == 8 ? "+" : ""
                                ]
                            }, index);
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BedsBathRooms);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3129:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var _utils_compass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9239);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




const CompassFilter = ()=>{
    const compass = _utils_compass__WEBPACK_IMPORTED_MODULE_3__/* .compassUtils */ .N;
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const handeOcClick = (item)=>{
        setFilterForm({
            ...filterForm,
            orientation: item
        });
        console.log(filterForm);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-fit border-2 rounded-xl overflow-hidden",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
            className: "select px-0 w-full outline-none text-[2rem]  text-center",
            onChange: (event)=>handeOcClick(event.target.value),
            children: compass.map((item, index)=>{
                if (index == 0) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        selected: true,
                        children: item
                    }, index);
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                    children: item
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CompassFilter);


/***/ }),

/***/ 9838:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6648);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);




const HostLanguage = ()=>{
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const { isFilter , setIsFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_2__/* .getHouseContext */ .S);
    const arrLanguage = [
        "HouseForSale",
        "HouseForRent"
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-fit",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full grid grid-cols-2",
            children: arrLanguage.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-1 h-[6.25rem] flex",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: (event)=>{
                            if (filterForm.typeHouse.includes(item)) {
                                const temp = filterForm.typeHouse.filter((items)=>items != item);
                                setFilterForm({
                                    ...filterForm,
                                    typeHouse: temp
                                });
                                console.log(filterForm.typeHouse);
                                return;
                            }
                            setFilterForm({
                                ...filterForm,
                                typeHouse: [
                                    ...filterForm.typeHouse,
                                    item
                                ]
                            });
                        },
                        className: `w-[80%] h-[4.5rem] m-auto border-2 rounded-xl hover:bg-redIcon hover:text-white
                active:scale-[.8] transition-all duration-500
                ${filterForm.typeHouse.includes(item) ? "bg-redIcon text-white" : ""}`,
                        children: item
                    })
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HostLanguage);


/***/ }),

/***/ 1856:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1817);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rc_slider__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__);





const PriceRange = ()=>{
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const handleOnChange = (value)=>{
        setFilterForm({
            ...filterForm,
            minPrice: value[0],
            maxPrice: value[1]
        });
        const inputMin = document.getElementById("inputMin");
        const inputMax = document.getElementById("inputMax");
        if (inputMin && inputMax) {
            inputMin.value = "";
            inputMax.value = "";
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full border-b-2 pb-10 border-slate-500",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-[6.25rem] flex box-border px-6",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((rc_slider__WEBPACK_IMPORTED_MODULE_2___default()), {
                    range: true,
                    allowCross: false,
                    draggableTrack: true,
                    defaultValue: [
                        10,
                        500000
                    ],
                    onChange: handleOnChange,
                    value: [
                        filterForm.minPrice,
                        filterForm.maxPrice
                    ],
                    className: "m-auto ",
                    min: 10,
                    max: 500000,
                    trackStyle: {
                        backgroundColor: "black",
                        height: 2
                    },
                    railStyle: {
                        height: 2
                    },
                    handleStyle: {
                        backgroundColor: "#FFFFFF",
                        opacity: 1,
                        border: "1px solid grey",
                        width: 30,
                        height: 30,
                        marginTop: -13
                    }
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[4.5rem] flex mobile:w-full mobile:flex-col mobile:h-fit ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 h-full border-2 rounded-2xl flex items-center mobile:py-3   mobile:mb-5   ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full h-fit flex flex-col box-border px-6",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Minimum"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full flex",
                                    children: [
                                        "$",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            id: "inputMin",
                                            placeholder: filterForm.minPrice + "",
                                            className: "outline-none overflow-y-hidden",
                                            onChange: (event)=>{
                                                const temp = Number.parseInt(event.target.value);
                                                if (temp < 10 || temp > filterForm.maxPrice || !temp) return;
                                                setFilterForm({
                                                    ...filterForm,
                                                    minPrice: temp
                                                });
                                            }
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[3rem] h-full flex mobile:hidden ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineMinus, {
                            className: "m-auto text-[2rem]"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 h-full border-2 rounded-2xl flex items-center mobile:py-3",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full h-fit flex flex-col box-border px-6 ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Maximum"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full flex",
                                    children: [
                                        "$",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            type: "number",
                                            id: "inputMax",
                                            placeholder: filterForm.maxPrice + "",
                                            className: "outline-none overflow-y-hidden",
                                            onChange: (event)=>{
                                                const temp = Number.parseInt(event.target.value);
                                                if (temp > 500000 || temp < filterForm.minPrice || !temp) return;
                                                setFilterForm({
                                                    ...filterForm,
                                                    maxPrice: temp
                                                });
                                            }
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PriceRange);


/***/ }),

/***/ 9125:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const variantsPropertyItems = {
    isHover: {
        scale: 1.1
    }
};
const PropertyHouse = ()=>{
    const arrPropertyItems = [
        {
            title: "House",
            imgPath: "https://a0.muscache.com/pictures/4d7580e1-4ab2-4d26-a3d6-97f9555ba8f9.jpg"
        },
        {
            title: "Apartment",
            imgPath: "https://a0.muscache.com/pictures/21cfc7c9-5457-494d-9779-7b0c21d81a25.jpg"
        },
        {
            title: "Guesthouse",
            imgPath: "https://a0.muscache.com/pictures/6f261426-2e47-4c91-8b1a-7a847da2b21b.jpg"
        }
    ];
    const { filterForm , setFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "grid grid-cols-3 grid-rows-1 mobile:grid-cols-1 mobile:grid-rows-3",
        children: arrPropertyItems.map((item, index)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full flex justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                    className: `w-[9.375rem] h-[130px] border-2 rounded-2xl box-border p-2 mobile:w-full
              mobile:mb-5
                            ${filterForm.typeHouse.includes(item.title) ? "border-black" : ""}
                          `,
                    variants: variantsPropertyItems,
                    whileTap: {
                        scale: 0.6
                    },
                    transition: {
                        duration: 0.5
                    },
                    onClick: (event)=>{
                        const arrTemp = filterForm.typeHouse;
                        // if typeHouse have exist => remove it
                        if (filterForm.typeHouse.includes(item.title)) {
                            const updateArrTemp = arrTemp.filter((item_)=>{
                                return item_ !== item.title;
                            });
                            setFilterForm({
                                ...filterForm,
                                typeHouse: updateArrTemp
                            });
                            return;
                        }
                        arrTemp.push(item.title);
                        setFilterForm({
                            ...filterForm,
                            typeHouse: arrTemp
                        });
                        return;
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex flex-col h-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: `${item.imgPath}`,
                                    alt: ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "m-auto mb-2 ml-2",
                                    children: item.title
                                })
                            })
                        ]
                    })
                }, index)
            }, index);
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PropertyHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 376:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export variantsAmenities */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3565);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1705);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6648);
/* harmony import */ var _contexts_isShowPt__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1069);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9445);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _filterFormComponent_Mapfilter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3890);
/* harmony import */ var _filterFormComponent_amenities_amenities__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2287);
/* harmony import */ var _filterFormComponent_bedsBathrooms__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2000);
/* harmony import */ var _filterFormComponent_compass__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3129);
/* harmony import */ var _filterFormComponent_hostLanguage__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9838);
/* harmony import */ var _filterFormComponent_priceRange__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1856);
/* harmony import */ var _filterFormComponent_property__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9125);
/* harmony import */ var _contexts_houseTemp__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1790);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_6__, _filterFormComponent_amenities_amenities__WEBPACK_IMPORTED_MODULE_10__, _filterFormComponent_bedsBathrooms__WEBPACK_IMPORTED_MODULE_11__, _filterFormComponent_property__WEBPACK_IMPORTED_MODULE_15__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_6__, _filterFormComponent_amenities_amenities__WEBPACK_IMPORTED_MODULE_10__, _filterFormComponent_bedsBathrooms__WEBPACK_IMPORTED_MODULE_11__, _filterFormComponent_property__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const variantsAmenities = {
    showMore: {
        height: 100
    },
    show: {
        translateY: [
            2000,
            0
        ]
    },
    hidden: {
        translateY: [
            0,
            2000
        ]
    }
};
const FormFilter = ({ keyMapBing  })=>{
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const { filterForm , setFilterForm , emptyFilterForm , resetFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_1__/* .filterContext */ .u);
    const { setIsFilter , isFilter , setReRenderFilter , reRenderFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__/* .getHouseContext */ .S);
    const { isClickOutSide , setIsClickOutSide  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__/* .filterFormAnimateContext */ .b);
    const { address , setAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_5__/* .selectPlaceContext */ .t);
    const { isShowAllPt  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_isShowPt__WEBPACK_IMPORTED_MODULE_4__/* .IsShowPtContext */ .Y);
    const formFilter = (0,react__WEBPACK_IMPORTED_MODULE_7__.useRef)(null);
    const { setHouseTemp  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_houseTemp__WEBPACK_IMPORTED_MODULE_16__/* .houseTempContext */ .W);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        const handleOnClickOutSide = (event)=>{
            if (formFilter.current) {
                const formFilter_ = formFilter.current;
                const isClickOutSide_ = formFilter_.contains(event.target);
                if (!isClickOutSide_) {
                    document.body.style.overflow = "scroll";
                    document.body.style.overflowX = "hidden";
                    setIsClickOutSide(false);
                }
            }
        };
        document.addEventListener("mousedown", handleOnClickOutSide);
    }, [
        isShowAllPt
    ]);
    const isEmpty = ()=>{
        const emptyObj = {
            maxPrice: 500000,
            minPrice: 10,
            beds: 0,
            bathRooms: 0,
            typeHouse: [],
            amenities: [],
            hostLanguage: "",
            orientation: ""
        };
        const emptyAddress = {
            countryRegion: "",
            locality: "",
            adminDistrict: "",
            countryRegionISO2: "",
            postalCode: "",
            addressLine: "",
            streetName: "",
            formattedAddress: "",
            latitude: 0,
            longitude: 0,
            title: "",
            district: ""
        };
        const emptyObjJson = JSON.stringify(emptyObj);
        const filterFormJson = JSON.stringify(filterForm);
        const emptyAddressJson = JSON.stringify(emptyAddress);
        const addressJson = JSON.stringify(address.address);
        if (emptyObjJson === filterFormJson && emptyAddressJson === addressJson) return true;
        return false;
    };
    const fetchData = async ()=>{
        setIsClickOutSide(false);
        document.body.style.overflow = "scroll";
        document.body.style.overflowX = "hidden";
        const element = document.getElementById("slideShowHouse");
        if (element) {
            element.scrollIntoView({
                behavior: "smooth"
            });
        }
        // neu du lieu co ton tai thi la fetch lai du lieu neu khong thi bo qua
        if (!isEmpty()) {
            setIsFilter("noneAuthFilter");
            setReRenderFilter(reRenderFilter + 1);
            return;
        } else {
            setIsFilter("main");
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{}, [
        filterForm,
        address
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.AnimatePresence, {
            initial: false,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.div, {
                variants: variantsAmenities,
                animate: isClickOutSide ? "show" : "hidden",
                transition: {
                    duration: 0.5,
                    type: "tween"
                },
                className: "w-[800px] h-[calc(100vh-3rem)] bg-white m-auto rounded-3xl   flex flex-col   mobile:mt-0 mobile:rounded-none mobile:w-screen mobile:h-screen   tablet:h-[calc(100vh-5.625rem)] tablet:mt-[.6rem] z-30   ",
                ref: formFilter,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: " flex-2 w-full border-b-2 flex relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "m-auto font-semibold text-[1rem]",
                                children: "Filter"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.button, {
                                className: "absolute w-[4.5rem] h-full flex desktop:hidden laptop:hidden",
                                onClick: (event)=>setIsClickOutSide(false),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-fit h-full m-auto",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_8__.GrClose, {
                                        className: "text-[2rem]"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full flex-[9] h-[75vh] overflow-x-hidden  overflow-scroll box-border p-10",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full h-fit mb-5",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "w-full h-fit flex flex-col",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-bold text-[2rem]",
                                                children: "Price range"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-[1rem]",
                                                children: "The average nightly price is $79, not including fees or taxes."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_priceRange__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col  pb-3",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[2rem] mb-5",
                                            children: "Map"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_Mapfilter__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            keyMapBing: keyMapBing
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col  pb-3",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[2rem] mb-5",
                                            children: "Beds & Bathrooms"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_bedsBathrooms__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mb-5 border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[2rem] mb-5",
                                            children: "Property type"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_property__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mb-5 border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[2rem] mb-5",
                                            children: "Amenities"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_amenities_amenities__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mb-5 border-b-2 border-slate-500 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[2rem] mb-5",
                                            children: "Orientation"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_compass__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mb-5 py-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex flex-col ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold text-[2rem] mb-5",
                                            children: "Type house"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_filterFormComponent_hostLanguage__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full border-t-2 flex items-center flex-2 py-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex justify-start",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "m-auto underline cursor-pointer",
                                    onClick: (event)=>{
                                        setHouseTemp([]);
                                        const addressTemp = {
                                            countryRegion: "",
                                            locality: "",
                                            adminDistrict: "",
                                            countryRegionISO2: "",
                                            postalCode: "",
                                            addressLine: "",
                                            streetName: "",
                                            formattedAddress: "",
                                            latitude: 0,
                                            longitude: 0,
                                            title: "",
                                            district: ""
                                        };
                                        // setFilterForm({...emptyFilterForm, typeHouse: []});
                                        resetFilterForm();
                                        setFilterForm({
                                            ...filterForm,
                                            amenities: []
                                        });
                                        setAddress({
                                            ...address,
                                            address: {
                                                ...addressTemp
                                            }
                                        });
                                    },
                                    children: "Clear all"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_6__.motion.button, {
                                    className: "w-[12.5rem] h-[2.4rem] rounded-lg border-2",
                                    whileHover: {
                                        backgroundColor: "rgba(255, 56, 92, 0.8)",
                                        color: "white"
                                    },
                                    onClick: fetchData,
                                    whileTap: {
                                        scale: 0.9
                                    },
                                    children: "Submit"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormFilter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7537:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7607);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1705);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _controlBar_controlBar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8673);
/* harmony import */ var _controlBar_popOver__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4983);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__, _controlBar_controlBar__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_3__, _controlBar_controlBar__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const variants = {
    controlHeaderShow: {
        display: "flex",
        opacity: [
            0,
            1
        ],
        transition: {
            delay: 0.2
        }
    },
    controlHeaderHidden: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        }
    },
    slideDownControlBar: {
        scale: [
            1,
            1.2
        ],
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        },
        transition: {
            type: "tween",
            duration: 0.2,
            ease: "easeOut"
        }
    },
    slideUpControlBar: {
        scale: [
            1.2,
            1
        ],
        opacity: [
            0,
            1
        ],
        display: "flex",
        transition: {
            delay: 0.2
        }
    },
    showUpLinkControl: {
        opacity: [
            0,
            1
        ],
        display: "flex"
    },
    hiddenLinkControl: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        },
        transition: {
            duration: 0.2
        }
    }
};
const ControlPlan = ()=>{
    const { isShow , setIsShow , setIsShowHeader , isShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_2__/* .filterFormAnimateContext */ .b);
    const [isFirstLoading, setIsFirstLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    const refHeader = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const refHeaderControl = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const arrLink = [
        {
            ref: "",
            title: "Stays"
        },
        {
            ref: "",
            title: "Experiences"
        },
        {
            ref: "",
            title: "Online Experiences"
        }
    ];
    const { setSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_1__/* .selectPopoverContext */ .K);
    const onSelected = (popoverId)=>{
        setSelected(popoverId);
    };
    // animate by hand again :")))"
    const handleOnScaleDown = (event)=>{
        setIsShowHeader(true);
        const inputElement = document.getElementById("searchBox");
        if (inputElement) {
            inputElement.focus();
        }
    };
    const isClickOutSide = (event)=>{
        const isClickHeaderRoot = document.getElementById("header-root")?.contains(event.target);
        const isClickHeaderControl = refHeaderControl.current?.contains(event.target);
        if (!isClickHeaderRoot && !isClickHeaderControl) {
            setIsShowHeader(false);
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        document.addEventListener("click", isClickOutSide);
        document.addEventListener("scroll", isClickOutSide);
        setIsFirstLoading(false);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        isShowHeader
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-[34.3rem] box-border p-4 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full h-full",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex overflow-hidden mb-1 ",
                            id: "link",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                                variants: variants,
                                animate: isShowHeader ? "showUpLinkControl" : "hiddenLinkControl",
                                className: "m-auto mt-3 w-full grid grid-cols-3 grid-rows-1",
                                children: arrLink.map((item, index)=>{
                                    return(// <Link
                                    //   key={index}
                                    //   href={`${item.ref}`} >
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: " relative w-full   before:bottom-0 before:h-[.2rem]  before:w-0 before:absolute   before:bg-slate-500 hover:before:w-full before:transition-all   before:duration-200   ",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-fit h-full m-auto",
                                            children: item.title
                                        })
                                    }, index));
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                            ref: refHeader,
                            variants: variants,
                            animate: isShowHeader ? "slideDownControlBar" : "slideUpControlBar",
                            className: "w-full h-full box-border px-1 flex items-center   rounded-full border-slate-400 bg-[#f05123] text-slate-100 font-semibold   ",
                            id: "scaleUp",
                            onClick: handleOnScaleDown,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "flex-1 h-full",
                                    id: "header-control_bar-list-index-1",
                                    onClick: (event)=>{
                                        onSelected("where");
                                    },
                                    children: "Search Location"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "flex-1 border-x-2 border-slate-400 h-full",
                                    id: "header-control_bar-list-index-2",
                                    onClick: (event)=>onSelected("checkin"),
                                    children: "Schedule"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "flex-1 h-full",
                                    id: "header-control_bar-list-index-4",
                                    onClick: (event)=>onSelected("who"),
                                    children: "Guests"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                variants: variants,
                animate: isShowHeader ? "controlHeaderShow" : "controlHeaderHidden",
                ref: refHeaderControl,
                className: "absolute w-full h-[5rem] mt-[5rem] bg-white   box-border z-20   after:h-full after:left-0 after:top-0 after:absolute   after:w-[calc(100vw-(100vw-100%)/2)] after:bg-white after:-z-10      before:h-full before:right-0 before:top-0 before:absolute   before:w-[calc(100vw-(100vw-100%)/2)] before:bg-white before:-z-10   ",
                id: "ControlHeader",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-[850px] tablet:w-full h-[90%] box-border rounded-full m-auto flex   text-[15px] transition-all duration-300 border-2   cursor-pointer   ",
                    id: "controlBar",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_controlBar_controlBar__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_controlBar_popOver__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ControlPlan);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8248:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_loginPanel_LoginPanel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7607);
/* harmony import */ var _contexts_placeList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3903);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _controlPlan_controlPlan__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7537);
/* harmony import */ var _headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5209);
/* harmony import */ var _main_filter_formFilter_formFilter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(376);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6197);
/* harmony import */ var _contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1705);
/* harmony import */ var _components_main_showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8462);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_loginPanel_LoginPanel__WEBPACK_IMPORTED_MODULE_1__, _controlPlan_controlPlan__WEBPACK_IMPORTED_MODULE_5__, _headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_6__, _main_filter_formFilter_formFilter__WEBPACK_IMPORTED_MODULE_7__, framer_motion__WEBPACK_IMPORTED_MODULE_8__]);
([_components_loginPanel_LoginPanel__WEBPACK_IMPORTED_MODULE_1__, _controlPlan_controlPlan__WEBPACK_IMPORTED_MODULE_5__, _headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_6__, _main_filter_formFilter_formFilter__WEBPACK_IMPORTED_MODULE_7__, framer_motion__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const variants = {
    show: {
        display: "flex",
        opacity: [
            0,
            1
        ]
    },
    hidden: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        }
    }
};
const HeaderMain = ({ keyMapBing , keyChatEngine  })=>{
    const { setPlaceList  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_placeList__WEBPACK_IMPORTED_MODULE_3__/* .placeListContext */ .P);
    const { isLoginClick , setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_2__/* .selectPopoverContext */ .K);
    const { isClickOutSide , setIsClickOutSide , isShowHeader , setIsShowHeader  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_filterFormAnimate__WEBPACK_IMPORTED_MODULE_9__/* .filterFormAnimateContext */ .b);
    const [isFirstLoading, setIsFirstLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    const loginPanel = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const mask = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)(null);
    const handleOnMask = (event)=>{
        setPlaceList([]);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        // animate de mo popup login
        // const handleOnclickLogin = (event: any) => {
        //   const isClick = loginPanel.current?.contains(event.target);
        //   if (!isClick && isLoginClick) {
        //     mask.current?.classList.remove('animate-transparentAnimateLogin2');
        //     loginPanel.current?.classList.remove('animate-slideUpLogin');
        //     mask.current?.classList.add('animate-transparentAnimateLoginReverse2');
        //     loginPanel.current?.classList.add('animate-slideDownLogin');
        //     setIsLoginClick(false);
        //     return;
        //   }
        // };
        // animate de dong popup login
        const handleOnClickLogin2 = (event)=>{
            if (isFirstLoading) return;
            mask.current?.classList.remove("animate-transparentAnimateLogin2");
            loginPanel.current?.classList.remove("animate-slideUpLogin");
            mask.current?.classList.add("animate-transparentAnimateLoginReverse2");
            loginPanel.current?.classList.add("animate-slideDownLogin");
            setIsLoginClick(false);
        };
        // animate for dynamic event
        const handleIsClick = ()=>{
            if (isLoginClick) {
                mask.current?.classList.remove("animate-transparentAnimateLoginReverse2");
                loginPanel.current?.classList.remove("animate-slideDownLogin");
                mask.current?.classList.add("animate-transparentAnimateLogin2");
                loginPanel.current?.classList.add("animate-slideUpLogin");
                return;
            } else if (!isLoginClick && !isFirstLoading) {
                mask.current?.classList.remove("animate-transparentAnimateLogin2");
                loginPanel.current?.classList.remove("animate-slideUpLogin");
                mask.current?.classList.add("animate-transparentAnimateLoginReverse2");
                loginPanel.current?.classList.add("animate-slideDownLogin");
            }
        };
        // document.addEventListener('mousedown', handleOnclickLogin);
        document.addEventListener("scroll", handleOnClickLogin2);
        handleIsClick();
        setIsFirstLoading(false);
    }, [
        isLoginClick
    ]);
    const handleOnClickLogin = (event)=>{
        const isClickInSide = loginPanel.current?.contains(event.target);
        if (!isClickInSide) {
            setIsLoginClick(false);
            return;
        } else {
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        isShowHeader,
        isClickOutSide
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.div, {
                    variants: variants,
                    animate: isClickOutSide ? "show" : "hidden",
                    transition: {
                        duration: 0.5
                    },
                    className: "w-screen h-screen bg-mask absolute z-40   overflow-hidden ",
                    id: "maskFilter",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_main_filter_formFilter_formFilter__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        keyMapBing: keyMapBing
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.div, {
                    variants: _components_main_showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_10__/* .variants */ .o,
                    animate: isLoginClick ? "showMask" : "hiddenMask",
                    onClick: handleOnClickLogin,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit h-fit m-auto  mobile:w-screen mobile:h-screen   flex flex-col mobile:p-0 p-5 rounded-xl ",
                        ref: loginPanel,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loginPanel_LoginPanel__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            keyChatEngine: keyChatEngine,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_8__.motion.div, {
                variants: variants,
                animate: isShowHeader ? "show" : "hidden",
                className: "w-screen h-screen opacity-0 bg-mask z-20 fixed top-0 left-0",
                id: "mask",
                onClick: handleOnMask
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_controlPlan_controlPlan__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderMain);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;