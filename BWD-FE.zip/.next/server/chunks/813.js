"use strict";
exports.id = 813;
exports.ids = [813];
exports.modules = {

/***/ 1964:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9765);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const AnimateTitle = ({ title , textStyles  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.p, {
        variants: _utils_motion__WEBPACK_IMPORTED_MODULE_1__/* .textContainer */ .AR,
        className: `font-bold text-[2.4rem]
 mobile:text-[2rem] mobile:text-left pl-[40px] ${textStyles}
      `,
        children: Array.from(title).map((letter, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.span, {
                variants: _utils_motion__WEBPACK_IMPORTED_MODULE_1__/* .textVariant2 */ .lM,
                children: letter === " " ? "\xa0" : letter
            }, index))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AnimateTitle);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 754:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8194);
/* harmony import */ var _api_client_houseApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(860);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6648);
/* harmony import */ var _contexts_houseTemp__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1790);
/* harmony import */ var _contexts_selectHouse__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2586);
/* harmony import */ var filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1711);
/* harmony import */ var filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8984);
/* harmony import */ var filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(391);
/* harmony import */ var filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(filepond_plugin_image_preview_dist_filepond_plugin_image_preview_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1137);
/* harmony import */ var filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(filepond_dist_filepond_min_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6197);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1817);
/* harmony import */ var rc_slider__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(rc_slider__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5178);
/* harmony import */ var react_filepond__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_filepond__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5641);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _amenities_editAmenities__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8235);
/* harmony import */ var _inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9578);
/* harmony import */ var _inputForm_map__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5061);
/* harmony import */ var _removeImg_removeImg__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1013);
/* harmony import */ var _utils_compass__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(9239);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__, _api_client_houseApi__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_10__, react_hook_form__WEBPACK_IMPORTED_MODULE_14__, _amenities_editAmenities__WEBPACK_IMPORTED_MODULE_16__, _removeImg_removeImg__WEBPACK_IMPORTED_MODULE_19__]);
([_api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__, _api_client_houseApi__WEBPACK_IMPORTED_MODULE_2__, framer_motion__WEBPACK_IMPORTED_MODULE_10__, react_hook_form__WEBPACK_IMPORTED_MODULE_14__, _amenities_editAmenities__WEBPACK_IMPORTED_MODULE_16__, _removeImg_removeImg__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















(0,react_filepond__WEBPACK_IMPORTED_MODULE_13__.registerPlugin)((filepond_plugin_image_exif_orientation__WEBPACK_IMPORTED_MODULE_6___default()), (filepond_plugin_image_preview__WEBPACK_IMPORTED_MODULE_7___default()));
const EditForm = ({ keyMapBing , api_url_path , setIsEdit , infShow  })=>{
    const { selectHouse  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useContext)(_contexts_selectHouse__WEBPACK_IMPORTED_MODULE_5__/* .selectHouseContext */ .q);
    const { houseTemp , setHouseTemp  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useContext)(_contexts_houseTemp__WEBPACK_IMPORTED_MODULE_4__/* .houseTempContext */ .W);
    const styleInput = "box-border p-3";
    const compass = _utils_compass__WEBPACK_IMPORTED_MODULE_21__/* .compassUtils */ .N;
    const tempPrice = selectHouse?.Price;
    const [tempHouse, setTempHouse] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(selectHouse);
    const [imgArr, setImgArr] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)([]);
    const filePondRef = (0,react__WEBPACK_IMPORTED_MODULE_12__.useRef)(null);
    const { setReRenderFilter , reRenderFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_12__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_3__/* .getHouseContext */ .S);
    const { register , handleSubmit , watch , reset , setError , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_14__.useForm)({
        defaultValues: tempHouse
    });
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{
        reset(selectHouse);
        setTempHouse(selectHouse);
    }, [
        selectHouse
    ]);
    const onSubmit = async (data)=>{
        console.log("temp", tempHouse?.arrImg);
        nprogress__WEBPACK_IMPORTED_MODULE_20___default().set(.6);
        if (filePondRef.current) {
            await filePondRef.current.processFiles();
        }
        if (tempHouse) {
            console.log("data", data);
            const data0 = {
                ...data,
                placeOffer: tempHouse?.placeOffer,
                Price: tempHouse.Price,
                address: tempHouse.address,
                arrImg: tempHouse.arrImg
            };
            console.log("data0", data0);
            const editStatus = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_2__/* .houseApi.editHouse */ .Y.editHouse(data0);
            // setReRenderFilter(reRenderFilter + 1);
            setHouseTemp([
                ...houseTemp.map((item, index)=>{
                    if (item.AddressId === data0.AddressId) {
                        return data0;
                    }
                    return item;
                })
            ]);
            nprogress__WEBPACK_IMPORTED_MODULE_20___default().done();
            setIsEdit(false);
        }
    };
    const handleOnChange = async (value)=>{
        const temp = selectHouse;
        if (temp) {
            setTempHouse({
                ...temp,
                Price: value
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[800px] h-[calc(100vh-3rem)] bg-white m-auto rounded-3xl   overflow-hidden flex flex-col   mobile:mt-0 mobile:rounded-none   mobile:w-screen mobile:h-screen   tablet:h-[calc(100vh-5.625rem)] tablet:mt-[.6rem] ",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                className: "w-full h-full relative ",
                onSubmit: handleSubmit(onSubmit),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.button, {
                        className: "absolute w-[4.5rem] h-[4.5rem] flex desktop:hidden laptop:hidden z-20",
                        onClick: (event)=>{
                            if (setIsEdit) {
                                setIsEdit(false);
                            }
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-fit h-full m-auto",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_15__.GrClose, {
                                className: "text-[2rem]"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full absolute h-[2.4rem]  border-b-2  flex",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-[2rem] m-auto",
                            children: "Edit"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full h-[5rem] absolute bottom-0 left-0 border-t-2 flex items-center flex-2 py-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "flex-1 flex justify-start",
                                onClick: (event)=>{
                                    if (selectHouse) {
                                        setTempHouse({
                                            ...selectHouse,
                                            placeOffer: watch().placeOffer
                                        });
                                    }
                                    reset(selectHouse);
                                    setImgArr([]);
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "m-auto underline cursor-pointer",
                                    children: "Clear all"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex-1 flex justify-center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.button, {
                                    type: "submit",
                                    className: "w-[12.5rem] h-[2.4rem] rounded-lg border-2",
                                    whileHover: {
                                        backgroundColor: "rgba(255, 56, 92, 0.8)",
                                        color: "white"
                                    },
                                    whileTap: {
                                        scale: 0.9
                                    },
                                    children: "Submit"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full h-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-[2.4rem]"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-[calc(100%-7.5rem)]   overflow-scroll overflow-x-hidden box-border p-7   mobile:p-0   ",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit grid text-[2rem] desktop:grid-areas-layoutEditDesktopLaptop   laptop:grid-areas-layoutEditDesktopLaptop   tablet:grid-areas-layoutEditTabletMobile   mobile:grid-areas-layoutEditMobile      desktop:grid-cols-3 laptop:grid-cols-3   tablet:grid-cols-2 mobile:grid-cols-1   ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-locale ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: "",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Address",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_map__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                                    id: infShow === "houseForRent" ? "rent" : "sale",
                                                    value: tempHouse?.address.formattedAddress || "",
                                                    keyMapBing: keyMapBing,
                                                    tempHouse: tempHouse,
                                                    setTempHouse: setTempHouse
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-capacity ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: "",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Capacity",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "number",
                                                    ...register("Capacity"),
                                                    className: "w-full h-[3rem] outline-none text-[2rem]"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-baths ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: "",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Baths",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "number",
                                                    ...register("NumsOfBath"),
                                                    className: "w-full h-[3rem] outline-none text-[2rem]"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-beds ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: "",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Beds",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "number",
                                                    ...register("NumsOfBed"),
                                                    className: "w-full h-[3rem] outline-none text-[2rem]"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-orientation ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: "",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Orientation",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                                    ...register("Orientation"),
                                                    className: "select px-0 w-full outline-none text-[2rem]",
                                                    children: compass.map((item, index)=>{
                                                        if (index == 0) {
                                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                selected: true,
                                                                children: item
                                                            }, index);
                                                        }
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                            children: item
                                                        }, index);
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-price ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: " before:hidden",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Price",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-full h-[3rem] flex mr-0",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((rc_slider__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                            // range
                                                            allowCross: false,
                                                            draggableTrack: true,
                                                            defaultValue: tempHouse?.Price,
                                                            onChange: handleOnChange,
                                                            value: tempHouse?.Price,
                                                            className: "m-auto ",
                                                            min: 10,
                                                            max: tempPrice ? tempPrice * 2 : 5000,
                                                            trackStyle: {
                                                                backgroundColor: "black",
                                                                height: 2
                                                            },
                                                            railStyle: {
                                                                height: 2
                                                            },
                                                            handleStyle: {
                                                                backgroundColor: "#FFFFFF",
                                                                opacity: 1,
                                                                border: "1px solid grey",
                                                                width: 30,
                                                                height: 30,
                                                                marginTop: -13
                                                            }
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "w-[9.375rem] h-full flex ml-5",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                type: "number",
                                                                ...register("Price"),
                                                                className: "w-[7.5rem] h-full m-auto   outline-none ",
                                                                value: tempHouse?.Price,
                                                                onChange: (event)=>{
                                                                    if (!tempHouse) return;
                                                                    const temp = parseFloat(event.target.value);
                                                                    setTempHouse({
                                                                        ...tempHouse,
                                                                        Price: temp
                                                                    });
                                                                }
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-title ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: "",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Title",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "text",
                                                    ...register("Title"),
                                                    className: "w-full h-[3rem] outline-none text-[2rem]"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-des ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: "",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Description",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                    ...register("Description"),
                                                    className: "w-full h-fit  outline-none text-[2rem]"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-placeoffer ${styleInput}`,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: "",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Amenities",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full h-fit mb-5 border-b-2 border-slate-500 py-10",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "w-full h-fit flex flex-col ",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_amenities_editAmenities__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                            setTempHouse: setTempHouse,
                                                            tempHouse: tempHouse
                                                        })
                                                    })
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: `grid-in-img ${styleInput}`,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_inputForm_inputFormEdit__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                styleDivAround: " before:hidden",
                                                styleFieldset: "",
                                                styleLegend: "",
                                                title: "Images",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_removeImg_removeImg__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                                        arrImg: tempHouse ? tempHouse.arrImg : [],
                                                        tempHouse: tempHouse,
                                                        setTempHouse: setTempHouse
                                                    }),
                                                    api_url_path !== undefined && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "mb-4",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_filepond__WEBPACK_IMPORTED_MODULE_13__.FilePond, {
                                                            ref: filePondRef,
                                                            files: imgArr,
                                                            allowMultiple: true,
                                                            instantUpload: false,
                                                            onaddfile: (error, file)=>{
                                                                if (error) return;
                                                                let temp = imgArr;
                                                                temp.push(file);
                                                                setImgArr(temp);
                                                            },
                                                            beforeAddFile: async (file)=>{
                                                                if (imgArr.length > 0) {
                                                                    const isExist = await imgArr.some((items)=>items.filename === file.filename);
                                                                    console.log(isExist);
                                                                    return !isExist;
                                                                }
                                                                return true;
                                                            },
                                                            onprocessfilerevert: async (file)=>{
                                                                try {
                                                                    const temp = await _api_client_axiosClient__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post(`/delete/img`, {
                                                                        nameImg: file.filename
                                                                    });
                                                                    if (temp.status == 200) {
                                                                        console.log(temp.data);
                                                                    }
                                                                } catch (error) {
                                                                    console.log(error);
                                                                    return;
                                                                }
                                                            },
                                                            maxFiles: 30,
                                                            maxParallelUploads: 30,
                                                            // server={`${api_url_path}/api/post/img`}
                                                            server: {
                                                                url: api_url_path + "/api",
                                                                process: {
                                                                    url: "/get/house/modifier",
                                                                    method: "POST",
                                                                    timeout: 120000,
                                                                    withCredentials: true
                                                                }
                                                            },
                                                            name: "files" /* sets the file input name, it's filepond by default */ ,
                                                            labelIdle: 'Drag and drop files <span class="filepond--label-action">Browse</span>',
                                                            acceptedFileTypes: [
                                                                "image/jpeg",
                                                                "image/jpg",
                                                                "image/png",
                                                                "image/gif",
                                                                "image/bmp",
                                                                "image/svg+xml",
                                                                "image/webp",
                                                                "image/tiff",
                                                                "image/x-icon",
                                                                "application/pdf"
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-[5rem]"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2197:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_selectHouse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2586);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const EditRemoveIcon = ({ isEdit , setIsEdit , item , isRemoveReq , setIsRemoveReq  })=>{
    const { selectHouse , setSelectHouse  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_selectHouse__WEBPACK_IMPORTED_MODULE_1__/* .selectHouseContext */ .q);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-0 relative",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    className: "w-[3rem] h-[4rem] top-0 left-0 absolute z-20 flex ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: (event)=>{
                            if (setIsEdit && isEdit != null) {
                                setIsEdit(!isEdit);
                            }
                            setSelectHouse({
                                ...selectHouse,
                                ...item
                            });
                        },
                        className: "w-fit h-fit m-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsListNested, {
                            className: "w-[2.4rem] h-[2.4rem] text-blue-600 "
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    className: "w-[3rem] h-[4rem] top-0 left-[3rem] absolute z-20 flex ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>{
                            setIsRemoveReq(true);
                        },
                        className: "w-fit h-fit m-auto",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_5__.RiDeleteBin5Line, {
                            className: "w-[2.4rem] h-[2.4rem] text-red-500 "
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditRemoveIcon);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_1__);


const EndMessage = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-[1.5rem]",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "m-auto flex",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_1__.MdOutlineNearbyError, {
                    className: "w-[3rem] h-[3rem] text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "m-auto ml-0 text-[2rem]",
                    children: " No results invalid "
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EndMessage);


/***/ }),

/***/ 2931:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _variantsShowHouse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8462);
/* harmony import */ var _carousel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3579);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(924);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_im__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _editRemoveIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _heart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6665);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _contexts_selectHouse__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2586);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _carousel__WEBPACK_IMPORTED_MODULE_3__, _editRemoveIcon__WEBPACK_IMPORTED_MODULE_7__, _heart__WEBPACK_IMPORTED_MODULE_10__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _carousel__WEBPACK_IMPORTED_MODULE_3__, _editRemoveIcon__WEBPACK_IMPORTED_MODULE_7__, _heart__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const HouseCard = ({ index , setIsHover , item , infShow , isHover , isEdit , setIsOpenMaskMap , setSelectLocale , setSelectUser , setIsOpenMask , setIsEdit , isRemoveReq , setIsRemoveReq  })=>{
    const { selectHouse , setSelectHouse  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useContext)(_contexts_selectHouse__WEBPACK_IMPORTED_MODULE_12__/* .selectHouseContext */ .q);
    const selectHouseHandle = (item)=>{
        setSelectHouse({
            ...selectHouse,
            ...item
        });
        console.log(item);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
        initial: {
            opacity: 0,
            display: "none"
        },
        animate: {
            opacity: 1,
            display: "block"
        },
        transition: {
            type: "tween",
            delay: index * 0.1
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            // whileInView={{ x: [-10, 0] }}
            variants: _variantsShowHouse__WEBPACK_IMPORTED_MODULE_2__/* .variants */ .o,
            whileHover: "hoverItem",
            onClick: (event)=>{
                selectHouseHandle(item);
            },
            transition: {
                type: "spring"
            },
            className: "w-full h-[25rem] rounded-2xl box-border bg-[#f28076] text-white",
            onHoverStart: ()=>{
                setIsHover({
                    ishover: true,
                    id: index
                });
            },
            onHoverEnd: ()=>{
                setIsHover({
                    ishover: false,
                    id: -1
                });
            },
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full h-[18.75rem] relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_carousel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            arrImg: item.arrImg,
                            houseId: item.HouseId
                        }),
                        infShow !== "authListHouse" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_heart__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            HouseId: item.HouseId,
                            IsFavorite: item.IsFavorite,
                            PostBy: item.PostBy
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute left-2 top-2 z-10",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                className: "fill-white",
                                width: 50,
                                height: 50,
                                src: "/x2click.svg",
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                            whileHover: {
                                scale: 1.2
                            },
                            onClick: ()=>{
                                setIsOpenMaskMap(true);
                                setSelectLocale({
                                    latitude: item.address.latitude,
                                    longitude: item.address.longitude,
                                    zoom: 18,
                                    formattedAddress: item.address.formattedAddress
                                });
                            },
                            className: `absolute top-2 right-12 ${infShow === "authListHouse" ? "right-2" : ""} text-red-500 text-[2rem] z-10`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_im__WEBPACK_IMPORTED_MODULE_5__.ImMap, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                            onClick: ()=>{
                                setSelectUser(item.useracc);
                                setIsOpenMask(true);
                                console.log("user click");
                            },
                            className: `absolute w-[4rem] h-[4rem] transition-all
                left-3 bottom-3 z-[15] rounded-full overflow-hidden shadow-2xl ${infShow === "authListHouse" ? "hidden" : ""}`,
                            children: item.useracc.Image != undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/api/img/path/" + item.useracc.Image,
                                alt: "",
                                className: "w-full h-full object-cover"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiUserCircle, {
                                className: "w-full h-full"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                            variants: _variantsShowHouse__WEBPACK_IMPORTED_MODULE_2__/* .variants */ .o,
                            animate: isHover.ishover && isHover.id === index ? "showIconControl" : "hiddenIconControl",
                            transition: {
                                type: "spring",
                                duration: 0.3
                            },
                            className: `absolute w-[4rem] h-[4rem] transition-all bg-white
                left-3 bottom-3 z-10 rounded-full overflow-hidden shadow-2xl flex
                tablet:hidden mobile:hidden
                ${infShow === "authListHouse" || infShow === "houseForRent" || infShow === "houseForSale" ? "" : "hidden"}`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-[4rem] h-full rounded-full overflow-hidden",
                                    children: item.useracc.Image != undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/api/img/path/" + item.useracc.Image,
                                        alt: "",
                                        className: "w-full h-full object-cover"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiUserCircle, {
                                        className: "w-full h-full"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_editRemoveIcon__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    isEdit: isEdit,
                                    setIsEdit: setIsEdit,
                                    item: item,
                                    isRemoveReq: isRemoveReq,
                                    setIsRemoveReq: setIsRemoveReq
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                            variants: _variantsShowHouse__WEBPACK_IMPORTED_MODULE_2__/* .variants */ .o,
                            transition: {
                                type: "spring",
                                duration: 0.3
                            },
                            className: `absolute w-[160px] h-[4rem] transition-all bg-white
                left-3 bottom-3  rounded-full overflow-hidden shadow-2xl flex
                laptop:hidden desktop:hidden z-20
                ${infShow === "authListHouse" ? "" : "hidden"}`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-[4rem] h-full rounded-full overflow-hidden",
                                    children: item.useracc.Image != undefined ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/api/img/path/" + item.useracc.Image,
                                        alt: "",
                                        className: "w-full h-full object-cover"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_6__.HiUserCircle, {
                                        className: "w-full h-full"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_editRemoveIcon__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    isEdit: isEdit,
                                    setIsEdit: setIsEdit,
                                    item: item,
                                    isRemoveReq: isRemoveReq,
                                    setIsRemoveReq: setIsRemoveReq
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: `/house/${item.HouseId}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-[6.25rem] w-full box-border p-4 ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full grid grid-cols-2 grid-rows-3",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "whitespace-nowrap max-w-[100%] text-ellipsis overflow-hidden",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "font-semibold ",
                                        children: [
                                            item.address.title,
                                            ", ",
                                            item.address.countryRegion
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-end font-semibold text-red-500",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                "$",
                                                item.Price
                                            ]
                                        }),
                                        infShow === "houseForRent" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-semibold",
                                            children: "/month"
                                        }) : ""
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Host: " + item.useracc.UserName
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex justify-end",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            item.NumsOfBath + " Baths,",
                                            " ",
                                            item.NumsOfBed + " Beds"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            item.Capacity + " m",
                                            "\xb2"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-end",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                item.Orientation,
                                                " "
                                            ]
                                        }),
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_11__.FaRegCompass, {
                                            className: "h-full ml-2 text-[1rem]"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }, index);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HouseCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const MapEdit = ({ setTempHouse , tempHouse , keyMapBing , value , id  })=>{
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__.whenLoaded.then(()=>{
            const map_ = document.getElementById("MapEditForm" + id);
            if (map_) {
                const map = new Microsoft.Maps.Map(map_, {
                    /* No need to set credentials if already passed in URL */ center: new Microsoft.Maps.Location(tempHouse?.address.latitude || 16.047079, tempHouse?.address.longitude || 108.206230),
                    mapTypeId: Microsoft.Maps.MapTypeId.road,
                    zoom: 16,
                    credentials: keyMapBing,
                    disableScrollWheelZoom: true
                });
                var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), undefined);
                var layer = new Microsoft.Maps.Layer();
                layer.add(pushpin);
                map.layers.insert(layer);
                Microsoft.Maps.loadModule("Microsoft.Maps.AutoSuggest", {
                    callback: ()=>{
                        var options = {
                            maxResults: 5,
                            businessSuggestions: true
                        };
                        var manager = new Microsoft.Maps.AutosuggestManager(options);
                        manager.attachAutosuggest("#searchMapEdit" + id, "#searchMapEditContainer" + id, (suggestionResult)=>{
                            map.entities.clear();
                            map.setView({
                                bounds: suggestionResult.bestView
                            });
                            var pushpin = new Microsoft.Maps.Pushpin(suggestionResult.location);
                            map.entities.push(pushpin);
                            console.log(suggestionResult);
                            if (tempHouse) {
                                setTempHouse({
                                    ...tempHouse,
                                    address: {
                                        ...tempHouse.address,
                                        ...suggestionResult?.address,
                                        ...suggestionResult?.location,
                                        title: suggestionResult.title
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });
    }, [
        tempHouse?.address.formattedAddress
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-full rounded-3xl border-2 border-red-400 overflow-hidden h-[22rem]`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    id: "MapEditForm" + id,
                    className: "relative z-10 w-full h-full"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "searchMapEditContainer" + id,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    placeholder: value,
                    id: "searchMapEdit" + id,
                    type: "text",
                    className: "w-full h-[3rem] outline-none text-[2rem]"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapEdit);


/***/ }),

/***/ 3381:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(860);
/* harmony import */ var _contexts_houseTemp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1790);
/* harmony import */ var _contexts_selectHouse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2586);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6197);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_5__]);
([_api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const RemoveReq = ({ isRemoveReq , setIsRemoveReq  })=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_4__/* .userAccContext */ .G);
    const { houseTemp , setHouseTemp  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_houseTemp__WEBPACK_IMPORTED_MODULE_2__/* .houseTempContext */ .W);
    const { selectHouse , setSelectHouse  } = (0,react__WEBPACK_IMPORTED_MODULE_7__.useContext)(_contexts_selectHouse__WEBPACK_IMPORTED_MODULE_3__/* .selectHouseContext */ .q);
    const [inputPass, setInputPass] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const [isTruePass, setIsTruePass] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(true);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_6__.useSession)();
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{}, [
        isTruePass
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-fit h-fit bg-white mobile:w-screen mobile:h-screen   flex flex-col mobile:p-0 p-5 rounded-xl ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full m-auto flex",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "m-auto flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-[9.375rem] h-fit",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: `/api/img/path/${user.Image}`,
                                alt: "",
                                className: "rounded-full"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-fit h-full grid grid-cols-1 grid-rows-2 ml-[2rem] m-auto gap-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "font-semibold text-[3rem] mobile:text-[2rem]",
                                    children: "Delete house"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "password",
                                        className: `outline-none
            border-b-2 border-slate-900
            ${isTruePass ? "" : "border-red-600"} mobile:text-[19px] text-[2rem] `,
                                        placeholder: "Password",
                                        onChange: (event)=>setInputPass(event.target.value)
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[6.25rem]  grid grid-cols-2 grid-rows-1 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full box-border p-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.button, {
                            onClick: (event)=>{
                                setIsRemoveReq(false);
                            },
                            className: "w-full h-full rounded-xl border-2 font-semibold",
                            children: "Cancel"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full box-border p-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_5__.motion.button, {
                            type: "button",
                            onClick: async (event)=>{
                                if (inputPass !== session?.userAcc.Password) {
                                    setIsTruePass(false);
                                } else {
                                    setIsTruePass(true);
                                    setHouseTemp(houseTemp.filter((item)=>item.AddressId !== selectHouse?.AddressId));
                                    if (selectHouse) {
                                        setIsRemoveReq(false);
                                        await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi.DeleteHouse */ .Y.DeleteHouse(selectHouse?.HouseId, selectHouse.AddressId);
                                    }
                                }
                            },
                            className: "w-full h-full rounded-xl border-2 bg-red bg-[#f05123]   text-white font-semibold   ",
                            children: "Delete"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RemoveReq);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1013:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_houseDetail_showAllHousePt_maskPt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6487);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_houseDetail_showAllHousePt_maskPt__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
([_components_houseDetail_showAllHousePt_maskPt__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const RemoveImg = ({ arrImg , tempHouse , setTempHouse  })=>{
    const [select, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const [isFirstLoading, setIsFirstLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
        // variants={variants}
        // transition={{ duration: 0.6 }}
        // onClickCapture={(event) => {
        //   document.body.style.overflow = 'hidden';
        // }}
        className: "w-full h-fit",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "h-full w-full relative flex",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-full ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full columns-2 h-fit gap-2  m-auto  mt-16 mb-14 overflow-hidden ",
                        children: arrImg.map((item, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                whileHover: {
                                    opacity: 0.6
                                },
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/api/img/path/" + item.Path,
                                        alt: "",
                                        onClick: ()=>setSelect(item.Path),
                                        className: "w-full   shadow-xl image-full cursor-pointer mb-2 rounded-lg   "
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        onClick: ()=>{
                                            if (tempHouse) {
                                                if (tempHouse.arrImg.length == 5) return;
                                                setTempHouse({
                                                    ...tempHouse,
                                                    arrImg: [
                                                        ...tempHouse?.arrImg.filter((item_)=>item.Path !== item_.Path)
                                                    ]
                                                });
                                            }
                                        },
                                        className: "absolute w-fit h-fit top-2 right-2 bg-white rounded-md z-30",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_4__.RiDeleteBin5Line, {
                                            className: "w-[2.4rem] h-[2.4rem] text-red-500 "
                                        })
                                    })
                                ]
                            }, index);
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_showAllHousePt_maskPt__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    Path: select,
                    setPath: setSelect
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RemoveImg);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6665:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(860);
/* harmony import */ var _contexts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7607);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
([_api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Heart = ({ HouseId , IsFavorite , PostBy  })=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_3__/* .userAccContext */ .G);
    const [isClickHeart, setIsClickHeart] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { setIsLoginClick  } = (0,react__WEBPACK_IMPORTED_MODULE_5__.useContext)(_contexts__WEBPACK_IMPORTED_MODULE_2__/* .selectPopoverContext */ .K);
    const handleOnClickFavorite = async (event, HouseId)=>{
        const addHouseFavorite = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi.authFavoriteHouse */ .Y.authFavoriteHouse(HouseId, user.UserId);
        if (addHouseFavorite.status != 200) {
            return;
        } else {
            return;
        }
    };
    // bo khoai danh sahc yeu thich
    const handleOnClickUnFavorite = async (event, HouseId)=>{
        const removeHouseFavorite = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi.authUnFavoriteHouse */ .Y.authUnFavoriteHouse(HouseId, user.UserId);
        if (removeHouseFavorite.status != 200) {
            return;
        } else {
            return;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.label, {
        whileHover: {
            scale: 1.2
        },
        className: `swap swap-flip text-[2rem] z-10 absolute right-2 top-2
                  text-red-500 `,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                type: "checkbox",
                onClick: async (event)=>{
                    if (user.UserId === "none user") {
                        event.preventDefault();
                        setIsLoginClick(true);
                        return;
                    }
                    if (event.currentTarget?.checked && IsFavorite == false) {
                        await handleOnClickFavorite(event, HouseId);
                    } else if (!event.currentTarget?.checked && IsFavorite == false) {
                        await handleOnClickUnFavorite(event, HouseId);
                    }
                    if (event.currentTarget?.checked && IsFavorite == true) {
                        await handleOnClickUnFavorite(event, HouseId);
                    } else if (!event.currentTarget?.checked && IsFavorite == true) {
                        await handleOnClickFavorite(event, HouseId);
                    }
                }
            }),
            IsFavorite ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        whileTap: {
                            scale: [
                                0.8,
                                1.3
                            ]
                        },
                        className: "swap-off",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiFillHeart, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        whileTap: {
                            scale: [
                                0.8,
                                1.3
                            ]
                        },
                        className: "swap-on",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineHeart, {})
                    })
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        whileTap: {
                            scale: [
                                0.8,
                                1.3
                            ]
                        },
                        className: "swap-on",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiFillHeart, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                        whileTap: {
                            scale: [
                                0.8,
                                1.3
                            ]
                        },
                        className: "swap-off",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_6__.AiOutlineHeart, {})
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Heart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



(0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__.initializeSSR)();
const MapEach = ({ latitude , longitude , zoom , keyMapBing , formattedAddress , idMap , style  })=>{
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__.initializeSSR)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_1__.whenLoaded.then(()=>{
            const map_ = document.getElementById("MapEach" + idMap);
            if (map_) {
                var map = new Microsoft.Maps.Map(map_, {
                    /* No need to set credentials if already passed in URL */ center: new Microsoft.Maps.Location(latitude, longitude),
                    mapTypeId: Microsoft.Maps.MapTypeId.road,
                    zoom: zoom,
                    credentials: keyMapBing
                });
                var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), undefined);
                var layer = new Microsoft.Maps.Layer();
                layer.add(pushpin);
                map.layers.insert(layer);
            }
        });
    }, [
        latitude,
        longitude,
        zoom
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text-[2rem]",
                children: formattedAddress
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-full rounded-3xl  border-2 border-red-400 overflow-hidden ${style}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    id: "MapEach" + idMap,
                    className: "relative z-10"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapEach);


/***/ }),

/***/ 6813:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(860);
/* harmony import */ var _components_houseDetail_host_hostUser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1600);
/* harmony import */ var _components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8772);
/* harmony import */ var _contexts_amountTabHosting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(432);
/* harmony import */ var _contexts_filter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3565);
/* harmony import */ var _contexts_getHouse__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6648);
/* harmony import */ var _contexts_houseTemp__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1790);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9445);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6197);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(808);
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4336);
/* harmony import */ var react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _animateTitle__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1964);
/* harmony import */ var _componentShowHouse_editForm__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(754);
/* harmony import */ var _componentShowHouse_endMessage__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9609);
/* harmony import */ var _componentShowHouse_houseCard__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2931);
/* harmony import */ var _componentShowHouse_inputForm_removeReq__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3381);
/* harmony import */ var _mapEach__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(8903);
/* harmony import */ var _variantsShowHouse__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(8462);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__, _components_houseDetail_host_hostUser__WEBPACK_IMPORTED_MODULE_2__, _components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_10__, _animateTitle__WEBPACK_IMPORTED_MODULE_16__, _componentShowHouse_editForm__WEBPACK_IMPORTED_MODULE_17__, _componentShowHouse_houseCard__WEBPACK_IMPORTED_MODULE_19__, _componentShowHouse_inputForm_removeReq__WEBPACK_IMPORTED_MODULE_20__]);
([_api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__, _components_houseDetail_host_hostUser__WEBPACK_IMPORTED_MODULE_2__, _components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_3__, framer_motion__WEBPACK_IMPORTED_MODULE_10__, _animateTitle__WEBPACK_IMPORTED_MODULE_16__, _componentShowHouse_editForm__WEBPACK_IMPORTED_MODULE_17__, _componentShowHouse_houseCard__WEBPACK_IMPORTED_MODULE_19__, _componentShowHouse_inputForm_removeReq__WEBPACK_IMPORTED_MODULE_20__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);























const ShowHouse = ({ infShow , keyMapBing , api_url_path  })=>{
    const arrTempLoading = Array.from({
        length: 10
    }, (_, index)=>index);
    const { filterForm , emptyFilterForm  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_filter__WEBPACK_IMPORTED_MODULE_5__/* .filterContext */ .u);
    const { address  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_8__/* .selectPlaceContext */ .t);
    const { setCurrentHosting  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_amountTabHosting__WEBPACK_IMPORTED_MODULE_4__/* .AmountTabHostingContext */ .b);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_11__.useSession)();
    const { user , setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_9__/* .userAccContext */ .G);
    const { isFilter , setIsFilter , reRenderFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_getHouse__WEBPACK_IMPORTED_MODULE_6__/* .getHouseContext */ .S);
    // const [houseTemp, setHouseTemp] = useState<house_[]>([]);
    const { houseTemp , setHouseTemp  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_houseTemp__WEBPACK_IMPORTED_MODULE_7__/* .houseTempContext */ .W);
    const maskUser = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)(null);
    const maskMap = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)(null);
    const editPanel = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)(null);
    const removeReqPanel = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)(null);
    const [isOpenMask, setIsOpenMask] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    const [hasMore, setHasMore] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(true);
    const [isEdit, setIsEdit] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    const [selectUser, setSelectUser] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)();
    const [isRemoveReq, setIsRemoveReq] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    const [isHover, setIsHover] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)({
        ishover: false,
        id: -1
    });
    const [selectLocale, setSelectLocale] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)();
    const [isOpenMaskMap, setIsOpenMaskMap] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    // thuc hien hanh dong khi kiem tra xem arr co ton tai hay khong
    const isEmpty = (arr)=>{
        console.log("isEmpty", arr.data);
        if (arr?.data?.length == 0) {
            setHasMore(false); // neu nhu du lieu tra ve la khong co lan dau tien thi khong xuat hien nx
            nprogress__WEBPACK_IMPORTED_MODULE_12___default().done();
            return;
        } else if (arr?.data?.length < 10) {
            setHouseTemp(arr.data);
            setHasMore(false); // neu nhu du lieu tra ve la khong co lan dau tien thi khong xuat hien nx
            nprogress__WEBPACK_IMPORTED_MODULE_12___default().done();
            return;
        }
        setHouseTemp(arr.data);
        nprogress__WEBPACK_IMPORTED_MODULE_12___default().done();
    };
    const fetchHouseApi = async ()=>{
        if (houseTemp.length != 0 || status === "loading") return;
        const temp = await session?.userAcc;
        // neu user login thi userid se thay doi nen phai chia ra nhieu truong hop
        nprogress__WEBPACK_IMPORTED_MODULE_12___default().set(0.6);
        if (infShow === "noneAuthHouseApi" && status === "authenticated") {
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi.noneAuthHouseApi */ .Y.noneAuthHouseApi(1, temp.UserId);
            return isEmpty(arr);
        } else if (infShow === "noneAuthHouseApi" && status === "unauthenticated") {
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi */ .Y[infShow](1, "");
            return isEmpty(arr);
        } else if (infShow === "noneAuthFilter" && status === "unauthenticated") {
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi */ .Y[infShow]({
                filter: filterForm,
                selectPlace: address
            }, 0, "");
            return isEmpty(arr);
        } else if (infShow === "noneAuthFilter" && status === "authenticated") {
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi */ .Y[infShow]({
                filter: filterForm,
                selectPlace: address
            }, 0, temp.UserId);
            return isEmpty(arr);
        } else if (infShow === "authListHouse" && status === "authenticated") {
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi */ .Y[infShow](temp.UserId);
            return isEmpty(arr);
        } else if (infShow === "favoriteHouse" && status === "authenticated") {
            const arr = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi.authFavoriteList */ .Y.authFavoriteList(temp.UserId, 0);
            return isEmpty(arr);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_13__.useEffect)(()=>{
        setHouseTemp([]);
        setHasMore(true);
    }, [
        infShow,
        isFilter,
        status,
        reRenderFilter
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_13__.useEffect)(()=>{
        fetchHouseApi();
    }, [
        houseTemp
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_13__.useEffect)(()=>{}, [
        houseTemp
    ]);
    const isExist = (moreHouse)=>{
        if (Array.isArray(moreHouse.data) && moreHouse.data.length != 0 && moreHouse.data.length >= 10) {
            setHouseTemp([
                ...houseTemp,
                ...moreHouse.data
            ]);
            console.log("fetchmore", moreHouse.data);
        } else if (Array.isArray(moreHouse.data) && moreHouse.data.length != 0 && moreHouse.data.length < 10) {
            console.log("last fetch", moreHouse.data);
            setHouseTemp([
                ...houseTemp,
                ...moreHouse.data
            ]);
            setHasMore(false); // cai nay de kiem tra xem da fetch het du lieu hay chua
        } else {
            setHasMore(false); // cai nay de kiem tra xem da fetch het du lieu hay chua
        }
    };
    const getMoreHouse = async ()=>{
        if (infShow === "favoriteHouse" || infShow == "authListHouse" || infShow === "houseForRent" || infShow === "houseForSale") {
            console.log("return ");
            setHasMore(false);
            return;
        }
        try {
            // get more house de lay them nha khi scroll xuoong cuoi cung https://www.npmjs.com/package/react-infinite-scroll-component
            // noi get more them du lieu khi dung infinite
            if (infShow === "noneAuthHouseApi") {
                const moreHouse = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi */ .Y[infShow](houseTemp.length, user.UserId);
                isExist(moreHouse);
            } else if (infShow === "noneAuthFilter") {
                console.log("fetch more");
                const moreHouse = await _api_client_houseApi__WEBPACK_IMPORTED_MODULE_1__/* .houseApi */ .Y[infShow]({
                    filter: filterForm,
                    selectPlace: address
                }, houseTemp.length, user.UserId);
                isExist(moreHouse);
            }
        } catch (error) {
            console.log(error);
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_13__.useEffect)(()=>{
        setCurrentHosting(houseTemp.length);
    }, [
        houseTemp,
        hasMore
    ]);
    const handleOnClickOutSideMaskUser = (event)=>{
        const isClickInSide = maskUser.current?.contains(event.target);
        if (!isClickInSide) {
            setIsOpenMask(false);
            return;
        } else {
            return;
        }
    };
    const handleOnClickOutSideMaskMap = (event)=>{
        const isClickInSide = maskMap.current?.contains(event.target);
        if (!isClickInSide) {
            setIsOpenMaskMap(false);
            return;
        } else {
            return;
        }
    };
    const handleOnClickOutSideEditPanel = (event)=>{
        const isClickInSide = editPanel.current?.contains(event.target);
        if (!isClickInSide) {
            setIsEdit(false);
            return;
        } else {
            return;
        }
    };
    const handleOnClickOutSideRemoveReqPanel = (event)=>{
        const isClickInSide = removeReqPanel.current?.contains(event.target);
        if (!isClickInSide) {
            setIsRemoveReq(false);
            return;
        } else {
            return;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                    variants: _variantsShowHouse__WEBPACK_IMPORTED_MODULE_22__/* .variants */ .o,
                    animate: isRemoveReq ? "showMask" : "hiddenMask",
                    onClick: handleOnClickOutSideRemoveReqPanel,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit h-fit m-auto",
                        ref: removeReqPanel,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentShowHouse_inputForm_removeReq__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                            setIsRemoveReq: setIsRemoveReq,
                            isRemoveReq: isRemoveReq
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                    variants: _variantsShowHouse__WEBPACK_IMPORTED_MODULE_22__/* .variants */ .o,
                    animate: isEdit ? "showMask" : "hiddenMask",
                    onClick: handleOnClickOutSideEditPanel,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0 flex",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit h-fit m-auto",
                        ref: editPanel,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentShowHouse_editForm__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                            infShow: infShow,
                            keyMapBing: keyMapBing,
                            api_url_path: api_url_path,
                            setIsEdit: setIsEdit
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                    variants: _variantsShowHouse__WEBPACK_IMPORTED_MODULE_22__/* .variants */ .o,
                    animate: isOpenMask ? "showMask" : "hiddenMask",
                    onClick: handleOnClickOutSideMaskUser,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0 ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                        className: "w-fit h-fit bg-[#f0efe9] p-7 m-auto mt-[10%] rounded-2xl",
                        ref: maskUser,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_host_hostUser__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            phone: selectUser?.Phone || "xxxx-xxxx",
                            description: "",
                            imgPath: selectUser?.Image,
                            gmail: selectUser?.Gmail,
                            userName: selectUser?.UserName
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                    variants: _variantsShowHouse__WEBPACK_IMPORTED_MODULE_22__/* .variants */ .o,
                    animate: isOpenMaskMap ? "showMaskMap" : "hiddenMaskMap",
                    onClick: handleOnClickOutSideMaskMap,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0 flex ",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        ref: maskMap,
                        className: "w-[50%] h-fit bg-[#f0efe9] p-7 m-auto rounded-2xl   mobile:w-full mobile:h-full   tablet:w-full tablet:h-full   relative   ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.button, {
                                className: "absolute w-[4.5rem] h-[4.5rem] flex desktop:hidden laptop:hidden z-20   top-0 left-0   ",
                                onClick: (event)=>{
                                    setIsOpenMaskMap(false);
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-fit h-full m-auto",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_14__.GrClose, {
                                        className: "text-[2rem]"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mapEach__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                longitude: selectLocale?.longitude ? selectLocale.longitude : 1,
                                latitude: selectLocale?.latitude ? selectLocale?.latitude : 1,
                                zoom: selectLocale?.zoom ? selectLocale.zoom : 15,
                                formattedAddress: selectLocale?.formattedAddress ? selectLocale.formattedAddress : "",
                                keyMapBing: keyMapBing,
                                style: "h-[32rem] mobile:h-[calc(100%-3rem)] tablet:h-[calc(100%-3rem)]",
                                idMap: "4"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                className: "w-full h-fit py-4 pb-28",
                id: "scroll-inf",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_animateTitle__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                        title: infShow === "authListHouse" ? "" : isFilter === "houseForSale" ? "House for sale " : isFilter === "houseForRent" ? "House for rent" : isFilter === "favoriteHouse" ? "Whislist" : "",
                        textStyles: " w-full h-fit "
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react_infinite_scroll_component__WEBPACK_IMPORTED_MODULE_15___default()), {
                        dataLength: houseTemp?.length || 0,
                        next: getMoreHouse,
                        hasMore: hasMore,
                        loader: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                            transition: {
                                delay: 0.3
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                        }),
                        style: {
                            overflow: "hidden"
                        },
                        className: "w-full h-fit grid grid-cols-houseBox gap-x-9 gap-y-8 px-7 py-8   mobile:px-0 mobile:py-0   ",
                        endMessage: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentShowHouse_endMessage__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
                        children: [
                            houseTemp.map((item, index)=>{
                                // if (infShow === 'houseForRent') {
                                //   if (item.Type === 'House for sale') {
                                //     return;
                                //   }
                                // } else if (infShow === 'houseForSale') {
                                //   if (item.Type === 'House for rent') {
                                //     return
                                //   }
                                // }
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_componentShowHouse_houseCard__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                    keyMapBing: keyMapBing,
                                    index: index,
                                    isHover: isHover,
                                    infShow: infShow,
                                    item: item,
                                    isEdit: isEdit,
                                    setIsHover: setIsHover,
                                    setIsOpenMask: setIsOpenMask,
                                    setIsOpenMaskMap: setIsOpenMaskMap,
                                    setSelectLocale: setSelectLocale,
                                    setSelectUser: setSelectUser,
                                    setIsEdit: setIsEdit,
                                    isRemoveReq: isRemoveReq,
                                    setIsRemoveReq: setIsRemoveReq
                                }, index);
                            }),
                            houseTemp.length == 0 && hasMore == true && arrTempLoading.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                                    variants: _variantsShowHouse__WEBPACK_IMPORTED_MODULE_22__/* .variants */ .o,
                                    animate: houseTemp.length == 0 ? "show" : "hidden",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_skeletonLoading_skletonShowHouse__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                                }, index))
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShowHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8772:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_loading_skeleton__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_loading_skeleton__WEBPACK_IMPORTED_MODULE_1__]);
react_loading_skeleton__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const SkeletonShowHouse = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_1__.SkeletonTheme, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    width: "100%",
                    height: 300
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_loading_skeleton__WEBPACK_IMPORTED_MODULE_1__["default"], {
                    count: 3,
                    width: "100%",
                    height: 30
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SkeletonShowHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 432:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "b": () => (/* binding */ AmountTabHostingContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const AmountTabHostingDataDefault = {
    currentHosting: 0,
    setCurrentHosting: ()=>{}
};
const AmountTabHostingContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(AmountTabHostingDataDefault);
const AmountTabHostingProviders = ({ children  })=>{
    const [currentHosting, setCurrentHosting_] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(AmountTabHostingDataDefault.currentHosting);
    const setCurrentHosting = (payload)=>setCurrentHosting_(payload);
    const AmountCurrentHostingDynamicData = {
        currentHosting,
        setCurrentHosting
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AmountTabHostingContext.Provider, {
        value: AmountCurrentHostingDynamicData,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AmountTabHostingProviders);


/***/ })

};
;