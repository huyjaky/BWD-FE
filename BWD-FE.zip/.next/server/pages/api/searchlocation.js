"use strict";
(() => {
var exports = {};
exports.id = 369;
exports.ids = [369];
exports.modules = {

/***/ 9884:
/***/ ((module) => {

module.exports = require("http-proxy");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 1756:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var http_proxy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9884);
/* harmony import */ var http_proxy__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(http_proxy__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const proxy = http_proxy__WEBPACK_IMPORTED_MODULE_1___default().createProxyServer();
const replaceString = (payload)=>{
    if (payload == null) return;
    let place = "";
    for(let index = 0; index < payload.length; index++){
        if (payload.charAt(index) === " ") {
            place += "%20";
            continue;
        }
        place += payload.charAt(index);
    }
    return place;
};
function handler(req, res) {
    if (req.method !== "POST") {
        return res.status(404).json({
            message: "method not supported"
        });
    }
    const adminDistrict_ = req.body.adminDistrict;
    const locality_ = req.body.locality;
    const addressLine_ = req.body.addressLine;
    const countryRegionIso2_ = req.body.countryRegionIso2;
    if (!adminDistrict_ && !locality_ && !addressLine_ && !countryRegionIso2_) {
        return res.status(400).json({
            message: "address not valid"
        });
    }
    const adminDistrict = replaceString(adminDistrict_) || "-";
    const locality = replaceString(locality_) || "-";
    const addressLine = replaceString(addressLine_) || "-";
    const countryRegionIso2 = replaceString(countryRegionIso2_) || "-";
    const token = process.env.ACCESS_TOKEN_BINGMAP;
    const urlBingMap = `http://dev.virtualearth.net/REST/v1/Locations/${countryRegionIso2}/${adminDistrict}/${locality}/${addressLine}?key=${token}`;
    return new Promise(()=>{
        try {
            const handleRequest = async (proxyReq, req, res, options)=>{
                try {
                    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].get(urlBingMap);
                    if (response.status === 200) {
                        res.write(JSON.stringify(response.data));
                        res.end();
                        return;
                    }
                } catch (error) {
                    return res.status(500).json({
                        message: "Internal server error" + error
                    });
                }
            };
            proxy.on("proxyReq", handleRequest);
            proxy.web(req, res, {
                target: "http://dev.virtualearth.net",
                changeOrigin: true,
                selfHandleResponse: true
            });
        } catch (error) {
            console.log(error);
        }
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1756));
module.exports = __webpack_exports__;

})();