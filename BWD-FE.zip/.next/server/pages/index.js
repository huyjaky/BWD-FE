(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 2135:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Montserrat_097b2d', '__Montserrat_Fallback_097b2d'","fontStyle":"normal"},
	"className": "__className_097b2d",
	"variable": "__variable_097b2d"
};


/***/ }),

/***/ 6992:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ TitleText),
/* harmony export */   "g": () => (/* binding */ TypingText)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";



const TypingText = ({ title , textStyles  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.p, {
        variants: _utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .textContainer */ .AR,
        className: `font-normal text-[1.5rem] text-slate-600 ${textStyles}`,
        children: Array.from(title).map((letter, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.span, {
                variants: _utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .textVariant2 */ .lM,
                children: letter === " " ? "\xa0" : letter
            }, index))
    });
const TitleText = ({ title , textStyles  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.h2, {
        variants: _utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .textVariant2 */ .lM,
        initial: "hidden",
        whileInView: "show",
        className: `mt-[.5rem] font-bold md:text-[4rem] text-[3rem] text-black ${textStyles}`,
        children: title
    });

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 456:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";




const ExploreCard = ({ id , imgUrl , title , index , active , handleClick  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("right", "tween", index * 0.3, 0.75),
        className: `relative ${active === id ? "lg:flex-[3.5] flex-[10]" : "lg:flex-[0.5] flex-[2]"} flex items-center justify-center min-w-[11rem] h-[44rem]  duration-[0.7s] ease-out-flex cursor-pointer
      transition-[flex] `,
        onClick: ()=>handleClick(id),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: imgUrl,
                alt: "planet-04",
                className: "absolute w-full h-full object-cover rounded-[1.5rem]"
            }),
            active !== id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: "font-semibold sm:text-[2rem] text-[1rem] text-white absolute z-0 lg:bottom-20 lg:rotate-[-90deg] lg:origin-[0,0]",
                children: title
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "absolute bottom-0 p-8 flex justify-start w-full flex-col bg-[rgba(0,0,0,0.5)] rounded-b-[2rem] transition-all   ease-linear   ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].flexCenter */ .Z.flexCenter} w-[4rem] h-[4rem] rounded-[2rem] glassmorphism mb-[1rem]
          transition-all ease-in-out
          `,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/about/headset.svg",
                            alt: "headset",
                            className: "w-1/2 h-1/2 object-contain"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-normal text-[1rem] leading-[1rem] text-white uppercase",
                        children: "Explorer house"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "mt-[2rem] font-semibold sm:text-[2rem] text-[2rem] text-white",
                        children: title
                    })
                ]
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExploreCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8385:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1074);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9765);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";







const Footer = ()=>{
    const [isTapJoin, setIsTapJoin] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.footer, {
            variants: _utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .footerVariants */ .FT,
            initial: "hidden",
            whileInView: "show",
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].xPaddings */ .Z.xPaddings} py-8 relative`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "footer-gradient"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col gap-8`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center justify-between flex-wrap gap-5 roud ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "font-bold md:text-[4rem] text-[3rem] text-black",
                                    children: "JOIN WITH US"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    href: "/homepage",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.button, {
                                        onClick: (event)=>setIsTapJoin(true),
                                        whileTap: {
                                            scale: 0.8
                                        },
                                        type: "button",
                                        className: "flex items-center h-fit py-4 px-6 bg-white border-2 rounded-[2rem] gap-[1rem]   border-slate-600 relative   ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-[1rem] text-black font-semibold",
                                                children: "JOIN"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
                                                initial: {
                                                    visibility: "hidden"
                                                },
                                                animate: isTapJoin ? {
                                                    visibility: "visible",
                                                    scale: 100
                                                } : {},
                                                transition: {
                                                    duration: 2,
                                                    type: "tween"
                                                },
                                                className: "absolute w-[4rem] h-[4rem] bg-white z-50 right-0 rounded-full pointer-events-none"
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mb-[3rem] h-[.2rem] bg-white opacity-10"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center justify-between flex-wrap gap-4",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                            className: "font-extrabold text-[2rem] text-black",
                                            children: "Olympus"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "font-normal text-[1rem] text-black opacity-50",
                                            children: "Copyright \xa9 2022 - 2023 Olympus. All rights reserved."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex gap-4",
                                            children: _constants__WEBPACK_IMPORTED_MODULE_1__/* .socials.map */ .UY.map((social)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: social.url,
                                                    alt: social.name,
                                                    className: "w-[2rem] h-[2rem] object-contain cursor-pointer fill-slate-900"
                                                }, social.name))
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3769:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9765);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";




const InsightCard = ({ imgUrl , title , subtitle , index  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_2__/* .fadeIn */ .Ji)("up", "spring", index * 0.5, 1),
        className: "flex md:flex-row flex-col gap-4",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: imgUrl,
                alt: "planet-01",
                className: "md:w-[24.5rem] w-full h-[16rem] rounded-[2rem] object-cover"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 md:ml-[4rem] flex flex-col max-w-[40.625rem]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                className: "font-normal lg:text-[3rem] text-[2rem] text-black",
                                children: title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mt-[1rem] font-normal lg:text-[1rem] text-[1rem] text-slate-700",
                                children: subtitle
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                        whileHover: {
                            scale: 1.2
                        },
                        className: "lg:flex hidden items-center justify-center w-[6.25rem] h-[6.25rem] rounded-full bg-transparent",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__.BsArrowUpRightCircle, {
                            className: "w-full h-full object-contain text-slate-500"
                        })
                    })
                ]
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InsightCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3349:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9765);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";







const variants = {
    show: {
        height: 100
    },
    hidden: {
        height: 0,
        paddingTop: 0,
        paddingBottom: 0
    }
};
const Navbar = ()=>{
    const [isOpen, setIsOpen] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        document.addEventListener("mousedown", (event)=>{
            setIsOpen(false);
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.nav, {
        variants: _utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .navVariants */ .yB,
        initial: "hidden",
        whileInView: "show",
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].xPaddings */ .Z.xPaddings} py-8 relative`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute w-[50%] inset-0 gradient-01"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex justify-between gap-8 relative`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[2rem] h-[2rem] object-contain"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "font-extrabold text-[2rem] leading-[2rem] text-black",
                        children: "Olympus"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_4__.BsList, {
                        className: "w-[2rem] h-[2.4rem] object-contain text-black",
                        onClick: ()=>{
                            setIsOpen(!isOpen);
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                        variants: variants,
                        animate: isOpen ? "show" : "hidden",
                        className: "absolute top-[2.4rem] w-full h-[6.25rem] bg-white   rounded-3xl shadow-xl overflow-hidden box-border py-3 ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full h-full box-border px-3",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                href: "/homepage",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.button, {
                                    className: "w-full h-[2rem]",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-[1rem] bg-red-500 px-3 py-1 rounded-2xl   text-white w-full h-full   ",
                                        children: "Homepage"
                                    })
                                })
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4222:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7781);


const NewFeatures = ({ imgUrl , title , subtitle  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex-1 flex flex-col sm:max-w-[16rem] min-w-[13rem]",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].flexCenter */ .Z.flexCenter} w-[4.5rem] h-[4.5rem] rounded-[2rem] bg-[#323F5D]`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: imgUrl,
                    alt: "icon",
                    className: "w-1/2 h-1/2 object-contain"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                className: "mt-[2rem] font-bold text-[2rem] leading-[2rem] text-black",
                children: [
                    "Title ",
                    title
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "flex-1 mt-[1rem] font-normal text-[1rem] text-slate-800 leading-[2rem]",
                children: subtitle
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewFeatures);


/***/ }),

/***/ 8268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7781);


const StartSteps = ({ number , text  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].flexCenter */ .Z.flexCenter} flex-row`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${_styles__WEBPACK_IMPORTED_MODULE_1__/* ["default"].flexCenter */ .Z.flexCenter} w-[4.5rem] h-[4.5rem] rounded-[2rem] bg-[#323F5D]`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "font-bold text-[1rem] text-white",
                    children: number
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "flex-1 ml-[2rem] font-normal text-[1rem] text-slate-800 leading-[2rem]",
                children: text
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StartSteps);


/***/ }),

/***/ 8349:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$_": () => (/* reexport safe */ _Footer__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "L4": () => (/* reexport safe */ _InsightCard__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "NM": () => (/* reexport safe */ _ExploreCard__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "Oz": () => (/* reexport safe */ _NewFeatures__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "dy": () => (/* reexport safe */ _StartSteps__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "eN": () => (/* reexport safe */ _CustomTexts__WEBPACK_IMPORTED_MODULE_1__.e),
/* harmony export */   "gw": () => (/* reexport safe */ _CustomTexts__WEBPACK_IMPORTED_MODULE_1__.g),
/* harmony export */   "wp": () => (/* reexport safe */ _Navbar__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var _Navbar__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3349);
/* harmony import */ var _CustomTexts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6992);
/* harmony import */ var _ExploreCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(456);
/* harmony import */ var _StartSteps__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8268);
/* harmony import */ var _NewFeatures__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4222);
/* harmony import */ var _InsightCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3769);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8385);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Navbar__WEBPACK_IMPORTED_MODULE_0__, _CustomTexts__WEBPACK_IMPORTED_MODULE_1__, _ExploreCard__WEBPACK_IMPORTED_MODULE_2__, _InsightCard__WEBPACK_IMPORTED_MODULE_5__, _Footer__WEBPACK_IMPORTED_MODULE_6__]);
([_Navbar__WEBPACK_IMPORTED_MODULE_0__, _CustomTexts__WEBPACK_IMPORTED_MODULE_1__, _ExploreCard__WEBPACK_IMPORTED_MODULE_2__, _InsightCard__WEBPACK_IMPORTED_MODULE_5__, _Footer__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kn": () => (/* binding */ insights),
/* harmony export */   "UY": () => (/* binding */ socials),
/* harmony export */   "gw": () => (/* binding */ newFeatures),
/* harmony export */   "nw": () => (/* binding */ exploreWorlds),
/* harmony export */   "pT": () => (/* binding */ startingFeatures)
/* harmony export */ });
const exploreWorlds = [
    {
        id: "world-1",
        imgUrl: "/A-19th-Century-Timber-Frame-House-Adapted-To-A-Contemporary-World.jpg",
        title: "19th-century"
    },
    {
        id: "world-2",
        imgUrl: "/A-Century-Old-Barn-Transformed-Into-A-Modern-Home-With-Soaring-Ceilings.jpg",
        title: "Minimalism"
    },
    {
        id: "world-3",
        imgUrl: "/A-Serene-House-Lets-Pine-Trees-Grow-Through-Its-Decks-and-Roofs.jpg",
        title: "Natural"
    },
    {
        id: "world-4",
        imgUrl: "/A-Volcanic-Rock-House-Seamlessly-Disappears-Into-The-Landscape.jpg",
        title: "A Volcanic Rock "
    },
    {
        id: "world-5",
        imgUrl: "/Old-Ranch-Style-House-Updated-With-A-Sleek-And-Contemporary-Design.jpg",
        title: "Ranch-Style"
    }
];
const startingFeatures = [
    "Find a house that suits you and you want to enter",
    "Experience lightning-fast website loading with SSG (Static Site Generation) technology.",
    "No need to beat around the bush, just stay on the page and have fun"
];
const newFeatures = [
    {
        imgUrl: "/about/vrpano.svg",
        title: "A new world",
        subtitle: "we have the latest update with new house for you to try never mind"
    },
    {
        imgUrl: "/about/headset.svg",
        title: "More suitable",
        subtitle: "In the latest update, the narrower design of your eyes makes the house even more suitable than ever before."
    }
];
const insights = [
    {
        imgUrl: "https://cdn.luatvietnam.vn/uploaded/Images/Original/2022/02/16/chinh-sach-moi-anh-huong-den-thi-truong-bat-dong-san_1602162451.png",
        // imgUrl: '/handshake-3311965-2764508.webp',
        title: "Website with friendly interface",
        subtitle: // 'Magna etiam tempor orci eu lobortis elementum nibh tellus molestie. Diam maecenas sed enim ut sem viverra alique.'
        "The website has a friendly interface that helps you interact easily to find information"
    },
    {
        imgUrl: "https://danviet.mediacdn.vn/296231569849192448/2022/7/3/vang-16568301719341316800141.jpg",
        // imgUrl: '/alarm-clock-icon-3d-render-png.webp',
        title: "Search for a house quickly",
        subtitle: // 'Vitae congue eu consequat ac felis donec. Et magnis dis parturient montes nascetur ridiculus mus. Convallis tellus id interdum'
        "With the optimization of the website will help you find the house more quickly"
    },
    {
        imgUrl: "https://cdn.thuvienphapluat.vn/uploads/lawnews/2022/01/08/38994/dieu-kien-kinh-doanh-bat-dong-san.jpg?w\\u003d480\\u0026h\\u003d280",
        // imgUrl: '/shield_4x-removebg-preview.png',
        title: "Securely secured website ensures user experience",
        subtitle: // 'Quam quisque id diam vel quam elementum. Viverra nam libero justo laoreet sit amet cursus sit. Mauris in aliquam sem'
        "Websites with ssl certificates help keep information safe"
    }
];
const socials = [
    {
        name: "twitter",
        url: "/about/twitter.svg"
    },
    {
        name: "linkedin",
        url: "/about/linkedin.svg"
    },
    {
        name: "instagram",
        url: "/about/instagram.svg"
    },
    {
        name: "facebook",
        url: "/about/facebook.svg"
    }
];


/***/ }),

/***/ 85:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_pages_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2135);
/* harmony import */ var next_font_google_target_css_path_src_pages_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_pages_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_about__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8349);
/* harmony import */ var _sections__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7508);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_about__WEBPACK_IMPORTED_MODULE_1__, _sections__WEBPACK_IMPORTED_MODULE_2__]);
([_components_about__WEBPACK_IMPORTED_MODULE_1__, _sections__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const About_ = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `bg-primary-white overflow-hidden ${(next_font_google_target_css_path_src_pages_index_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_3___default().className)}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_1__/* .Navbar */ .wp, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections__WEBPACK_IMPORTED_MODULE_2__/* .Hero */ .VM, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections__WEBPACK_IMPORTED_MODULE_2__/* .About */ .CL, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "gradient-03 z-0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections__WEBPACK_IMPORTED_MODULE_2__/* .Explore */ .r3, {})
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections__WEBPACK_IMPORTED_MODULE_2__/* .GetStarted */ .Ff, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "gradient-04 z-0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections__WEBPACK_IMPORTED_MODULE_2__/* .WhatsNew */ .a_, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections__WEBPACK_IMPORTED_MODULE_2__/* .World */ .q3, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections__WEBPACK_IMPORTED_MODULE_2__/* .Insights */ .u$, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "gradient-04 z-0"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sections__WEBPACK_IMPORTED_MODULE_2__/* .Feedback */ .x2, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_1__/* .Footer */ .$_, {})
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About_);
const getStaticProps = async ({ params  })=>{
    return {
        props: {},
        revalidate: 60
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3443:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9765);
/* harmony import */ var _components_about__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8349);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_4__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";






const About = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].paddings */ .Z.paddings} relative z-10`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "gradient-02 z-0"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .staggerContainer */ .Jm)(null, null),
                initial: "hidden",
                whileInView: "show",
                viewport: {
                    once: false,
                    amount: 0.25
                },
                className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto ${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].flexCenter */ .Z.flexCenter} flex-col`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_4__/* .TypingText */ .gw, {
                        title: "| About Olympus",
                        textStyles: "text-center"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.p, {
                        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("up", "tween", 0.2, 1),
                        className: "mt-[8px] font-normal sm:text-[2rem] text-[1rem] text-center text-slate-700",
                        children: [
                            "Welcome to ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-extrabold text-black",
                                children: " Olympus "
                            }),
                            " ",
                            ", our real estate website, our website offers a user-friendly interface that provides your real estate search experience. With so many features packed in, we're confident ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-extrabold text-black",
                                children: " Olympus "
                            }),
                            " ",
                            "is your ultimate destination for finding the perfect home."
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                        variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("up", "tween", 0.3, 1),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiOutlineArrowDown, {
                            className: "text-[2.4rem] object-contain mt-[28px] text-black"
                        })
                    })
                ]
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (About);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8352:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7781);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1074);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9765);
/* harmony import */ var _components_about__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8349);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _components_about__WEBPACK_IMPORTED_MODULE_6__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _components_about__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";







const Explore = ()=>{
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("world-2");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_3__/* ["default"].paddings */ .Z.paddings}`,
        id: "explore",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_5__/* .staggerContainer */ .Jm)(null, null),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: false,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_3__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_6__/* .TypingText */ .gw, {
                    title: "| The House",
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_6__/* .TitleText */ .eN, {
                    title: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            "Choose the house you want ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                className: "md:block hidden"
                            }),
                            " to explore"
                        ]
                    }),
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-[3rem] flex lg:flex-row flex-col min-h-[70vh] gap-5 transition-all duration-500",
                    children: _constants__WEBPACK_IMPORTED_MODULE_4__/* .exploreWorlds.map */ .nw.map((world, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_6__/* .ExploreCard */ .NM, {
                            ...world,
                            index: index,
                            active: active,
                            handleClick: setActive
                        }, world.id))
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Explore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7984:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";




const Feedback = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].paddings */ .Z.paddings}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .staggerContainer */ .Jm)(null, null),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: false,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex lg:flex-row flex-col gap-6 transition-all `,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("right", "tween", 0.2, 1),
                    className: "flex-[0.5] lg:max-w-[34.5rem] flex justify-end flex-col gradient-05 sm:p-8 p-4 rounded-[2rem]   border-[1px] border-[#6A6A6A] relative transition-all",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "feedback-gradient"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "font-bold sm:text-[2rem] text-[2rem] sm:leading-[2rem] leading-[2rem] text-black",
                                    children: "Huy Phan"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "mt-[8px] font-normal sm:text-[1rem] text-[1rem] sm:leading-[22.68px] leading-[16.68px] text-black",
                                    children: "Founder Olympus"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "mt-[2rem] font-normal sm:text-[2.2rem] text-[1rem] sm:leading-[45.6px] leading-[39.6px] text-black",
                            children: "“With Olympus, you can easily explore and select your favorite homes. Users can access detailed information and interact with homeowners to discover your ideal home.”"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .fadeIn */ .Ji)("left", "tween", 0.2, 1),
                    className: "relative flex-1 flex justify-center items-center transition-all",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "https://thanhtra.com.vn/data/images/0/2021/12/21/nghiemlan/lam-phat-bat-dong-san.jpg",
                        alt: "planet-09",
                        className: "w-full lg:h-[38rem] h-auto min-h-[13rem] object-cover rounded-[2.4rem]   transition-all"
                    })
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Feedback);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2034:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1074);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9765);
/* harmony import */ var _components_about__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8349);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";






const GetStarted = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].paddings */ .Z.paddings} relative z-10`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .staggerContainer */ .Jm)(null, null),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: false,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex lg:flex-row flex-col gap-8`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .planetVariants */ .vk)("left"),
                    className: `flex-1 ${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].flexCenter */ .Z.flexCenter}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/about/get-started.png",
                        alt: "get-started",
                        className: "w-[90%] h-[90%] object-contain"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .fadeIn */ .Ji)("left", "tween", 0.2, 1),
                    className: "flex-[0.75] flex justify-center flex-col",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .TypingText */ .gw, {
                            title: "| How Olympus Works",
                            textStyles: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .TitleText */ .eN, {
                            title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: "Get started with just a few clicks"
                            }),
                            textStyles: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-[2rem] flex flex-col max-w-[34.5rem] gap-[2rem]",
                            children: _constants__WEBPACK_IMPORTED_MODULE_3__/* .startingFeatures.map */ .pT.map((feature, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .StartSteps */ .dy, {
                                    number: `${index < 10 ? "0" : ""} ${index + 1}`,
                                    text: feature
                                }, feature))
                        })
                    ]
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GetStarted);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2966:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
"use client";




const Hero = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].yPaddings */ .Z.yPaddings} sm:pl-16 pl-6`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .staggerContainer */ .Jm)(null, null),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: false,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col`,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-center items-center flex-col relative z-10",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.h1, {
                            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .textVariant */ .wt)(1.1),
                            className: _styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].heroHeading */ .Z.heroHeading,
                            children: "Olympus"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .textVariant */ .wt)(1.2),
                            className: "flex flex-row justify-center items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: _styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].heroHeading */ .Z.heroHeading,
                                    children: "Ma"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: _styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].heroDText */ .Z.heroDText
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                    className: _styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].heroHeading */ .Z.heroHeading,
                                    children: "Ness"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_3__/* .slideIn */ .Ym)("right", "tween", 0.2, 1),
                    className: "relative w-full md:-mt-[20px] -mt-[12px]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute w-full h-[300px] bg-red-500 rounded-tl-[140px] z-[0] -top-[30px]"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/Design-HomesFeatureImage.webp",
                            alt: "hero_cover",
                            className: "w-full sm:h-[500px] h-[350px] object-cover rounded-tl-[140px] z-10 relative"
                        })
                    ]
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3115:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1074);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9765);
/* harmony import */ var _components_about__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8349);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";






const Insights = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].paddings */ .Z.paddings} relative z-10`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .staggerContainer */ .Jm)(null, null),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: false,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .TypingText */ .gw, {
                    title: "| Insight",
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .TitleText */ .eN, {
                    title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: "Insight about Olympus"
                    }),
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "mt-[3rem] flex flex-col gap-[2rem]",
                    children: _constants__WEBPACK_IMPORTED_MODULE_3__/* .insights.map */ .Kn.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .InsightCard */ .L4, {
                            ...item,
                            index: index + 1
                        }, `insight-${index}`))
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Insights);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7539:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1074);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9765);
/* harmony import */ var _components_about__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8349);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";






const WhatsNew = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].paddings */ .Z.paddings} relative z-10`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .staggerContainer */ .Jm)(null, null),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: false,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex lg:flex-row flex-col gap-8`,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .fadeIn */ .Ji)("right", "tween", 0.2, 1),
                    className: "flex-[0.95] flex justify-center flex-col",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .TypingText */ .gw, {
                            title: "| Whats new?",
                            textStyles: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .TitleText */ .eN, {
                            title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: "What's new about Olympus?"
                            }),
                            textStyles: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mt-[48px] flex flex-wrap justify-between gap-[2rem]",
                            children: _constants__WEBPACK_IMPORTED_MODULE_3__/* .newFeatures.map */ .gw.map((feature)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_5__/* .NewFeatures */ .Oz, {
                                    ...feature
                                }, feature.title))
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .planetVariants */ .vk)("right"),
                    className: `flex-1 ${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].flexCenter */ .Z.flexCenter}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/about/whats-new.png",
                        alt: "get-started",
                        className: "w-[90%] h-[90%] object-contain"
                    })
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WhatsNew);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6905:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7781);
/* harmony import */ var _components_about__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8349);
/* harmony import */ var _utils_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9765);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_3__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _components_about__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";





const World = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].paddings */ .Z.paddings} relative z-10`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
            variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .staggerContainer */ .Jm)(null, null),
            initial: "hidden",
            whileInView: "show",
            viewport: {
                once: false,
                amount: 0.25
            },
            className: `${_styles__WEBPACK_IMPORTED_MODULE_2__/* ["default"].innerWidth */ .Z.innerWidth} mx-auto flex flex-col`,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_3__/* .TypingText */ .gw, {
                    title: "| People on the World",
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_about__WEBPACK_IMPORTED_MODULE_3__/* .TitleText */ .eN, {
                    title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: "Track friends around you and invite them to join together"
                    }),
                    textStyles: "text-center"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                    variants: (0,_utils_motion__WEBPACK_IMPORTED_MODULE_4__/* .fadeIn */ .Ji)("up", "tween", 0.3, 1),
                    className: "relative mt-[68px] flex w-full h-[34.3rem]",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/about/map.png",
                            alt: "map",
                            className: "w-full h-full object-cover"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute bottom-20 right-20 w-[4.5rem] h-[4.5rem] p-[6px] rounded-full bg-[#5D6680]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/about/people-01.png",
                                alt: "people",
                                className: "w-full h-full"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute top-10 left-20 w-[4.5rem] h-[4.5rem] p-[6px] rounded-full bg-[#5D6680]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/about/people-02.png",
                                alt: "people",
                                className: "w-full h-full"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "absolute top-1/2 left-[45%] w-[4.5rem] h-[4.5rem] p-[6px] rounded-full bg-[#5D6680]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/about/people-03.png",
                                alt: "people",
                                className: "w-full h-full"
                            })
                        })
                    ]
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (World);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7508:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CL": () => (/* reexport safe */ _About__WEBPACK_IMPORTED_MODULE_1__.Z),
/* harmony export */   "Ff": () => (/* reexport safe */ _GetStarted__WEBPACK_IMPORTED_MODULE_3__.Z),
/* harmony export */   "VM": () => (/* reexport safe */ _Hero__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "a_": () => (/* reexport safe */ _WhatsNew__WEBPACK_IMPORTED_MODULE_4__.Z),
/* harmony export */   "q3": () => (/* reexport safe */ _World__WEBPACK_IMPORTED_MODULE_5__.Z),
/* harmony export */   "r3": () => (/* reexport safe */ _Explore__WEBPACK_IMPORTED_MODULE_2__.Z),
/* harmony export */   "u$": () => (/* reexport safe */ _Insights__WEBPACK_IMPORTED_MODULE_6__.Z),
/* harmony export */   "x2": () => (/* reexport safe */ _Feedback__WEBPACK_IMPORTED_MODULE_7__.Z)
/* harmony export */ });
/* harmony import */ var _Hero__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2966);
/* harmony import */ var _About__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3443);
/* harmony import */ var _Explore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8352);
/* harmony import */ var _GetStarted__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2034);
/* harmony import */ var _WhatsNew__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7539);
/* harmony import */ var _World__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6905);
/* harmony import */ var _Insights__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3115);
/* harmony import */ var _Feedback__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7984);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Hero__WEBPACK_IMPORTED_MODULE_0__, _About__WEBPACK_IMPORTED_MODULE_1__, _Explore__WEBPACK_IMPORTED_MODULE_2__, _GetStarted__WEBPACK_IMPORTED_MODULE_3__, _WhatsNew__WEBPACK_IMPORTED_MODULE_4__, _World__WEBPACK_IMPORTED_MODULE_5__, _Insights__WEBPACK_IMPORTED_MODULE_6__, _Feedback__WEBPACK_IMPORTED_MODULE_7__]);
([_Hero__WEBPACK_IMPORTED_MODULE_0__, _About__WEBPACK_IMPORTED_MODULE_1__, _Explore__WEBPACK_IMPORTED_MODULE_2__, _GetStarted__WEBPACK_IMPORTED_MODULE_3__, _WhatsNew__WEBPACK_IMPORTED_MODULE_4__, _World__WEBPACK_IMPORTED_MODULE_5__, _Insights__WEBPACK_IMPORTED_MODULE_6__, _Feedback__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7781:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const styles = {
    innerWidth: "2xl:max-w-[1280px] w-full",
    interWidth: "lg:w-[80%] w-[100%]",
    paddings: "sm:p-16 xs:p-8 px-6 py-12",
    yPaddings: "sm:py-16 xs:py-8 py-12",
    xPaddings: "sm:px-16 px-6",
    topPaddings: "sm:pt-16 xs:pt-8 pt-12",
    bottomPaddings: "sm:pb-16 xs:pb-8 pb-12",
    flexCenter: "flex justify-center items-center",
    flexStart: "flex justify-start items-start",
    flexEnd: "flex justify-end",
    navPadding: "pt-[98px]",
    // hero section
    heroHeading: "font-bold lg:text-[144px] md:text-[100px] sm:text-[60px] text-[44px] lg:leading-[158.4px] md:leading-[114.4px] sm:leading-[74.4px] leading-[64.4px] uppercase text-black",
    heroDText: "md:w-[212px] sm:w-[80px] w-[60px] md:h-[108px] sm:h-[48px] h-[38px] md:border-[18px] border-[9px] rounded-r-[50px] border-black sm:mx-2 mx-[6px]"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (styles);


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,664,765], () => (__webpack_exec__(85)));
module.exports = __webpack_exports__;

})();