(() => {
var exports = {};
exports.id = 136;
exports.ids = [136];
exports.modules = {

/***/ 7391:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Montserrat_097b2d', '__Montserrat_Fallback_097b2d'","fontStyle":"normal"},
	"className": "__className_097b2d",
	"variable": "__variable_097b2d"
};


/***/ }),

/***/ 5361:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_bill__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2357);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_date_range__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4304);
/* harmony import */ var react_date_range__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_date_range__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _rootMaskHeader_controlPlan_controlBar_popOverDetail_who__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(779);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9445);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6197);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_7__]);
framer_motion__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const Bill = ({ houseDetail  })=>{
    const { Bill , setBill  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_bill__WEBPACK_IMPORTED_MODULE_1__/* .BillContext */ .m);
    const { address  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_6__/* .selectPlaceContext */ .t);
    const handleOnChange = (item)=>{
        setBill({
            ...Bill,
            checkInDay: item
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{}, [
        Bill.checkInDay
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setBill({
            ...Bill,
            guest: {
                ...Bill.guest,
                ...address.guest
            }
        });
        console.log("bill");
    }, [
        address
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-fit bg-white rounded-2xl   shadow-2xl sticky top-4 mb-[17.5rem] transition-all",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full h-full box-border p-5",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "text-[2.4rem] font-semibold",
                        children: [
                            "$",
                            houseDetail.Price
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "dropdown w-full border-2 border-red-500 rounded-xl",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            tabIndex: 0,
                            className: "btn m-1 w-full justify-start text-[2rem]",
                            children: Bill.checkInDay.getDate() !== new Date().getDate() ? moment__WEBPACK_IMPORTED_MODULE_2___default()(Bill.checkInDay).format("MM-DD-YYYY") : "Select date"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            tabIndex: 0,
                            className: "dropdown-content shadow-xl   menu p-2 bg-base-100 rounded-box   transition-all duration-500 w-full mt-[9.375rem]   ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_date_range__WEBPACK_IMPORTED_MODULE_4__.Calendar, {
                                    editableDateInputs: true,
                                    onChange: (item)=>handleOnChange(item),
                                    minDate: new Date(),
                                    // moveRangeOnFirstSelection={false}
                                    date: Bill.checkInDay,
                                    color: "rgb(239 68 68)",
                                    className: " font-bold m-auto text-3xl"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "dropdown w-full border-2 border-red-500 rounded-xl mt-2 ",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                            tabIndex: 0,
                            className: "btn m-1 w-full justify-start text-[2rem]",
                            children: [
                                Bill.guest.adults != 0 || Bill.guest.childrens != 0 ? Bill.guest.adults + Bill.guest.childrens + " guests" : "Guests ",
                                Bill.guest.infants != 0 && ", " + Bill.guest.infants + " infants"
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            tabIndex: 0,
                            className: "dropdown-content shadow-xl   menu p-2 bg-base-100 rounded-box   transition-all duration-500 w-full mt-[85px]   ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "w-full h-fit",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_rootMaskHeader_controlPlan_controlBar_popOverDetail_who__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                    styleWho: "justify-center  "
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_8___default()), {
                    href: `/confirm/${houseDetail.HouseId}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.button, {
                        onClick: (event)=>{
                            setBill({
                                ...Bill,
                                image: houseDetail.arrImg[0].Path,
                                title: houseDetail.Title,
                                formatedAddress: houseDetail.address.formattedAddress,
                                price: houseDetail.Price
                            });
                        },
                        className: "mt-2  w-full h-[3rem] bg-red-500 rounded-xl text-white font-semibold",
                        children: "Reverse"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Bill);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3737:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const FtHouse = ({ children , title , des  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-full flex",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "text-[1.5rem] my-auto mr-3",
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-full text-[1.5rem] flex",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "my-auto",
                    children: [
                        title + ":",
                        "  "
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: " h-full flex",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "my-auto text-[1.5rem]",
                    children: [
                        des,
                        title === "Area" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: "\xb2"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FtHouse);


/***/ }),

/***/ 1938:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var _hostUser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1600);
/* harmony import */ var _ftHouse__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3737);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4152);
/* harmony import */ var react_icons_tb__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_tb__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _hostUser__WEBPACK_IMPORTED_MODULE_2__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_1__, _hostUser__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Host = ({ userAcc , placeOffer , link , description , houseDetail  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex-[7] flex flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full mb-5 ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-[2rem]",
                    children: "Meet your host"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full rounded-2xl h-[34.3rem] bg-[#f0efe9] flex",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_hostUser__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    description: description,
                    imgPath: userAcc.Image,
                    userName: userAcc.UserName,
                    gmail: userAcc.Gmail
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-10 border-t-2 border-slate-800",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full mb-5 mt-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-[2rem]",
                            children: "Description"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full ",
                        children: description
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-10 border-t-2 border-slate-800",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full mb-5 mt-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-[2rem]",
                            children: "What this Amenities"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full grid grid-cols-2",
                        children: placeOffer.map((item, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                                whileInView: {
                                    y: [
                                        20,
                                        0
                                    ],
                                    opacity: [
                                        0,
                                        1
                                    ]
                                },
                                transition: {
                                    duration: 0.6,
                                    delay: 0.2 * index
                                },
                                className: "w-full h-fit flex items-center cursor-default",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-[1.5rem] text-ellipsis overflow-hidden whitespace-nowrap",
                                    children: item.PlaceOffer
                                })
                            }, index);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-10 border-t-2 border-slate-800",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full mb-5 mt-5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-[2rem]",
                            children: "House features"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-full grid grid-cols-2 mobile:grid-cols-1 gap-y-4 ",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ftHouse__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                des: houseDetail.Price + "",
                                title: "Price",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdOutlineAttachMoney, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ftHouse__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                des: houseDetail.Capacity + " m",
                                title: "Area",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiOutlineAreaChart, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ftHouse__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                des: houseDetail.NumsOfBath + "",
                                title: "Baths",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tb__WEBPACK_IMPORTED_MODULE_6__.TbBathFilled, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ftHouse__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                des: houseDetail.NumsOfBed + "",
                                title: "Beds",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_7__.BiSolidBed, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ftHouse__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                des: houseDetail.Orientation + "",
                                title: "Orientation",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_8__.FaCompass, {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ftHouse__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                des: houseDetail.Type,
                                title: "Type",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_9__.BsFillHouseFill, {})
                            })
                        ]
                    })
                ]
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Host);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5748:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_1__]);
framer_motion__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const MapBox = ({ longitude , latitude , keyMapBing  })=>{
    const [viewPort, setViewPort] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        longitude: longitude,
        latitude: latitude,
        keyMapBing: keyMapBing
    });
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        bing_maps_loader__WEBPACK_IMPORTED_MODULE_3__.whenLoaded.then(()=>{
            const map_ = document.getElementById("Map");
            if (map_) {
                var map = new Microsoft.Maps.Map(map_, {
                    /* No need to set credentials if already passed in URL */ center: new Microsoft.Maps.Location(latitude, longitude),
                    mapTypeId: Microsoft.Maps.MapTypeId.road,
                    zoom: 18,
                    credentials: keyMapBing,
                    disableScrollWheelZoom: true
                });
                var pushpin = new Microsoft.Maps.Pushpin(map.getCenter(), undefined);
                var layer = new Microsoft.Maps.Layer();
                layer.add(pushpin);
                map.layers.insert(layer);
            }
        });
    }, [
        latitude,
        longitude
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-fit mt-10 border-t-2 border-slate-800 mb-10",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full mb-5 mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-[2rem]",
                    children: "Where you will be"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__.motion.div, {
                whileInView: {
                    y: [
                        40,
                        0
                    ],
                    opacity: [
                        0,
                        1
                    ]
                },
                transition: {
                    duration: 0.5
                },
                className: "w-full h-fit",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full h-[32rem] rounded-3xl border-2 border-red-400 overflow-hidden",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        id: "Map"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapBox);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5214:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_isShowPt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1069);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _showAllHousePt_maskPt__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6487);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _showAllHousePt_maskPt__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _showAllHousePt_maskPt__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const Picture = ({ arrImg  })=>{
    const { setIsShowAllPt  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_isShowPt__WEBPACK_IMPORTED_MODULE_1__/* .IsShowPtContext */ .Y);
    const [select, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const handleOnClick = ()=>{
        setIsShowAllPt(true);
        document.body.style.overflow = "hidden";
    };
    const settingImg = "object-cover w-full h-full hover:opacity-50  transition-all duration-500";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[28rem] grid gap-3 rounded-3xl overflow-hidden mt-7   grid-cols-layoutPicture grid-rows-layoutPicture grid-areas-layoutPicture   relative mobile:hidden tablet:hidden   ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/api/img/path/" + arrImg[0].Path,
                        alt: "",
                        onClick: ()=>setSelect(arrImg[0].Path),
                        className: `grid-in-h1 ${settingImg}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/api/img/path/" + arrImg[1].Path,
                        alt: "",
                        onClick: ()=>setSelect(arrImg[1].Path),
                        className: `grid-in-h2 ${settingImg}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/api/img/path/" + arrImg[2].Path,
                        alt: "",
                        onClick: ()=>setSelect(arrImg[2].Path),
                        className: `grid-in-h3 ${settingImg}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/api/img/path/" + arrImg[3].Path,
                        alt: "",
                        onClick: ()=>setSelect(arrImg[3].Path),
                        className: `grid-in-h4 ${settingImg}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/api/img/path/" + arrImg[4].Path,
                        alt: "",
                        onClick: ()=>setSelect(arrImg[4].Path),
                        className: `grid-in-h5 ${settingImg}`
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                        onClick: handleOnClick,
                        whileTap: {
                            scale: 0.8
                        },
                        className: "absolute w-[14rem] h-[2.4rem] bg-white right-10 bottom-5 rounded-xl   flex cursor-pointer   ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-fit h-fit flex items-center m-auto",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_4__.BiMenu, {
                                    className: "text-[1rem]"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-[15px]",
                                    children: "Show all photos"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_showAllHousePt_maskPt__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                Path: select,
                setPath: setSelect
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Picture);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4397:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_isShowPt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1069);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _maskPt__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6487);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _maskPt__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _maskPt__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const variants = {
    show: {
        top: [
            1200,
            0
        ]
    },
    hidden: {
        top: [
            0,
            1200
        ]
    }
};
const ShowAllHouse = ({ arrImg  })=>{
    const [select, setSelect] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { isShowAllPt , setIsShowAllPt  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_isShowPt__WEBPACK_IMPORTED_MODULE_1__/* .IsShowPtContext */ .Y);
    const [isFirstLoading, setIsFirstLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
            variants: variants,
            initial: isFirstLoading ? false : "hidden",
            animate: isShowAllPt ? "show" : "hidden",
            transition: {
                duration: 0.6
            },
            onClickCapture: (event)=>{
                document.body.style.overflow = "hidden";
            },
            className: "fixed left-0 w-screen h-screen z-[500] bg-white",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "h-full w-full relative flex",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-fit absolute top-0 ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
                            whileTap: {
                                scale: 0.8
                            },
                            onClick: (event)=>{
                                setIsShowAllPt(false);
                                document.body.style.overflow = "scroll";
                                document.body.style.overflowX = "hidden";
                            },
                            className: "w-[6.25rem] h-[6.25rem] cursor-pointer flex",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoChevronBackOutline, {
                                className: "text-[3rem] m-auto"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full overflow-scroll overflow-x-hidden flex ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-[700px] columns-2 h-fit gap-2  m-auto  mt-28 mb-14 overflow-hidden ",
                            children: arrImg.map((item, index)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                                    whileHover: {
                                        opacity: 0.6
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/api/img/path/" + item.Path,
                                        alt: "",
                                        onClick: ()=>setSelect(item.Path),
                                        className: "w-full   shadow-xl image-full cursor-pointer mb-2 rounded-lg   "
                                    })
                                }, index);
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_maskPt__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        Path: select,
                        setPath: setSelect
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShowAllHouse);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6069:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const TitleHouse = ({ title , address  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full h-fit flex flex-col box-border px-10 mt-7 ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-1 mb-3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-[2rem] font-semibold",
                    children: title
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-1",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: address.formattedAddress
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TitleHouse);


/***/ }),

/***/ 6808:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_pages_house_slug_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(7391);
/* harmony import */ var next_font_google_target_css_path_src_pages_house_slug_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_pages_house_slug_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3446);
/* harmony import */ var _components_footers_footerRooms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2883);
/* harmony import */ var _components_houseDetail_bill__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5361);
/* harmony import */ var _components_houseDetail_host_host__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1938);
/* harmony import */ var _components_houseDetail_map__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5748);
/* harmony import */ var _components_houseDetail_picture__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5214);
/* harmony import */ var _components_houseDetail_showAllHousePt_showAllHouse__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4397);
/* harmony import */ var _components_houseDetail_titleHouse__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6069);
/* harmony import */ var _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(231);
/* harmony import */ var _components_main_showHouse_carousel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3579);
/* harmony import */ var _components_rootMaskHeader_headerMain__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8248);
/* harmony import */ var _contexts_isShowPt__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1069);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7991);
/* harmony import */ var bing_maps_loader__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(bing_maps_loader__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5687);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var node_fetch__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6544);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_1__, _components_houseDetail_bill__WEBPACK_IMPORTED_MODULE_3__, _components_houseDetail_host_host__WEBPACK_IMPORTED_MODULE_4__, _components_houseDetail_map__WEBPACK_IMPORTED_MODULE_5__, _components_houseDetail_picture__WEBPACK_IMPORTED_MODULE_6__, _components_houseDetail_showAllHousePt_showAllHouse__WEBPACK_IMPORTED_MODULE_7__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_9__, _components_main_showHouse_carousel__WEBPACK_IMPORTED_MODULE_10__, _components_rootMaskHeader_headerMain__WEBPACK_IMPORTED_MODULE_11__, framer_motion__WEBPACK_IMPORTED_MODULE_14__, node_fetch__WEBPACK_IMPORTED_MODULE_18__]);
([_components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_1__, _components_houseDetail_bill__WEBPACK_IMPORTED_MODULE_3__, _components_houseDetail_host_host__WEBPACK_IMPORTED_MODULE_4__, _components_houseDetail_map__WEBPACK_IMPORTED_MODULE_5__, _components_houseDetail_picture__WEBPACK_IMPORTED_MODULE_6__, _components_houseDetail_showAllHousePt_showAllHouse__WEBPACK_IMPORTED_MODULE_7__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_9__, _components_main_showHouse_carousel__WEBPACK_IMPORTED_MODULE_10__, _components_rootMaskHeader_headerMain__WEBPACK_IMPORTED_MODULE_11__, framer_motion__WEBPACK_IMPORTED_MODULE_14__, node_fetch__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















const HouseDetail = ({ houseDetail , keyMapBing , link  })=>{
    const { setIsShowAllPt  } = (0,react__WEBPACK_IMPORTED_MODULE_15__.useContext)(_contexts_isShowPt__WEBPACK_IMPORTED_MODULE_12__/* .IsShowPtContext */ .Y);
    const handleOnClick = ()=>{
        setIsShowAllPt(true);
        document.body.style.overflow = "hidden";
    };
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_13__.initializeSSR)();
    (0,react__WEBPACK_IMPORTED_MODULE_15__.useEffect)(()=>{
        window.scrollTo(0, 0);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-fit",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                className: `${(next_font_google_target_css_path_src_pages_house_slug_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_19___default().className)} relative box-border`,
                id: "root",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_14__.AnimatePresence, {
                        initial: false,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_rootMaskHeader_headerMain__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            keyMapBing: ""
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-[1150px] h-fit   tablet:w-screen mobile:w-screen mobile:px-4   box-border m-auto",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_titleHouse__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                title: houseDetail?.Title,
                                address: houseDetail.address
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_picture__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                arrImg: houseDetail.arrImg
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "w-full h-[32rem] laptop:hidden desktop:hidden flex justify-center box-border relative z-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_main_showHouse_carousel__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        arrImg: houseDetail.arrImg,
                                        houseId: houseDetail.HouseId
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        onClick: handleOnClick,
                                        className: "absolute right-4 bottom-4 w-fit h-fit   rounded-xl p-3   bg-white z-50 flex items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_16__.BiMenu, {
                                                className: "text-[2rem] "
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-[19px]",
                                                children: "Show all photos"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_showAllHousePt_showAllHouse__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                arrImg: houseDetail.arrImg
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full h-fit mt-10",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "w-full h-fit flex box-border mobile:flex-col",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_host_host__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            houseDetail: houseDetail,
                                            description: houseDetail.Description,
                                            link: link,
                                            userAcc: houseDetail.useracc,
                                            placeOffer: houseDetail.placeOffer
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("article", {
                                            className: "flex-[5] ml-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_bill__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                houseDetail: houseDetail
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_houseDetail_map__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                latitude: houseDetail.address.latitude,
                                longitude: houseDetail.address.longitude,
                                keyMapBing: keyMapBing
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footers_footerRooms__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footers_footerMainRes__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                ]
            })
        })
    });
};
let cachedHouseDetail = [];
HouseDetail.Layout = _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z;
const getStaticPaths = async ()=>{
    const link = process.env.API_URL_PATH;
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_13__.initializeSSR)();
    const httpsAgent = new (https__WEBPACK_IMPORTED_MODULE_17___default().Agent)({
        rejectUnauthorized: false
    });
    if (cachedHouseDetail.length == 0) {
        try {
            const slug = await (0,node_fetch__WEBPACK_IMPORTED_MODULE_18__["default"])(`${link}/api/get/house/page`, {
                agent: httpsAgent
            });
            cachedHouseDetail = await slug.json();
        } catch (error) {
            console.log(error);
        }
    }
    const paths = cachedHouseDetail.map((house)=>({
            params: {
                slug: house.HouseId
            }
        }));
    return {
        paths,
        fallback: "blocking"
    };
};
const getStaticProps = async ({ params  })=>{
    (0,bing_maps_loader__WEBPACK_IMPORTED_MODULE_13__.initializeSSR)();
    const link = process.env.API_URL_PATH;
    const httpsAgent = new (https__WEBPACK_IMPORTED_MODULE_17___default().Agent)({
        rejectUnauthorized: false
    });
    if (cachedHouseDetail.length == 0) {
        const slug = await (0,node_fetch__WEBPACK_IMPORTED_MODULE_18__["default"])(`${link}/api/get/house/page`, {
            agent: httpsAgent
        });
        cachedHouseDetail = await slug.json();
    }
    const houseDetailData = cachedHouseDetail.find((house)=>house.HouseId === params?.slug);
    const keyMapBing = process.env.ACCESS_TOKEN_BINGMAP;
    return {
        props: {
            houseDetail: houseDetailData,
            keyMapBing: keyMapBing,
            link: link
        },
        revalidate: 60
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HouseDetail);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7991:
/***/ ((module) => {

"use strict";
module.exports = require("bing-maps-loader");

/***/ }),

/***/ 5538:
/***/ ((module) => {

"use strict";
module.exports = require("bingmaps");

/***/ }),

/***/ 4146:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 808:
/***/ ((module) => {

"use strict";
module.exports = require("nprogress");

/***/ }),

/***/ 1817:
/***/ ((module) => {

"use strict";
module.exports = require("rc-slider");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 4304:
/***/ ((module) => {

"use strict";
module.exports = require("react-date-range");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 8547:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gr");

/***/ }),

/***/ 1111:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/hi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io");

/***/ }),

/***/ 9989:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io5");

/***/ }),

/***/ 4041:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/md");

/***/ }),

/***/ 4152:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

"use strict";
module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ }),

/***/ 6544:
/***/ ((module) => {

"use strict";
module.exports = import("node-fetch");;

/***/ }),

/***/ 5563:
/***/ ((module) => {

"use strict";
module.exports = import("popmotion");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,664,170,298,636,675,864,445,586,565,731,543,413,856,209,751,905,667,248], () => (__webpack_exec__(6808)));
module.exports = __webpack_exports__;

})();