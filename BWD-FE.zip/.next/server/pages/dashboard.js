"use strict";
(() => {
var exports = {};
exports.id = 26;
exports.ids = [26];
exports.modules = {

/***/ 9841:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ schedule)
/* harmony export */ });
/* harmony import */ var _axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const schedule = {
    createSchedule (payload) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/create/schedule/host", payload);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8033:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ ScheduleApi)
/* harmony export */ });
/* harmony import */ var _axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// get/schedule/host

const ScheduleApi = {
    scheduleHost (HostId) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/get/schedule/host", {
            HostId: HostId
        });
    },
    scheduleHostModifier (EventId, event) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/modifier/schedule/host", {
            EventId: EventId,
            data: event
        });
    },
    scheduleHostDelete (EventId) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/delete/scheduel/host", {
            EventId: EventId
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_dashboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5382);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const LayoutPanelDasboard = ({ children  })=>{
    const { selectOption  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_dashboard__WEBPACK_IMPORTED_MODULE_1__/* .DashboardContext */ .G);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-full ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full rounded-xl shadow-xl overflow-hidden p-10 box-border",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full h-full",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-full h-full flex flex-col overflow-hidden",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-[3rem] font-semibold",
                            children: selectOption
                        }),
                        children
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LayoutPanelDasboard);


/***/ }),

/***/ 6371:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3708);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styleButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4603);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_styleButton__WEBPACK_IMPORTED_MODULE_3__]);
_styleButton__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const NavbarDashboard = ()=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_1__/* .userAccContext */ .G);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{}, [
        user
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-[20rem] h-full border-r-2",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-fit  flex flex-col items-center py-4 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[7rem] h-[7rem] bg-white rounded-full overflow-hidden",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/api/img/path/" + user.Image,
                            className: "w-full h-full"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-fit h-fit mt-5 flex text-center flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Welcome"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-[30px] font-semibold",
                                children: user.UserName
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-auto grid grid-cols-1 grid-rows-3",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleButton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            title: "Schedule",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_4__.GrSchedules, {
                                className: "text-[25px] my-auto mr-2"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleButton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            title: "Piechart",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_5__.AiOutlinePieChart, {
                                className: "text-[25px] my-auto mr-2"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styleButton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            title: "Barchart",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_6__.BsFillBarChartFill, {
                                className: "text-[25px] my-auto mr-2"
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarDashboard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4603:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_dashboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5382);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__]);
framer_motion__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const StyleButton = ({ children , title  })=>{
    const [isHover, setIsHover] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { selectOption , setSelectOption  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_contexts_dashboard__WEBPACK_IMPORTED_MODULE_1__/* .DashboardContext */ .G);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-[4rem] ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.button, {
            onClick: (event)=>{
                setSelectOption(title);
            },
            onHoverStart: (event)=>{
                setIsHover(true);
            },
            onHoverEnd: (event)=>{
                setIsHover(false);
            },
            className: "w-full h-full flex relative z-10",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    animate: isHover ? {
                        width: [
                            "0%",
                            "100%"
                        ]
                    } : {
                        width: [
                            "100%",
                            "0%"
                        ]
                    },
                    className: "absolute h-full w-0 top-0 left-0 bg-emerald-300 z-0"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_2__.motion.div, {
                    className: "w-[50%] h-fit m-auto flex relative z-10   justify-start ",
                    children: [
                        children,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-[24px]",
                            children: title
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StyleButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 816:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8033);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
([_api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const EditEvents = ({ isRemoveReq , selectedRemove , setIsRemoveReq  })=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__/* .userAccContext */ .G);
    const [edited, setEdited] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [isTruePass, setIsTruePass] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        isTruePass
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full m-auto flex",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "m-auto flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-[9.375rem] h-fit mobile:h-full",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: `/api/img/path/${user.Image}`,
                                alt: "",
                                className: "rounded-full"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-fit h-full grid grid-cols-1 grid-rows-2 ml-[2rem] m-auto gap-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "font-semibold text-[3rem] mobile:text-[2rem]",
                                    children: "Edit title"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: `outline-none
            border-b-2 border-slate-900
            ${isTruePass ? "" : "border-red-600"} mobile:text-[19px] text-[2rem] `,
                                        placeholder: selectedRemove?.event.title,
                                        onChange: (event)=>setEdited(event.target.value)
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[6.25rem]  grid grid-cols-2 grid-rows-1 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full box-border p-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                            onClick: (event)=>{
                                setIsRemoveReq(false);
                            },
                            className: "w-full h-full rounded-xl border-2 font-semibold",
                            children: "Cancel"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full box-border p-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                            type: "button",
                            onClick: async (event)=>{
                                // selectedRemove?.event.;
                                setIsRemoveReq(false);
                                console.log(edited);
                                try {
                                    if (selectedRemove?.event?.id) {
                                        _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__/* .ScheduleApi.scheduleHostModifier */ .I.scheduleHostModifier(selectedRemove?.event?.id, {
                                            PhoneNumber: edited
                                        });
                                        selectedRemove.event.setProp("title", edited);
                                    }
                                    setEdited("");
                                } catch (error) {
                                    console.log(error);
                                    return error;
                                }
                            },
                            className: "w-full h-full rounded-xl border-2 bg-red bg-[#f05123]   text-white font-semibold   ",
                            children: "Edit"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditEvents);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7249:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8033);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
([_api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const RemoveEvent = ({ isRemoveReq , selectedRemove , setIsRemoveReq  })=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__/* .userAccContext */ .G);
    const [inputPass, setInputPass] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [isTruePass, setIsTruePass] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        isTruePass
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full m-auto flex",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "m-auto flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-[9.375rem] h-fit",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: `/api/img/path/${user.Image}`,
                                alt: "",
                                className: "rounded-full"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-fit h-full grid grid-cols-1 grid-rows-2 ml-[2rem] m-auto gap-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "font-semibold text-[3rem] mobile:text-[2rem]",
                                    children: "Delete house"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "password",
                                        className: `outline-none
            border-b-2 border-slate-900
            ${isTruePass ? "" : "border-red-600"} mobile:text-[19px] text-[2rem] `,
                                        placeholder: "Password",
                                        onChange: (event)=>setInputPass(event.target.value)
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[6.25rem]  grid grid-cols-2 grid-rows-1 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full box-border p-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                            onClick: (event)=>{
                                setIsRemoveReq(false);
                            },
                            className: "w-full h-full rounded-xl border-2 font-semibold",
                            children: "Cancel"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full box-border p-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                            type: "button",
                            onClick: async (event)=>{
                                if (inputPass === user.Password) {
                                    selectedRemove?.event.remove();
                                    setIsRemoveReq(false);
                                    try {
                                        _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__/* .ScheduleApi.scheduleHostDelete */ .I.scheduleHostDelete(selectedRemove?.event?.id || "");
                                    } catch (error) {
                                        console.log(error);
                                        return error;
                                    }
                                }
                            },
                            className: "w-full h-full rounded-xl border-2 bg-red bg-[#f05123]   text-white font-semibold   ",
                            children: "Delete"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RemoveEvent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9464:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_schedule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9841);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_schedule__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_3__]);
([_api_client_schedule__WEBPACK_IMPORTED_MODULE_1__, framer_motion__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const AddEvent = ({ selected , setIsAddEvent  })=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__/* .userAccContext */ .G);
    const [edited, setEdited] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [isTruePass, setIsTruePass] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        isTruePass
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "w-full m-auto flex",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "m-auto flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-[9.375rem] h-fit mobile:h-full",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: `/api/img/path/${user.Image}`,
                                alt: "",
                                className: "rounded-full"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-fit h-full grid grid-cols-1 grid-rows-2 ml-[2rem] m-auto gap-5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "font-semibold text-[3rem] mobile:text-[2rem]",
                                    children: "Add event"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: `outline-none
            border-b-2 border-slate-900 mobile:text-[19px] text-[2rem] `,
                                        value: edited,
                                        onChange: (event)=>setEdited(event.target.value)
                                    })
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[6.25rem]  grid grid-cols-2 grid-rows-1 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full box-border p-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                            onClick: (event)=>{
                                setEdited("");
                                setIsAddEvent(false);
                            },
                            className: "w-full h-full rounded-xl border-2 font-semibold",
                            children: "Cancel"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full box-border p-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.button, {
                            type: "button",
                            onClick: async (event)=>{
                                // selectedRemove?.event.;
                                if (!selected) return;
                                const calenderApi = selected.view.calendar;
                                calenderApi.addEvent({
                                    id: `${selected.startStr}-${edited}`,
                                    title: edited,
                                    start: selected.startStr,
                                    end: selected.endStr,
                                    allDay: selected.allDay
                                });
                                setEdited("");
                                setIsAddEvent(false);
                                const createSchedule = await _api_client_schedule__WEBPACK_IMPORTED_MODULE_1__/* .schedule.createSchedule */ .O.createSchedule({
                                    EventId: "",
                                    HouseId: "",
                                    UserId: "",
                                    PhoneNumber: edited,
                                    Date: new Date(selected.startStr),
                                    Adults: 0,
                                    Childrens: 0,
                                    Infants: 0,
                                    Host: user.UserId,
                                    house: undefined
                                });
                                if (createSchedule.status != 200) {
                                    console.log("have err with create schedule");
                                    return;
                                }
                            },
                            className: "w-full h-full rounded-xl border-2 bg-red bg-[#f05123]   text-white font-semibold   ",
                            children: "Add"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddEvent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8634:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const LayoutTitle = ({ children , leftRight  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full h-full flex items-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `m-auto ${leftRight === "left" ? "ml-0" : "mr-0"} text-ellipsis overflow-hidden whitespace-nowrap`,
            children: children
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LayoutTitle);


/***/ }),

/***/ 7266:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_dashboard__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5382);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _layoutTitle__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8634);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_4__]);
framer_motion__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const PopupSchedule = ({ isShowPopup , setIsShowPopup  })=>{
    const { selectHousePopup , setSelectHousePopup  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_dashboard__WEBPACK_IMPORTED_MODULE_1__/* .DashboardContext */ .G);
    const popupHouse = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const { x , y  } = useFollowPointer(popupHouse);
    // if (!selectHousePopup) return (
    //   <div className="hidden"></div>
    // )
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_4__.motion.div, {
        ref: popupHouse,
        animate: {
            x,
            y
        },
        className: `w-fit fixed z-50 h-fit ${isShowPopup ? "" : "hidden"}
      ${selectHousePopup && selectHousePopup.HouseId ? "" : "hidden"}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-[20rem] h-[15rem] rounded-xl overflow-hidden",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-full relative",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                        src: "/api/img/path/" + selectHousePopup?.arrImg[0]?.Path,
                        alt: "",
                        className: "w-full h-full   object-cover   "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "absolute w-full h-[5rem] bottom-0 left-0 backdrop-blur-sm box-border px-2   rounded-b-xl   ",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full h-full grid grid-cols-2 grid-rows-3 gap-y-5   text-[#de741c] font-semibold",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layoutTitle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    leftRight: "left",
                                    children: selectHousePopup?.address.title
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layoutTitle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    leftRight: "right",
                                    children: [
                                        "$",
                                        selectHousePopup?.Price
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layoutTitle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    leftRight: "left",
                                    children: [
                                        selectHousePopup?.NumsOfBath + " Baths,",
                                        " ",
                                        selectHousePopup?.NumsOfBed + " Beds"
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_layoutTitle__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    leftRight: "right",
                                    children: [
                                        selectHousePopup?.Capacity + "m",
                                        "\xb2"
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PopupSchedule);
function useFollowPointer(ref) {
    const [point, setPoint] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        x: 0,
        y: 0
    });
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (!ref.current) return;
        const handlePointerMove = ({ clientX , clientY  })=>{
            const element = ref.current;
            const x = clientX - element.offsetLeft - element.offsetWidth / 2 + 200;
            const y = clientY - element.offsetTop - element.offsetHeight / 2 - 150;
            setPoint({
                x,
                y
            });
        };
        window.addEventListener("mousemove", handlePointerMove);
        return ()=>window.removeEventListener("mousemove", handlePointerMove);
    }, []);
    return point;
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2979:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _contexts_selectHouse__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2586);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3708);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _panelPopup_removeEvent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7249);
/* harmony import */ var _panelPopup_editEvent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(816);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_3__, _panelPopup_removeEvent__WEBPACK_IMPORTED_MODULE_5__, _panelPopup_editEvent__WEBPACK_IMPORTED_MODULE_6__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_3__, _panelPopup_removeEvent__WEBPACK_IMPORTED_MODULE_5__, _panelPopup_editEvent__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const RemoveReqSchedule = ({ isRemoveReq , setIsRemoveReq , selectedRemove  })=>{
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_2__/* .userAccContext */ .G);
    const { selectHouse , setSelectHouse  } = (0,react__WEBPACK_IMPORTED_MODULE_4__.useContext)(_contexts_selectHouse__WEBPACK_IMPORTED_MODULE_1__/* .selectHouseContext */ .q);
    const [inputPass, setInputPass] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("");
    const [isEdit, setIsEdit] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("edit");
    const [isTruePass, setIsTruePass] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{}, [
        isTruePass
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-[5rem]  grid grid-cols-2 grid-rows-1 gap-x-5 mb-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: (event)=>setIsEdit("edit"),
                        className: "w-full h-full flex bg-white rounded-xl",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-fit h-fit m-auto",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold text-[25px]",
                                children: "Edit"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: (event)=>setIsEdit("delete"),
                        className: "w-full h-full flex bg-white rounded-xl",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-fit h-fit m-auto",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-semibold text-[25px]",
                                children: "Delete"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.AnimatePresence, {
                mode: "wait",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_3__.motion.div, {
                    initial: {
                        y: 10,
                        opacity: 0
                    },
                    animate: {
                        y: 0,
                        opacity: 1
                    },
                    exit: {
                        y: -10,
                        opacity: 0
                    },
                    transition: {
                        duration: 0.2
                    },
                    className: "w-fit h-fit bg-white mobile:w-screen mobile:h-screen   flex flex-col mobile:p-0 p-5 rounded-xl ",
                    children: isEdit === "edit" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_panelPopup_editEvent__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        isRemoveReq: isRemoveReq,
                        selectedRemove: selectedRemove,
                        setIsRemoveReq: setIsRemoveReq
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_panelPopup_removeEvent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        isRemoveReq: isRemoveReq,
                        selectedRemove: selectedRemove,
                        setIsRemoveReq: setIsRemoveReq
                    })
                }, isEdit)
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RemoveReqSchedule);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4723:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8033);
/* harmony import */ var _components_main_showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8462);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3708);
/* harmony import */ var _fullcalendar_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9405);
/* harmony import */ var _fullcalendar_daygrid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5503);
/* harmony import */ var _fullcalendar_interaction__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1103);
/* harmony import */ var _fullcalendar_list__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2483);
/* harmony import */ var _fullcalendar_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9870);
/* harmony import */ var _fullcalendar_timegrid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(476);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _removeReqSchedule__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2979);
/* harmony import */ var _contexts_dashboard__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5382);
/* harmony import */ var _popupSchedule_popupSchedule__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7266);
/* harmony import */ var _popupSchedule_addEvent__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9464);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__, _fullcalendar_core__WEBPACK_IMPORTED_MODULE_4__, _fullcalendar_daygrid__WEBPACK_IMPORTED_MODULE_5__, _fullcalendar_interaction__WEBPACK_IMPORTED_MODULE_6__, _fullcalendar_list__WEBPACK_IMPORTED_MODULE_7__, _fullcalendar_react__WEBPACK_IMPORTED_MODULE_8__, _fullcalendar_timegrid__WEBPACK_IMPORTED_MODULE_9__, framer_motion__WEBPACK_IMPORTED_MODULE_10__, _removeReqSchedule__WEBPACK_IMPORTED_MODULE_12__, _popupSchedule_popupSchedule__WEBPACK_IMPORTED_MODULE_14__, _popupSchedule_addEvent__WEBPACK_IMPORTED_MODULE_15__]);
([_api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__, _fullcalendar_core__WEBPACK_IMPORTED_MODULE_4__, _fullcalendar_daygrid__WEBPACK_IMPORTED_MODULE_5__, _fullcalendar_interaction__WEBPACK_IMPORTED_MODULE_6__, _fullcalendar_list__WEBPACK_IMPORTED_MODULE_7__, _fullcalendar_react__WEBPACK_IMPORTED_MODULE_8__, _fullcalendar_timegrid__WEBPACK_IMPORTED_MODULE_9__, framer_motion__WEBPACK_IMPORTED_MODULE_10__, _removeReqSchedule__WEBPACK_IMPORTED_MODULE_12__, _popupSchedule_popupSchedule__WEBPACK_IMPORTED_MODULE_14__, _popupSchedule_addEvent__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const Schedule = ()=>{
    const [currentEvents, setCurrentEvents] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)([]);
    const calendarRef = (0,react__WEBPACK_IMPORTED_MODULE_11__.useRef)(null);
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_3__/* .userAccContext */ .G);
    const [isRemoveReq, setIsRemoveReq] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const { eventArr , setEventArr , setSelectHousePopup , selectHousePopup  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useContext)(_contexts_dashboard__WEBPACK_IMPORTED_MODULE_13__/* .DashboardContext */ .G);
    const [isFirstLoading, setIsFirstLoading] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(true);
    const [selectedRemove, setSelectedRemove] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)();
    const removeReqPanel = (0,react__WEBPACK_IMPORTED_MODULE_11__.useRef)(null);
    const [selectAddEvent, setSelectAddEvent] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)();
    const [isAddEvent, setIsAddEvent] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const addEventPanell = (0,react__WEBPACK_IMPORTED_MODULE_11__.useRef)(null);
    const [isShowPopup, setIsShowPopup] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(false);
    const [keyPopup, setKeyPopup] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)(-1);
    const handleDateClick = (selected)=>{
        console.log("test", selected);
        setSelectAddEvent(selected);
        setIsAddEvent(true);
    };
    const handleEventClick = (selected)=>{
        // if (window.confirm('delete')) {
        //   selected.event.remove();
        // }
        setSelectedRemove(selected);
        setIsRemoveReq(true);
    };
    function addDays(date, days) {
        var result = new Date(date);
        result.setDate(result.getDate() + days);
        return result;
    }
    const handleOnClickOutSideAddEventPanel = (event)=>{
        const isClickInSide = addEventPanell.current?.contains(event.target);
        if (!isClickInSide) {
            setIsAddEvent(false);
            return;
        } else {
            return;
        }
    };
    const handleOnClickOutSideRemoveReqPanel = (event)=>{
        const isClickInSide = removeReqPanel.current?.contains(event.target);
        if (!isClickInSide) {
            setIsRemoveReq(false);
            return;
        } else {
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        const addEv = async ()=>{
            if (eventArr.length == 0) return;
            const calendarApi = calendarRef?.current?.getApi();
            console.log("event", eventArr);
            const setEv = await eventArr.map((item, index)=>{
                if (item.HouseId !== null) {
                    const newEvent = {
                        title: item.PhoneNumber,
                        start: item.Date + "",
                        id: item.EventId,
                        color: "#ee6457"
                    };
                    if (calendarApi) {
                        calendarApi.addEvent(newEvent);
                    }
                } else {
                    const newEvent = {
                        title: item.PhoneNumber,
                        start: item.Date + "",
                        id: item.EventId
                    };
                    if (calendarApi) {
                        calendarApi.addEvent(newEvent);
                    }
                }
                return item;
            });
        };
        addEv();
    }, [
        eventArr
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        console.log("crev", currentEvents);
    }, [
        currentEvents,
        selectedRemove
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popupSchedule_popupSchedule__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                isShowPopup: isShowPopup,
                setIsShowPopup: setIsShowPopup
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                    variants: _components_main_showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_2__/* .variants */ .o,
                    animate: isAddEvent ? "showMask" : "hiddenMask",
                    onClick: handleOnClickOutSideAddEventPanel,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit h-fit m-auto bg-white mobile:w-screen mobile:h-screen   flex flex-col mobile:p-0 p-5 rounded-xl ",
                        ref: addEventPanell,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popupSchedule_addEvent__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                            selected: selectAddEvent,
                            setIsAddEvent: setIsAddEvent
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                    variants: _components_main_showHouse_variantsShowHouse__WEBPACK_IMPORTED_MODULE_2__/* .variants */ .o,
                    animate: isRemoveReq ? "showMask" : "hiddenMask",
                    onClick: handleOnClickOutSideRemoveReqPanel,
                    className: "fixed w-screen h-screen bg-mask z-50 top-0 left-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-fit h-fit m-auto",
                        ref: removeReqPanel,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_removeReqSchedule__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            selectedRemove: selectedRemove,
                            setIsRemoveReq: setIsRemoveReq,
                            isRemoveReq: isRemoveReq
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full h-full flex box-border ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                        className: "w-[15rem] h-[70vh] overflow-scroll overflow-x-hidden mobile:hidden",
                        children: currentEvents.map((item, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                                    onHoverStart: (event)=>{
                                        // if (!eventArr[index].house) return
                                        setIsShowPopup(true);
                                        setKeyPopup(index);
                                        setSelectHousePopup(eventArr[index].house);
                                    // if (eventArr[index].house !== undefined && eventArr[index].house?.length == 0) return;
                                    // console.log(eventArr[index].house);
                                    // setSelectHousePopup(eventArr[index]?.house[0]);
                                    },
                                    onHoverEnd: (event)=>{
                                        setIsShowPopup(false);
                                        setKeyPopup(-1);
                                    },
                                    className: "w-ful h-[8rem]   box-border p-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                                        className: "w-full h-full bg-[#6699CC] rounded-lg p-2 cursor-pointer",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                                            onHoverStart: (event)=>setIsShowPopup(true),
                                            className: "w-fit h-fit flex flex-col text-[#FAE8EB]  ",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "mb-2 font-semibold text-[20px]",
                                                    children: item.title
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: (0,_fullcalendar_core__WEBPACK_IMPORTED_MODULE_4__.formatDate)(item.startStr, {
                                                        year: "numeric",
                                                        month: "short",
                                                        day: "numeric"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            }, index);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-[calc(100%-15rem)] h-full mobile:w-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fullcalendar_react__WEBPACK_IMPORTED_MODULE_8__["default"], {
                            ref: calendarRef,
                            height: "100%",
                            plugins: [
                                _fullcalendar_daygrid__WEBPACK_IMPORTED_MODULE_5__["default"],
                                _fullcalendar_interaction__WEBPACK_IMPORTED_MODULE_6__["default"],
                                _fullcalendar_timegrid__WEBPACK_IMPORTED_MODULE_9__["default"],
                                _fullcalendar_list__WEBPACK_IMPORTED_MODULE_7__["default"]
                            ],
                            headerToolbar: {
                                left: "prev, next today",
                                center: "title",
                                right: "dayGridMonth,timeGridWeek,timeGridDay,listMonth"
                            },
                            initialView: "dayGridMonth",
                            editable: true,
                            selectable: true,
                            selectMirror: true,
                            dayMaxEvents: true,
                            select: handleDateClick,
                            eventClick: handleEventClick,
                            eventsSet: (event)=>{
                                setCurrentEvents(event);
                            },
                            // eventChange={(event) => console.log(event)}
                            eventChange: (event)=>{
                                const eventChange = new Date((0,_fullcalendar_core__WEBPACK_IMPORTED_MODULE_4__.formatDate)(event.event.startStr, {
                                    year: "numeric",
                                    month: "short",
                                    day: "numeric"
                                }));
                                try {
                                    _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_1__/* .ScheduleApi.scheduleHostModifier */ .I.scheduleHostModifier(event.event.id, {
                                        Date: addDays(eventChange, 1)
                                    });
                                } catch (error) {
                                    console.log(error);
                                    return {
                                        error
                                    };
                                }
                            }
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Schedule);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1013:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_dashboard_layoutPanel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8773);
/* harmony import */ var _components_dashboard_navbar_navbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6371);
/* harmony import */ var _components_dashboard_schedule_schedule__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4723);
/* harmony import */ var _components_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5209);
/* harmony import */ var _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(231);
/* harmony import */ var _contexts_dashboard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5382);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6197);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8033);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_dashboard_navbar_navbar__WEBPACK_IMPORTED_MODULE_2__, _components_dashboard_schedule_schedule__WEBPACK_IMPORTED_MODULE_3__, _components_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_4__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_7__, _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_10__]);
([_components_dashboard_navbar_navbar__WEBPACK_IMPORTED_MODULE_2__, _components_dashboard_schedule_schedule__WEBPACK_IMPORTED_MODULE_3__, _components_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_4__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_5__, framer_motion__WEBPACK_IMPORTED_MODULE_7__, _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
"use client";











const Index = ({})=>{
    const { selectOption , setSelectOption , setEventArr , eventArr  } = (0,react__WEBPACK_IMPORTED_MODULE_8__.useContext)(_contexts_dashboard__WEBPACK_IMPORTED_MODULE_6__/* .DashboardContext */ .G);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_9__.useSession)();
    const [isHoverCorner, setIsHoverCorner] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const fetchSchedule = async ()=>{
        try {
            if (status === "unauthenticated" || status === "loading") return;
            const schedule = await _api_client_scheduleApi__WEBPACK_IMPORTED_MODULE_10__/* .ScheduleApi.scheduleHost */ .I.scheduleHost(session?.userAcc.UserId);
            if (schedule.status == 200) {
                console.log(schedule.data);
                setEventArr(schedule.data);
            }
        } catch (error) {
            console.log(error);
            return;
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (eventArr.length == 0) {
            fetchSchedule();
        }
    }, [
        status
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-screen h-screen",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_headers_headerForm_HeaderForm__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-screen h-[calc(100vh-5rem)] flex",
                children: [
                    selectOption === "Schedule" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_layoutPanel__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_schedule_schedule__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.div, {
                        onHoverStart: (event)=>{
                            setIsHoverCorner(true);
                        },
                        className: "w-[2rem] fixed h-screen top-0 left-0 border-r-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full h-full flex",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "m-auto",
                                id: "hoverme",
                                children: "Lets hover me"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_7__.motion.div, {
                        onHoverStart: (event)=>{
                            setIsHoverCorner(true);
                        },
                        initial: {
                            left: "-30rem"
                        },
                        animate: isHoverCorner ? {
                            left: [
                                "-30rem",
                                "0rem"
                            ]
                        } : {
                            x: [
                                "0rem",
                                "-30rem"
                            ]
                        },
                        transition: {
                            duration: .6
                        },
                        onHoverEnd: (event)=>{
                            setIsHoverCorner(false);
                        },
                        className: "fixed top-0 left-0 bg-white w-fit h-screen z-50 ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_dashboard_navbar_navbar__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                    })
                ]
            })
        ]
    });
};
Index.Layout = _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);
const getServerSideProps = async ({ req , res  })=>{
    const keyMapBing = process.env.ACCESS_TOKEN_BINGMAP;
    const keyChatEngine = process.env.KEYCHAT_ENGINE;
    return {
        props: {
            keyMapBing: keyMapBing,
            keyChatEngine: keyChatEngine
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7991:
/***/ ((module) => {

module.exports = require("bing-maps-loader");

/***/ }),

/***/ 5538:
/***/ ((module) => {

module.exports = require("bingmaps");

/***/ }),

/***/ 4146:
/***/ ((module) => {

module.exports = require("date-fns");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 4304:
/***/ ((module) => {

module.exports = require("react-date-range");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 8547:
/***/ ((module) => {

module.exports = require("react-icons/gr");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 4152:
/***/ ((module) => {

module.exports = require("react-icons/tb");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9405:
/***/ ((module) => {

module.exports = import("@fullcalendar/core");;

/***/ }),

/***/ 5503:
/***/ ((module) => {

module.exports = import("@fullcalendar/daygrid");;

/***/ }),

/***/ 1103:
/***/ ((module) => {

module.exports = import("@fullcalendar/interaction");;

/***/ }),

/***/ 2483:
/***/ ((module) => {

module.exports = import("@fullcalendar/list");;

/***/ }),

/***/ 9870:
/***/ ((module) => {

module.exports = import("@fullcalendar/react");;

/***/ }),

/***/ 476:
/***/ ((module) => {

module.exports = import("@fullcalendar/timegrid");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

module.exports = import("framer-motion");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,664,170,298,806,565,543,39,856,209,231,254,462,382], () => (__webpack_exec__(1013)));
module.exports = __webpack_exports__;

})();