(() => {
var exports = {};
exports.id = 544;
exports.ids = [544];
exports.modules = {

/***/ 5287:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Montserrat_097b2d', '__Montserrat_Fallback_097b2d'","fontStyle":"normal"},
	"className": "__className_097b2d",
	"variable": "__variable_097b2d"
};


/***/ }),

/***/ 8194:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const axiosClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "/api",
    headers: {
        "Content-Type": "application/json"
    }
});
// Add a response interceptor
axiosClient.interceptors.response.use(function(response) {
    // Any status code that lie within the range of 2xx cause this function to trigger
    // Do something with response data
    return response;
}, function(error) {
    // Any status codes that falls outside the range of 2xx cause this function to trigger
    // Do something with response error
    return {
        error: error
    };
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (axiosClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9841:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "O": () => (/* binding */ schedule)
/* harmony export */ });
/* harmony import */ var _axiosClient__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8194);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosClient__WEBPACK_IMPORTED_MODULE_0__]);
_axiosClient__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const schedule = {
    createSchedule (payload) {
        return _axiosClient__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/create/schedule", payload);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 38:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticPaths": () => (/* binding */ getStaticPaths),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_font_google_target_css_path_src_pages_confirm_slug_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(5287);
/* harmony import */ var next_font_google_target_css_path_src_pages_confirm_slug_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(next_font_google_target_css_path_src_pages_confirm_slug_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _api_client_schedule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9841);
/* harmony import */ var _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(231);
/* harmony import */ var _components_rootMaskHeader_controlPlan_controlBar_popOverDetail_checkIn_Out__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4141);
/* harmony import */ var _components_rootMaskHeader_controlPlan_controlBar_popOverDetail_who__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(779);
/* harmony import */ var _contexts_bill__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2357);
/* harmony import */ var _contexts_selectPlace__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9445);
/* harmony import */ var _contexts_userAcc__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3708);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1908);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6197);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5641);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(5609);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5687);
/* harmony import */ var https__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(https__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var node_fetch__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(6544);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_client_schedule__WEBPACK_IMPORTED_MODULE_1__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_8__, framer_motion__WEBPACK_IMPORTED_MODULE_9__, react_hook_form__WEBPACK_IMPORTED_MODULE_14__, node_fetch__WEBPACK_IMPORTED_MODULE_19__]);
([_api_client_schedule__WEBPACK_IMPORTED_MODULE_1__, _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_2__, _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_8__, framer_motion__WEBPACK_IMPORTED_MODULE_9__, react_hook_form__WEBPACK_IMPORTED_MODULE_14__, node_fetch__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





















const variants = {
    showMask: {
        display: "flex",
        opacity: [
            0,
            1
        ]
    },
    hiddenMask: {
        opacity: [
            1,
            0
        ],
        transitionEnd: {
            display: "none"
        }
    }
};
const phonePattern = /(84|0[3|5|7|8|9])+([0-9]{8})\b/g;
const schema = yup__WEBPACK_IMPORTED_MODULE_17__.object({
    guests: yup__WEBPACK_IMPORTED_MODULE_17__.object({
        adults: yup__WEBPACK_IMPORTED_MODULE_17__.number(),
        childrens: yup__WEBPACK_IMPORTED_MODULE_17__.number(),
        infants: yup__WEBPACK_IMPORTED_MODULE_17__.number()
    }).required(),
    phoneNumber: yup__WEBPACK_IMPORTED_MODULE_17__.string().required().matches(phonePattern, "Invalid phone number")
}).required();
const Confirm = ({ houseDetail , keyMapBox  })=>{
    const { Bill , setBill  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_bill__WEBPACK_IMPORTED_MODULE_5__/* .BillContext */ .m);
    const { address  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_selectPlace__WEBPACK_IMPORTED_MODULE_6__/* .selectPlaceContext */ .t);
    const { user  } = (0,react__WEBPACK_IMPORTED_MODULE_13__.useContext)(_contexts_userAcc__WEBPACK_IMPORTED_MODULE_7__/* .userAccContext */ .G);
    const guestRef = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)(null);
    const calenderRef = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)(null);
    const notificateRef = (0,react__WEBPACK_IMPORTED_MODULE_13__.useRef)(null);
    const [maskNotificate, setMaskNotificate] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    const [maskGuests, setMaskGuests] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    const [maskCalender, setMaskCalender] = (0,react__WEBPACK_IMPORTED_MODULE_13__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const { register , handleSubmit , setError , formState: { errors  }  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_14__.useForm)({
        defaultValues: {
            guests: Bill.guest,
            phoneNumber: ""
        },
        resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_8__.yupResolver)(schema)
    });
    (0,react__WEBPACK_IMPORTED_MODULE_13__.useEffect)(()=>{
        setBill({
            ...Bill,
            guest: {
                ...Bill.guest,
                ...address.guest
            }
        });
    }, [
        address.guest
    ]);
    const onSubmit = async (data)=>{
        if (Bill.guest.adults === 0) {
            // setMaskGuests(true);
            router.push("/homepage", undefined, {
                shallow: true
            });
            return;
        }
        const createSchedule = await _api_client_schedule__WEBPACK_IMPORTED_MODULE_1__/* .schedule.createSchedule */ .O.createSchedule({
            HouseId: houseDetail?.HouseId,
            UserId: user.UserId,
            PhoneNumber: data.phoneNumber + "",
            Date: Bill.checkInDay,
            Adults: Bill.guest.adults,
            Childrens: Bill.guest.childrens,
            Infants: Bill.guest.infants
        });
        if (createSchedule.status != 200) {
            console.log("have err with create schedule");
            return;
        } else {
            if (createSchedule.data.isExist == true) {
                setMaskNotificate(true);
                return;
            }
            router.push({
                pathname: "/confirm/" + houseDetail?.HouseId,
                query: {
                    slug: "your-slug-value"
                }
            }, undefined, {
                shallow: true
            });
        }
    };
    const maskGuests_ = (event)=>{
        const isClickGuests = guestRef.current?.contains(event.target);
        if (!isClickGuests) {
            setMaskGuests(false);
            return;
        }
    };
    const maskCalender_ = (event)=>{
        const isClickCalender = calenderRef.current?.contains(event.target);
        if (!isClickCalender) {
            setMaskCalender(false);
            return;
        }
    };
    const maskNotificate_ = (event)=>{
        const isClickMaskNotificate = notificateRef.current?.contains(event.target);
        if (!isClickMaskNotificate) {
            setMaskNotificate(false);
            return;
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.div, {
                    variants: variants,
                    animate: maskGuests ? "showMask" : "hiddenMask",
                    onClick: maskGuests_,
                    className: "fixed w-screen h-screen bg-mask flex z-30",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.div, {
                        className: "w-fit h-fit m-auto",
                        ref: guestRef,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_rootMaskHeader_controlPlan_controlBar_popOverDetail_who__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            styleWho: "justify-center w-[800px] h-[32rem]"
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.div, {
                    variants: variants,
                    animate: maskCalender ? "showMask" : "hiddenMask",
                    onClick: maskCalender_,
                    className: "fixed w-screen h-screen bg-mask flex z-30",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.div, {
                        className: "w-fit h-fit m-auto",
                        ref: notificateRef,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_rootMaskHeader_controlPlan_controlBar_popOverDetail_checkIn_Out__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            styleHorizontal: "mobile:hidden tablet:hidden",
                            styleVerical: "laptop:hidden desktop:hidden"
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.AnimatePresence, {
                initial: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.div, {
                    variants: variants,
                    animate: maskNotificate ? "showMask" : "hiddenMask",
                    onClick: maskNotificate_,
                    className: "fixed w-screen h-screen bg-mask flex z-30",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.div, {
                        className: "w-fit h-fit m-auto",
                        ref: notificateRef,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.div, {
                            className: "w-fit relative h-fit text-center bg-white rounded-2xl p-7 border-2 border-red-500   ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: (event)=>setMaskNotificate(false),
                                    className: "absolute right-3 top-2",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_16__.GrClose, {})
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_15__.BiMessageSquareError, {
                                            className: "mr-2 text-[2rem] text-red-500"
                                        }),
                                        " you must be cancelled before create new one schedule apointment"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    href: {
                                        pathname: `/house/${houseDetail?.HouseId}`
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "w-full mt-2 bg-red-400 rounded-2xl text-white",
                                        children: "Go to your schedule"
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `w-full h-fit box-border flex ${(next_font_google_target_css_path_src_pages_confirm_slug_tsx_import_Montserrat_arguments_subsets_latin_weight_200_400_600_800_variable_font_monsterrat_variableName_monsterrat___WEBPACK_IMPORTED_MODULE_20___default().className)}`,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-[calc(100vw-20rem)] h-fit m-auto mt-5 mobile:w-screen",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full h-fit flex items-center ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    href: `/house/${houseDetail?.HouseId}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.button, {
                                        className: "w-[3rem] h-[2.4rem]",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_16__.GrPrevious, {
                                            className: "text-[28px] m-auto"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-[2rem]",
                                    children: "Confirm and pay"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                            className: "w-full flex mt-5",
                            onSubmit: handleSubmit(onSubmit),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex-[7] flex flex-col box-border tablet:px-5 mobile:px-5",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full flex-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text-[2rem]",
                                                children: "Make an appointment"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full mt-5 flex-1  cursor-pointer",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-full flex justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex flex-col w-fit h-fit ",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "font-semibold",
                                                                    children: "Dates"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    children: moment__WEBPACK_IMPORTED_MODULE_10___default()(Bill.checkInDay).format("MMM D - D, YYYY")
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                onClick: (event)=>setMaskCalender(true),
                                                                className: "text-[22px] underline",
                                                                children: "Edit"
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full mt-5 flex-1",
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "w-full flex justify-between",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "w-fit h-fit flex flex-col",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                        className: "font-semibold",
                                                                        children: "Guests"
                                                                    }),
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                        children: [
                                                                            Bill.guest.adults != 0 || Bill.guest.childrens != 0 ? Bill.guest.adults + Bill.guest.childrens + " guests" : "Guests ",
                                                                            Bill.guest.infants != 0 && ", " + Bill.guest.infants + " infants"
                                                                        ]
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                        onClick: ()=>setMaskGuests(true),
                                                                        className: "text-[22px] underline",
                                                                        children: "Edit"
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full h-fit flex flex-col mt-10 border-t-2 relative",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "w-full flex-1 mt-10",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-[2rem]",
                                                        children: "Enter your phone number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: `w-full h-fit  relative
              after:absolute after:bottom-0 after:w-full after:h-[.25rem]  mt-5
              after:right-0  rounded-xl ${errors.phoneNumber?.message !== undefined ? "after:bg-red-500" : "after:bg-slate-800"}
              `,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        ...register("phoneNumber"),
                                                        type: "text",
                                                        className: "w-full h-[3rem] outline-none   ",
                                                        placeholder: "Phone number"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "absolute -bottom-6 text-red-500",
                                                    children: errors.phoneNumber?.message
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full h-fit flex flex-col border-t-2 mt-10",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "w-full flex-1 mt-10",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-[17px] font-semibold",
                                                        children: " Cancellation policy: "
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "Free cancellation for 48 hours"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "w-full h-fit flex flex-col border-t-2 mt-10",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full flex-1 mt-10",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "By selecting the button below, I agree to the Host's House Rules, Ground rules for guests, Refund Policy, and that can charge my payment method if I’m responsible for damage."
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__.motion.button, {
                                            whileTap: {
                                                scale: 0.8
                                            },
                                            type: "submit",
                                            className: "w-[12.5rem] h-[4rem] bg-red-500 text-white mt-5 rounded-xl",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-semibold text-[2rem]",
                                                children: "Confirm"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex-[6]  box-border p-6 tablet:hidden mobile:hidden",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-full h-full ",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-full h-fit bg-white rounded-2xl shadow-2xl overflow-hidden box-border   p-5   ",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    // src={'/api/img/path'+houseDetail?.arrImg[0].Path}
                                                    src: "/api/img/path/" + houseDetail?.arrImg[0].Path,
                                                    alt: "",
                                                    className: "w-full h-[18.75rem] rounded-2xl object-cover"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-full flex justify-between",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "w-fit h-fit flex flex-col",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    className: "font-semibold text-[1rem]",
                                                                    children: houseDetail?.Title
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                    children: houseDetail?.address.formattedAddress
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "w-fit h-full flex",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                                className: "text-[34px] m-auto",
                                                                children: [
                                                                    "$",
                                                                    houseDetail?.Price
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
Confirm.Layout = _components_layouts_authWithAnimate__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
let cachedHouseDetail = [];
const agent = new (https__WEBPACK_IMPORTED_MODULE_18___default().Agent)({
    rejectUnauthorized: false
});
const options = {
    method: "GET",
    headers: {
        "Content-Type": "application/json"
    },
    agent
};
const getStaticPaths = async ()=>{
    const link = process.env.API_URL_PATH;
    const slug = await (0,node_fetch__WEBPACK_IMPORTED_MODULE_19__["default"])(`${link}/api/get/house/page`, options);
    cachedHouseDetail = await slug.json();
    const paths = cachedHouseDetail.map((house)=>({
            params: {
                slug: house.HouseId
            }
        }));
    return {
        paths,
        fallback: true
    };
};
const getStaticProps = async ({ params  })=>{
    const link = process.env.API_URL_PATH;
    const slug = await (0,node_fetch__WEBPACK_IMPORTED_MODULE_19__["default"])(`${link}/api/get/house/page`, options);
    cachedHouseDetail = await slug.json();
    const houseDetailData = cachedHouseDetail.find((house)=>house.HouseId === params?.slug);
    return {
        props: {
            houseDetail: houseDetailData
        },
        revalidate: 600
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Confirm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4146:
/***/ ((module) => {

"use strict";
module.exports = require("date-fns");

/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 4304:
/***/ ((module) => {

"use strict";
module.exports = require("react-date-range");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6652:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/bi");

/***/ }),

/***/ 8547:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gr");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 5609:
/***/ ((module) => {

"use strict";
module.exports = require("yup");

/***/ }),

/***/ 1908:
/***/ ((module) => {

"use strict";
module.exports = import("@hookform/resolvers/yup");;

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

"use strict";
module.exports = import("framer-motion");;

/***/ }),

/***/ 6544:
/***/ ((module) => {

"use strict";
module.exports = import("node-fetch");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

"use strict";
module.exports = import("react-hook-form");;

/***/ }),

/***/ 5687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [219,664,170,298,864,445,586,543], () => (__webpack_exec__(38)));
module.exports = __webpack_exports__;

})();